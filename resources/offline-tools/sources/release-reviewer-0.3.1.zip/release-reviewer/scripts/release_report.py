#!/usr/bin/env python3
"""Validate source citations and publish one consistent release review report."""
from __future__ import annotations

import argparse
import base64
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import evidence as ev
import chain_review
import resource_rules
import review_session

PRIORITIES = ("P0", "P1")
CONFIG_KINDS = {"config-key", "environment-variable", "config-file"}
CONFIG_STATUSES = {"defined": "已有定義", "missing-definition": "未找到定義",
                   "external": "需確認外部注入", "unknown": "待確認"}
DB_KINDS = {"connection": "連線", "database": "資料庫", "table": "資料表",
            "column": "欄位", "view": "View", "procedure": "預存程序"}
EXTERNAL_KINDS = {"ftp", "sftp", "redis", "kafka", "other"}
INTRODUCTIONS = {"first-use", "resource-definition", "target-change", "access-change"}
LABELS = {"P0": "立即處理", "P1": "上版前修正"}
ASSESSMENTS = {"blocked": "存在已確認阻擋", "incomplete": "檢查未完成",
               "pending-confirmation": "待核對上版條件", "no-blockers-found": "已檢查範圍未發現阻擋"}
CHECKLIST_START = "<!-- release-checklist:start -->"
CHECKLIST_END = "<!-- release-checklist:end -->"


def text(value, label):
    ev.require(isinstance(value, str) and bool(value.strip()), f"{label} 必須是非空白文字。")
    return value.strip()


def strings(value, label):
    ev.require(isinstance(value, list) and all(isinstance(v, str) and v.strip() for v in value),
               f"{label} 必須是文字陣列。")
    return value


def validate_citations(items, manifest, context):
    ev.require(isinstance(items, list), "evidence 必須是陣列。")
    cleaned = []
    for item in items:
        ev.require(isinstance(item, dict), "證據必須是物件。")
        source = item.get("source")
        repo = item.get("repo")
        ev.require(isinstance(repo, str) and bool(repo.strip()), "v3 證據必須含非空白 Repo 身分。")
        ref = item.get("ref")
        path = item.get("path")
        ev.require(isinstance(ref, str) and ev.SHA.fullmatch(ref), "證據必須含完整 SHA。")
        content = ev.read_blob(manifest, context, source, path, ref, repo)
        start, end = item.get("line_start"), item.get("line_end")
        if start is not None or end is not None:
            ev.require(type(start) is int and type(end) is int and 1 <= start <= end,
                       "證據行號必須為有效的正整數區間。")
            ev.require(b"\0" not in content, "二進位證據不能引用文字行號。")
            ev.require(end <= len(content.splitlines()), f"證據行號超出固定檔案：{path}")
        citation = {"repo": repo, "source": source, "ref": ref, "path": path,
                    "content_sha256": hashlib.sha256(content).hexdigest(),
                    **({"line_start": start, "line_end": end} if start is not None else {})}
        if source == "merge-preview" and b"\0" not in content:
            citation.update(preview_snapshot(content, path, start, end))
        cleaned.append(citation)
    return cleaned



def preview_snapshot(content, path, start, end):
    """Keep cited final code after owned objects are cleaned; omit configuration values."""
    decoded = content.decode("utf-8", errors="replace")
    if re.search(r"(?i)BEGIN.*PRIVATE.*KEY", decoded) or Path(path).suffix.lower() in {".pem", ".key", ".pfx", ".p12"}:
        return {"snapshot_note": "認證／私鑰內容已省略，保留原始內容 SHA-256。"}
    config_suffixes = {".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf", ".config", ".env"}
    if Path(path).suffix.lower() in config_suffixes or Path(path).name.startswith(".env"):
        keys = set()
        def collect(value):
            if isinstance(value, dict):
                for key, child in value.items():
                    keys.add(key)
                    collect(child)
            elif isinstance(value, list):
                for child in value:
                    collect(child)
        if Path(path).suffix.lower() == ".json":
            try:
                collect(json.loads(decoded))
            except ValueError:
                pass
        return {"configuration_keys": sorted(keys),
                "snapshot_note": "設定值已省略；僅保留可解析的鍵名及原始內容 SHA-256。"}
    if start is None:
        return {}
    sensitive = re.compile(r"(?i)password|passwd|pwd|token|secret|api.?key|access.?key|private.?key|"
                           r"credential|authorization|connection.?string|data\s*source|initial\s*catalog|"
                           r"server\s*=|host\s*=|begin.*private.*key")
    excerpt = []
    for number, line in enumerate(decoded.splitlines()[start - 1:end], start):
        safe = "[含認證或連線設定的行已省略]" if sensitive.search(line) else redact(line)
        excerpt.append(f"{number}: {safe}")
    return {"excerpt": excerpt}


def expected_coverage(manifest):
    expected = {}
    preview = manifest.get("merge_preview") or {}
    head_pair = ("head", manifest["head_sha"])
    left_pair = ("merge-base", manifest["diff_base"])
    scopes = [(manifest["changed_files"], left_pair, head_pair)]
    if preview.get("status") == "clean":
        merged = ("merge-preview", preview["tree_sha"])
        scopes += [(preview["changed_files"], head_pair, merged),
                   (manifest["release_changes"], ("base", manifest["base_sha"]), merged)]
    # Conflict trees cannot be treated as a final executable version.
    for changes, before, after in scopes:
        for change in changes:
            path = change["path"]
            ev.require(ev.safe_path(path), "變更清單包含無法安全引用的路徑。")
            pair = before if change["status"].startswith("D") else after
            expected.setdefault(path, set()).add(pair)
            old = change.get("old_path")
            if old:
                ev.require(ev.safe_path(old), "變更清單包含無法安全引用的舊路徑。")
                expected.setdefault(old, set()).add(before)
    return expected


def final_version(manifest):
    preview = manifest.get("merge_preview") or {}
    if preview.get("status") == "clean":
        return "merge-preview", preview["tree_sha"]
    return "head", manifest["head_sha"]


def validate_result(draft, manifest, context):
    ev.require(isinstance(draft, dict) and draft.get("schema") == "ReleaseReviewDraft/v3",
               "結果須使用 ReleaseReviewDraft/v3。")
    ev.require(not draft.get("checklist"), "初始 Checklist 由 helper 產生，不能預填已確認。")
    result = {"schema": "ReleaseReviewReport/v3", "summary": text(draft.get("summary"), "summary")}
    for field in ("coverage", "code_risks", "config_changes", "db_changes", "external_changes", "dependency_coverage"):
        ev.require(isinstance(draft.get(field), list), f"{field} 必須是陣列。")
    for field in ("next_steps", "tests_executed", "tests_not_executed", "limitations"):
        result[field] = strings(draft.get(field), field)
    expected = expected_coverage(manifest)
    all_changes = (manifest["changed_files"] + manifest["release_changes"]
                   + (manifest.get("merge_preview") or {}).get("changed_files", []))
    metadata_paths = {p for c in all_changes
                      if c.get("binary") or "160000" in (c.get("old_mode"), c.get("new_mode"))
                      for p in (c.get("path"), c.get("old_path")) if p}
    covered = {}
    for item in draft["coverage"]:
        ev.require(isinstance(item, dict), "coverage 項目須為物件。")
        path = item.get("path")
        ev.require(path in expected and path not in covered, f"覆蓋路徑重複或不在變更範圍：{path}")
        status = item.get("status")
        ev.require(status in {"reviewed", "metadata-only", "not-reviewed"}, "覆蓋狀態無效。")
        citations = validate_citations(item.get("evidence", []), manifest, context)
        ev.require(all(e["repo"] == "entry" and e["path"] == path for e in citations), "覆蓋證據必須指向入口 Repo 該路徑。")
        entry = {"path": path, "status": status, "evidence": citations}
        if status == "reviewed":
            ev.require(path not in metadata_paths, "二進位或 submodule 路徑須保留內容檢查限制。")
            actual = {(e["source"], e["ref"]) for e in citations}
            ev.require(expected[path] <= actual, f"缺少此路徑在各比較範圍的固定證據：{path}")
        else:
            entry["reason"] = text(item.get("reason"), "未完整覆蓋原因")
        covered[path] = entry
    ev.require(set(covered) == set(expected), "coverage 未列出所有變更路徑及改名前的路徑。")
    result["coverage"] = list(covered.values())
    reviewed = {p for p, item in covered.items() if item["status"] == "reviewed"}
    previous_priority = -1
    final_pair = final_version(manifest)
    risks = []
    for number, item in enumerate(draft["code_risks"], 1):
        ev.require(isinstance(item, dict) and item.get("id") == f"R-{number:03}", "程式風險編號須連續。")
        priority = item.get("priority")
        ev.require(priority in PRIORITIES, "只接受直接阻止上版的 P0／P1 程式風險。")
        order = PRIORITIES.index(priority)
        ev.require(order >= previous_priority, "程式風險須依 P0、P1 排序。")
        previous_priority = order
        risk = {k: text(item.get(k), k) for k in
                ("id", "priority", "title", "blocking_reason", "trigger", "impact", "recommendation", "scenario_source")}
        ev.require(risk["scenario_source"] in {"code-derived", "reproduced"}, "情境來源無效。")
        ev.require(risk["scenario_source"] != "reproduced" or bool(result["tests_executed"]),
                   "標示已重現時須記錄實際執行的檢查。")
        risk["evidence"] = validate_citations(item.get("evidence", []), manifest, context)
        ev.require(any(e["repo"] == "entry" and e["path"] in reviewed for e in risk["evidence"]),
                   "程式風險至少須引用一個已審查的變更路徑。")
        ev.require(any(e["repo"] == "entry" and (e["source"], e["ref"]) == final_pair for e in risk["evidence"]),
                   "程式風險須附最終受審版本的行為證據。")
        risks.append(risk)
    result["code_risks"] = risks
    searches = {}
    for field, prefix, kinds in (("config_changes", "C", CONFIG_KINDS),
                                 ("db_changes", "D", set(DB_KINDS)),
                                 ("external_changes", "E", EXTERNAL_KINDS)):
        changes = []
        identities = set()
        for number, item in enumerate(draft[field], 1):
            ev.require(isinstance(item, dict) and item.get("id") == f"{prefix}-{number:03}",
                       f"{field} 編號須連續。")
            change = {k: text(item.get(k), k) for k in
                      ("id", "kind", "name", "description", "baseline_reason", "recommendation")}
            ev.require(change["kind"] in kinds, f"{field} 類型無效。")
            change["introduction"] = item.get("introduction", "first-use")
            ev.require(change["introduction"] in INTRODUCTIONS, "新增依賴判定類型無效。")
            change["evidence"] = validate_citations(item.get("evidence", []), manifest, context)
            ev.require(any(e["repo"] == "entry" and (e["source"], e["ref"]) == final_pair for e in change["evidence"]),
                       "新增依賴須引用最終受審版本中的使用、目標或部署定義位置。")
            identifiers = item.get("baseline_searches")
            ev.require(isinstance(identifiers, list) and bool(identifiers),
                       "新增使用須附基礎版本整個 Repo 的搜尋紀錄。")
            for identifier in identifiers:
                if identifier not in searches:
                    searches[identifier] = ev.validate_baseline_search(context, manifest, identifier)
            change["baseline_searches"] = identifiers
            if field == "config_changes":
                status = item.get("definition_status")
                ev.require(status in CONFIG_STATUSES, "設定定義狀態無效。")
                change["definition_status"] = status
                change["definition_evidence"] = validate_citations(
                    item.get("definition_evidence", []), manifest, context)
                if status == "defined":
                    ev.require(any(e["repo"] == "entry" and (e["source"], e["ref"]) == final_pair
                                   for e in change["definition_evidence"]),
                               "已有定義須附最終版本中的設定定義證據。")
                identity = (change["kind"], change["name"])
            else:
                change["connection"] = text(item.get("connection"), "connection")
                change["resolution"] = item.get("resolution")
                ev.require(change["resolution"] in {"identified", "unknown"}, "資源辨識狀態無效。")
                identity = (change["connection"], change["kind"], change["name"])
            ev.require(identity not in identities, "同一新增使用項目不應重複列出。")
            identities.add(identity)
            changes.append(change)
        result[field] = changes
    result["baseline_searches"] = [{"id": identifier, "query": record["query"],
                                   "repo": record["repo"], "ref": record["ref"],
                                   "ignore_case": record["ignore_case"],
                                   "match_count": len(record["matches"])}
                                  for identifier, record in searches.items()]
    result.update(chain_review.validate(draft, manifest, context, validate_citations))
    unrelated = {c["repo"] for c in result["supporting_coverage"] if c["status"] == "unrelated"}
    ev.require(not any(e["repo"] in unrelated for risk in risks for e in risk["evidence"]), "風險不能引用已判定無關的 Repo。")
    categories, resource_complete = {}, True
    for item in draft["dependency_coverage"]:
        ev.require(isinstance(item, dict), "依賴覆蓋項目須為物件。")
        kind = item.get("kind")
        ev.require(kind in {"config", "db", *EXTERNAL_KINDS} and kind not in categories, "依賴覆蓋類型重複或無效。")
        status = item.get("status")
        ev.require(status in {"reviewed", "not-reviewed"}, "依賴覆蓋狀態無效。")
        citations = validate_citations(item.get("evidence", []), manifest, context)
        if status == "reviewed" and expected:
            ev.require(any(e["repo"] == "entry" and (e["source"], e["ref"]) == final_pair for e in citations),
                       "依賴覆蓋須有最終受審版本證據。")
        categories[kind] = {"kind": kind, "status": status, "reason": text(item.get("reason"), "依賴覆蓋說明"), "evidence": citations}
        resource_complete = resource_complete and status == "reviewed"
    ev.require(set(categories) == {"config", "db", *EXTERNAL_KINDS}, "缺少設定、DB 或外部資源類型覆蓋。")
    result["dependency_coverage"] = list(categories.values())
    result["checklist"] = resource_rules.build_checklist(result)
    for field in ("config_changes", "db_changes", "external_changes"):
        for dependency in result[field]:
            dependency["checklist_ids"] = [c["id"] for c in result["checklist"] if c["dependency_id"] == dependency["id"]]
    result["environment_status"] = "待人工核對" if result["checklist"] else "未驗證實際環境"
    # Complete means the documented static scope is covered, never that production is ready.
    unresolved = any(c["definition_status"] == "unknown" for c in result["config_changes"])
    unresolved |= any(d["resolution"] == "unknown" for d in result["db_changes"])
    unresolved |= any(d["resolution"] == "unknown" for d in result["external_changes"])
    complete = manifest["context_complete"] and all(v["status"] == "reviewed" for v in covered.values())
    complete = complete and not unresolved and result["chain_complete"] and resource_complete
    result["review_complete"] = complete
    result["status"] = "靜態檢查完成" if complete else "檢查未完成"
    if complete and not expected:
        result["status"] = "沒有差異"
    result["identity"] = {key: manifest.get(key) for key in
                          ("project", "repo", "base_input", "head_input", "base_sha", "head_sha",
                           "merge_base", "diff_base", "mode", "generated_at", "working_tree_unchanged", "report_root")}
    result["identity"].update({"final_source": final_pair[0], "final_ref": final_pair[1]})
    result["identity"].update({"scope": manifest["scope"], "entry_repo": "entry", "repositories": manifest["repositories"]})
    result["context_gaps"] = manifest["context_gaps"]
    result["merge_status"] = (manifest.get("merge_preview") or {}).get("status")
    result["merge_detail"] = (manifest.get("merge_preview") or {}).get("detail", "")
    result["review_gaps"] = review_gaps(result)
    result["blocker_count"] = len(risks) + int(result["merge_status"] == "conflicts")
    result["pending_count"] = len(result["checklist"])
    result["gap_count"] = len(result["review_gaps"])
    result["release_assessment"] = ("blocked" if result["blocker_count"] else
                                    "incomplete" if not complete else
                                    "pending-confirmation" if result["pending_count"] else
                                    "no-blockers-found")
    return result


def redact(value):
    """Remove common credential formats; reviewers must also omit secret values."""
    if isinstance(value, list):
        return [redact(v) for v in value]
    if isinstance(value, dict):
        return {k: redact(v) for k, v in value.items()}
    if not isinstance(value, str):
        return value
    value = re.sub(r"(?i)(\b(?:password|pwd|token|api[_-]?key|secret|access[_-]?key)\b"
                   r"\s*[=:]\s*)(?:\"[^\"]*\"|'[^']*'|[^;,\s&]+)",
                   r"\1[已遮蔽]", value)
    value = re.sub(r"(?i)([a-z][a-z0-9+.-]*://)[^/\s:@]+:[^/\s@]+@", r"\1[已遮蔽]@", value)
    return re.sub(r"(?i)(\bBearer\s+)\S+", r"\1[已遮蔽]", value)


def cell(value):
    return str(value).replace("|", r"\|").replace("\r", " ").replace("\n", " ")


def citations(items):
    lines = []
    for item in items:
        location = item["repo"] + "/" + item["path"]
        if "line_start" in item:
            location += f":{item['line_start']}-{item['line_end']}"
        lines.append(f"- {location}；來源 {item['source']}；版本 {item['ref']}")
        if item.get("content_sha256"):
            lines.append(f"  內容 SHA-256：{item['content_sha256']}")
        if item.get("excerpt"):
            longest = max((len(m.group()) for line in item["excerpt"] for m in re.finditer(r"~+", line)), default=0)
            fence = "~" * max(3, longest + 1)
            lines += ["", fence + "text", *item["excerpt"], fence, ""]
        if "configuration_keys" in item:
            lines.append("  設定鍵：" + ("、".join(item["configuration_keys"]) or "未取得可解析鍵名"))
        if item.get("snapshot_note"):
            lines.append("  " + item["snapshot_note"])
    return lines


def review_gaps(result):
    gaps = list(result["context_gaps"]) + list(result["chain_gaps"])
    gaps += [f"未覆蓋 {c['path']}：{c['reason']}" for c in result["coverage"] if c["status"] != "reviewed"]
    gaps += [f"關聯 Repo {c['repo']}：{c['reason']}" for c in result["supporting_coverage"]
             if c["status"] == "not-reviewed"]
    gaps += [f"功能鏈 {link['id']}：{link['reason']}" for link in result["functional_chain"]
             if link["status"] == "not-reviewed"]
    gaps += [f"依賴類型 {c['kind']}：{c['reason']}" for c in result["dependency_coverage"]
             if c["status"] == "not-reviewed"]
    gaps += [f"{c['id']} {c['name']}：設定來源尚未解析。" for c in result["config_changes"]
             if c["definition_status"] == "unknown"]
    gaps += [f"{c['id']} {c['name']}：資源目標尚未解析。"
             for c in result["db_changes"] + result["external_changes"] if c["resolution"] == "unknown"]
    return list(dict.fromkeys(gaps))


def static_body(body):
    """Hash fixed review text, excluding only the delimited human checklist."""
    ev.require(body.count(CHECKLIST_START) == body.count(CHECKLIST_END) == 1,
               "報告須包含唯一的人工 Checklist 區塊。")
    start, end = body.index(CHECKLIST_START), body.index(CHECKLIST_END)
    ev.require(start < end, "Checklist 邊界順序無效。")
    return body[:start] + body[end + len(CHECKLIST_END):]


def short_citations(items):
    return "；".join(cell(e["repo"] + "/" + e["path"] +
                    (f":{e['line_start']}-{e['line_end']}" if "line_start" in e else ""))
                    for e in items)


def render_checklist(result):
    lines = [CHECKLIST_START, "### 人工核對紀錄", ""]
    for dependency in result["config_changes"] + result["db_changes"] + result["external_changes"]:
        lines += [f"#### [{dependency['id']}｜{dependency['name']}](#{dependency['id']})", "",
                  "| 編號 | 核對事項 | 狀態 | 核對人 | 日期 | 工單／驗證證據 | 不適用理由 |",
                  "| --- | --- | --- | --- | --- | --- | --- |"]
        for item in result["checklist"]:
            if item["dependency_id"] == dependency["id"]:
                lines.append(f"| <a id=\"{item['id']}\"></a>{item['id']} | {cell(item['question'])} | 待確認 | | | | |")
        lines.append("")
    if not result["checklist"]:
        lines += ["本次沒有新增依賴的自動核對項。", ""]
    lines.append(CHECKLIST_END)
    return "\n".join(lines)


def render_markdown(result):
    identity = result["identity"]
    lines = ["# Release Report", "",
             f"**產生時上版判斷：{ASSESSMENTS[result['release_assessment']]}**", "",
             result["summary"], "",
             f"阻擋 {result['blocker_count']} 項｜待確認 {result['pending_count']} 項｜檢查缺口 {result['gap_count']} 項。",
             f"靜態範圍：{result['status']}。判斷固定於產生時；人工填寫 Checklist 不會自動核准上版。",
             "", "## 已確認阻擋項", ""]
    if result["merge_status"] == "conflicts":
        lines += ["### M-001｜合併衝突", "",
                  "基礎與比較版本無法產生乾淨的合併結果，須先解決衝突並重新審查。",
                  "衝突樹不能當成最終可執行版本；Git 固定版本紀錄見後文。", ""]
    for risk in result["code_risks"]:
        lines += [f"### {risk['id']}｜{risk['priority']}｜{risk['title']}", "",
                  f"**阻擋原因**：{risk['blocking_reason']}", "",
                  f"**觸發條件**：{risk['trigger']}", "",
                  f"**影響**：{risk['impact']}", "",
                  f"**處理方式**：{risk['recommendation']}", "",
                  f"**證據**：{short_citations(risk['evidence'])}。",
                  "**情境**：" + ("程式推導，未實際執行。" if risk["scenario_source"] == "code-derived"
                                else "已實際重現，執行紀錄見後文。"), ""]
    if not result["blocker_count"]:
        lines += ["已檢查範圍未發現有證據的直接阻擋；待確認條件與缺口見後文。", ""]
    lines += ["## 新增項目與 Checklist", ""]
    dependencies = result["config_changes"] + result["db_changes"] + result["external_changes"]
    for dependency in dependencies:
        status = (CONFIG_STATUSES[dependency["definition_status"]] if "definition_status" in dependency
                  else "待解析目標" if dependency["resolution"] == "unknown" else "已辨識目標")
        lines += [f"<a id=\"{dependency['id']}\"></a>", "",
                  f"### {dependency['id']}｜{dependency['name']}", "",
                  f"{dependency['description']}（{status}）",
                  f"連線／用途：{dependency.get('connection', '入口服務設定')}。",
                  f"**上版準備**：{dependency['recommendation']}", "",
                  "**核對項**：" + "、".join(f"[{kid}](#{kid})" for kid in dependency["checklist_ids"]), ""]
    if not dependencies:
        lines += ["本次未辨識到新增依賴。", ""]
    lines += ["核對狀態限「待確認／已確認／未通過／不適用」。已確認需核對人、日期及開通／套用後驗證證據；",
              "僅有申請工單仍為待確認，不適用需具體理由。必要項目待確認或未通過時，上版準備未完成。",
              "本段核對紀錄可人工更新；固定正文與產生時判斷保留原始快照。", "",
              render_checklist(result), "", "## 待確認事項與限制", ""]
    if result["checklist"]:
        lines += ["- 新增依賴的目標環境準備尚待上述 Checklist 核對。"]
    lines += [f"- {gap}" for gap in result["review_gaps"]]
    lines += [f"- {limit}" for limit in result["limitations"]]
    if not result["review_gaps"] and not result["limitations"] and not result["checklist"]:
        lines += ["本次沒有另外列出的待確認事項或檢查缺口。"]
    if result["next_steps"]:
        lines += ["", "**後續處理**：", "", *[f"- {step}" for step in result["next_steps"]]]
    lines += ["", "## 證據與版本紀錄", "", "<details>",
              "<summary>固定版本、搜尋、功能鏈與覆蓋紀錄</summary>", ""]
    for label, key in (("Repo", "repo"), ("工作區報告根目錄", "report_root"),
                       ("基礎分支", "base_input"), ("比較分支", "head_input"),
                       ("基礎 SHA", "base_sha"), ("比較 SHA", "head_sha"), ("共同起點", "merge_base"),
                       ("最終來源", "final_source"), ("最終 SHA", "final_ref"),
                       ("擷取時間（UTC）", "generated_at"), ("本機檔案與暫存區維持原狀", "working_tree_unchanged")):
        lines.append(f"- {label}：{identity.get(key)}")
    lines += ["", "版本比對只包含已提交內容。靜態範圍完整不代表目標環境已驗證。", ""]
    if result["merge_status"] != "clean":
        lines += ["**合併預覽紀錄**：", "",
                  *["> " + line for line in result["merge_detail"].splitlines()], ""]
    for risk in result["code_risks"]:
        lines += [f"### {risk['id']} 固定證據", "", *citations(risk["evidence"]), ""]
    records = {r["id"]: r for r in result["baseline_searches"]}
    for dependency in dependencies:
        lines += [f"### {dependency['id']} 新增判定與證據", "",
                  f"新增類型：{dependency['introduction']}；{dependency['baseline_reason']}", "",
                  *citations(dependency["evidence"]), ""]
        if dependency.get("definition_evidence"):
            lines += ["設定定義：", "", *citations(dependency["definition_evidence"]), ""]
        for identifier in dependency["baseline_searches"]:
            record = records[identifier]
            lines.append(f"- 基礎全 Repo 搜尋：{cell(record['query'])}；命中 {record['match_count']}；紀錄 {identifier}")
        lines.append("")
    lines += ["### 關聯 Repo 與功能鏈", "",
              "| Repo | 固定本機分支 | SHA | 狀態 |", "| --- | --- | --- | --- |"]
    for repo in identity["repositories"]:
        lines.append(f"| {cell(repo['id'] + ' / ' + repo['name'])} | {cell(repo.get('default_branch') or '入口指定分支')} | {repo.get('ref') or '見入口版本／未取得'} | {repo['status']} |")
    for coverage in result["supporting_coverage"]:
        lines += ["", f"**{coverage['repo']}：{coverage['status']}**；{coverage['reason']}", "",
                  *citations(coverage["evidence"])]
    for link in result["functional_chain"]:
        lines += ["", f"**{link['id']}｜{link['from_repo']} → {link['to_repo']}｜{link['kind']}**",
                  f"{link['status']}：{link['description']}", "", *citations(link["evidence"])]
        if link.get("reason"):
            lines += ["", link["reason"]]
    for record in result["supporting_searches"]:
        lines.append(f"- 關聯搜尋：{record['repo']}；版本 {record['ref']}；{cell(record['query'])}；命中 {record['match_count']}；紀錄 {record['id']}")
    lines += ["", "### 靜態覆蓋", "", "| 路徑 | 狀態 | 未完成原因 |", "| --- | --- | --- |"]
    for coverage in result["coverage"]:
        lines.append(f"| {cell(coverage['path'])} | {coverage['status']} | {cell(coverage.get('reason', ''))} |")
    if not result["coverage"]:
        lines.append("| — | 沒有變更路徑 | — |")
    lines += ["", "**依賴類型覆蓋**：", "",
              *[f"- {c['kind']}：{c['status']}；{c['reason']}" for c in result["dependency_coverage"]]]
    for title, values in (("已執行檢查", result["tests_executed"]),
                          ("未執行檢查", result["tests_not_executed"])):
        lines += ["", f"**{title}**：", "", *([f"- {v}" for v in values] or ["- 無紀錄。"])]
    lines += ["", "</details>", ""]
    return "\n".join(lines)


def publish_report(context, draft_path):
    context = Path(context).expanduser().absolute()
    try:
        context = review_session.validate_session(context)
        manifest = ev.load_manifest(context)
        draft_path = Path(draft_path).resolve()
        ev.require(draft_path.is_relative_to(context), "草稿必須位於本次 context 內。")
        draft = json.loads(draft_path.read_text(encoding="utf-8"))
        result = redact(validate_result(draft, manifest, context))
        destination = Path(manifest["report_root"])
        ev.require(not destination.is_relative_to(context), "報告不能寫入稍後會清理的 context。")
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        stem = f"release-review-{stamp}-{manifest['base_sha'][:8]}-{manifest['head_sha'][:8]}"
        body = render_markdown(result)
        metadata = {"schema": result["schema"], **result["identity"],
                    "review_complete": result["review_complete"],
                    "release_assessment": result["release_assessment"],
                    "blocker_count": result["blocker_count"], "pending_count": result["pending_count"],
                    "gap_count": result["gap_count"],
                    "context_sha256": hashlib.sha256((context / "manifest.json").read_bytes()).hexdigest(),
                    "static_body_sha256": hashlib.sha256(static_body(body).encode("utf-8")).hexdigest()}
        marker = base64.b64encode(ev.canonical(metadata)).decode("ascii")
        markdown = body + f"\n<!-- release-review-report:{marker} -->\n"
        for number in range(1000):
            suffix = "" if number == 0 else f"-{number:02}"
            md = destination / f"{stem}{suffix}.md"
            created = False
            try:
                with md.open("x", encoding="utf-8", newline="\n") as stream:
                    created = True
                    stream.write(markdown)
            except FileExistsError:
                continue
            except BaseException:
                if created:
                    md.unlink(missing_ok=True)
                raise
            return md
        raise ValueError("找不到可使用的新報告檔名。")
    finally:
        review_session.cleanup_if_owned(context)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--context-dir", required=True)
    parser.add_argument("--result", required=True)
    args = parser.parse_args(argv)
    try:
        md = publish_report(args.context_dir, args.result)
    except (ValueError, OSError, KeyError, TypeError, subprocess.TimeoutExpired) as exc:
        print(f"release-report: 未建立報告：{exc}", file=sys.stderr)
        return 2
    print(json.dumps({"markdown_report": str(md)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
