#!/usr/bin/env python3
"""Validate the shared Copilot/Codex capability surface without byte mirroring."""

from __future__ import annotations

import json
import hashlib
from collections.abc import Callable
from pathlib import Path
import re
import tomllib
from typing import cast


EXPECTED_OPERATIONS = {
    "install",
    "ingest",
    "query",
    "lint",
    "code_audit",
    "archaeology",
    "adr",
    "synthesis",
    "business_analysis",
    "system_analysis",
    "system_design",
    "development_spec",
    "notebooklm_export",
}
EXPECTED_INTENT_CONTRACT = {
    "install": (False, True, "apply_flag"),
    "ingest": (False, True, "interactive_preview_or_explicit_batch"),
    "query": (False, False, "read_only"),
    "lint": (False, True, "confirm_repairs"),
    "code_audit": (True, False, "explicit_request"),
    "archaeology": (False, True, "explicit_persist"),
    "adr": (True, False, "explicit_request"),
    "synthesis": (True, False, "explicit_request"),
    "business_analysis": (True, False, "explicit_request"),
    "system_analysis": (True, False, "explicit_request"),
    "system_design": (True, False, "explicit_request"),
    "development_spec": (True, False, "explicit_request"),
    "notebooklm_export": (False, True, "preview_then_confirm"),
}
CODE_AUDIT_CHECKS = [
    "transaction_consistency",
    "configuration_reference_consistency",
    "logic_state_consistency",
    "change_regression",
]
CODE_AUDIT_FINDING_CLASSES = ["BUG", "RISK", "BIZ"]
CODE_AUDIT_HISTORY = {
    "mode": "current_first_targeted",
    "commands": ["git log", "git show", "git blame"],
    "read_only": True,
}
CODE_AUDIT_REPORT_VALIDATOR = ".agents/skills/codebase-wiki/scripts/validate-code-audit.py"
CODE_AUDIT_WORKFLOW_TOKENS = (
    "Start with the current Codebase tree",
    "scan-project.py",
    "snapshot",
    "project-owned CI/CD",
    "Inventory every in-scope entrypoint",
    "Consult `wiki/index.md` and relevant Wiki pages only",
    "On every run, rebuild the entrypoint inventory",
    "Transactions and side effects",
    "Configuration references",
    "Logic and state contracts",
    "Change completeness",
    "git log --follow",
    "git rev-parse --is-shallow-repository",
    "git show --format=fuller --stat --patch",
    "complete body",
    "uncommitted changes",
    "preserve its original record",
    "separate Archaeology report",
    "Functional review model",
    "FUNC-UNCLASSIFIED",
    "rechecked-no-longer-observed",
)
CODE_AUDIT_SOURCE_FIRST_ADAPTERS = {
    ".github/prompts/code-audit.prompt.md": (
        "先從目前工作樹",
        "只有遇到業務規則或政策語意缺口時才查",
    ),
    "Codex.md": (
        "先從目前 Codebase 的目錄、manifest、設定與入口註冊處盤點",
        "只有遇到業務規則或政策語意缺口才查 Wiki",
    ),
}
EXPECTED_GROUPS = {
    "install_setup": ["install"],
    "ingest": ["ingest"],
    "query": ["query"],
    "lint": ["lint"],
    "code_audit": ["code_audit"],
    "adr": ["adr"],
    "synthesis": ["synthesis"],
    "business_analysis": ["business_analysis"],
    "system_analysis": ["system_analysis"],
    "system_design": ["system_design"],
    "development_spec": ["development_spec"],
    "notebooklm_export": ["notebooklm_export"],
    "archaeology": ["archaeology"],
}
CANONICAL_HOOK_ROOT = ".agents/skills/codebase-wiki/scripts/hooks/"
CODEX_SESSION_SOURCES = "startup|resume|clear|compact"
FOLLOW_UP_REFERENCE = ".agents/skills/codebase-wiki/references/follow-up-actions.md"
FOLLOW_UP_ADAPTERS = (
    ".github/prompts/query-wiki.prompt.md",
    ".github/prompts/lint-wiki.prompt.md",
    "Codex.md",
)
REMOVED_ACTIVE_PATHS = (
    ".agents/skills/codebase-wiki/references/guide-workflow.md",
    ".agents/skills/codebase-wiki/assets/guide-template.md",
    ".github/prompts/onboarding-guide.prompt.md",
    ".github/prompts/save-guide.prompt.md",
    ".github/agents/wiki-archaeologist.agent.md",
    ".github/agents/wiki-ingest.agent.md",
    ".github/agents/wiki-keeper.agent.md",
    ".github/agents/wiki-lint.agent.md",
    ".github/agents/wiki-query.agent.md",
    ".codex/agents/wiki-archaeologist.toml",
    ".codex/agents/wiki-ingest.toml",
    ".codex/agents/wiki-keeper.toml",
    ".codex/agents/wiki-lint.toml",
    ".codex/agents/wiki-query.toml",
)
REMOVED_CODEX_FANOUT_CONFIG = {
    "max_concurrent_threads_per_session": 6,
    "max_depth": 1,
}
REMOVED_LIVE_DATABASE_REFERENCE = (
    ".agents/skills/codebase-wiki/references/mssql-evidence-rules.md"
)
LIVE_DATABASE_CONTRACT_PATHS = (
    ".agents/skills/codebase-wiki/SKILL.md",
    ".agents/skills/codebase-wiki/references/intent-routing.md",
    ".agents/skills/codebase-wiki/references/query-workflow.md",
    ".agents/skills/codebase-wiki/references/synthesis-workflow.md",
    ".agents/skills/codebase-wiki/references/business-analysis-workflow.md",
    ".agents/skills/codebase-wiki/references/system-analysis-workflow.md",
    ".agents/skills/codebase-wiki/references/system-design-workflow.md",
    ".github/prompts/query-wiki.prompt.md",
    ".github/prompts/business-analysis-doc.prompt.md",
    ".github/prompts/system-analysis-doc.prompt.md",
    ".github/prompts/system-design-doc.prompt.md",
)
LIVE_DATABASE_ENABLEMENT_TOKENS = (
    "mssql",
    "sql server live evidence",
    "sql query",
    "sql queries",
    "bounded read-only `select`",
    "db live evidence",
    "db evidence",
    "database evidence block",
    "database evidence is needed",
    "exposes sql server",
    "schema discovery",
    "metadata discovery",
)
QUERY_DATABASE_BOUNDARIES = {
    ".agents/skills/codebase-wiki/references/query-workflow.md": (
        "must not connect to",
        "current database state",
    ),
}
QUERY_TGREP_BOUNDARIES = {
    ".agents/skills/codebase-wiki/references/query-workflow.md": (
        "out of scope for Query",
        "does not use tgrep",
        "CLI fallbacks",
    ),
}
SOURCE_DISCOVERY_REFERENCE = ".agents/skills/codebase-wiki/references/source-discovery-workflow.md"
TGREP_MANIFEST_PATH = ".agents/skills/codebase-wiki/bin/tgrep-manifest.json"
TGREP_BINARY_PATH = ".agents/skills/codebase-wiki/bin/windows-x64/tgrep.exe"
TGREP_SHA256 = "9b90e4446e2cbf05e1da086547501e35d7b32f0f6d5f687548cf270b07fbd9d7"
RELEASE_WORKFLOW_PATH = ".github/workflows/release.yml"
RELEASE_WORKFLOW_REQUIRED_TOKENS = (
    "name: Release",
    "on:\n  push:",
    "tags:",
    '- "v*.*.*"',
    "actions/checkout@v7",
    "actions/setup-python@v7",
    "contents: write",
    'python tools/release.py validate --tag "${GITHUB_REF_NAME}"',
    'python tools/release.py build --output dist --repository "${GITHUB_REPOSITORY}"',
    'GH_TOKEN: ${{ github.token }}',
    'gh release create "${GITHUB_REF_NAME}"',
    "--verify-tag",
    "--generate-notes",
    "dist/codebase-llm-wiki-codex.zip",
    "dist/codebase-llm-wiki-copilot.zip",
    "dist/update-manifest.json",
    "dist/SHA256SUMS",
)
RELEASE_WORKFLOW_ALLOWED_PERMISSION_NAMES = {"contents"}
TGREP_INTEGRATION = {
    "provider": "tgrep",
    "version": "1.0.5",
    "platforms": ["windows-x86_64"],
    "operations": ["ingest", "archaeology"],
    "fallback": "host-native-search",
    "index_policy": "existing-index-or-full-scan",
    "auto_index": False,
    "auto_serve": False,
    "exit_codes": {"match": 0, "no_match": 1, "error": 2},
    "writes": False,
    "query_enabled": False,
    "wrapper": ".agents/skills/codebase-wiki/scripts/tgrep-search.py",
    "manifest": TGREP_MANIFEST_PATH,
    "binary": TGREP_BINARY_PATH,
    "sha256": TGREP_SHA256,
    "upstream_release": "https://github.com/microsoft/tgrep/releases/tag/v1.0.5",
}
COPILOT_PROMPT_CONTRACT = {
    "ingest-module.prompt.md": (
        "references/ingest-workflow.md",
        "references/source-discovery-workflow.md",
        "等待確認",
        "確認前不得寫檔",
        "wiki/index.md",
        "wiki/log.md",
    ),
    "ingest-batch.prompt.md": (
        "references/ingest-workflow.md",
        "references/source-discovery-workflow.md",
        "明確授權",
        "不需要再次要求",
        "指定 scope",
        "wiki/index.md",
        "wiki/log.md",
    ),
    "query-wiki.prompt.md": (
        "references/query-workflow.md",
        "1–5",
        "零寫入",
    ),
    "lint-wiki.prompt.md": (
        "references/lint-checklist.md",
        "references/follow-up-actions.md",
        "先回報",
        "未經確認不得修復",
        "一筆 lint log",
    ),
    "code-audit.prompt.md": (
        "references/code-audit-workflow.md",
        "assets/code-audit-template.md",
        "validate-code-audit.py",
        "只回報",
        "partial",
        "BUG",
        "RISK",
        "BIZ",
        "git show",
        "transaction",
        "設定",
        "不得呼叫 tgrep",
        "wiki/index.md",
        "wiki/log.md",
    ),
    "code-archaeology.prompt.md": (
        "references/code-archaeology-workflow.md",
        "references/source-discovery-workflow.md",
        "Git evidence",
        "預設零寫入",
        "明確要求保存",
        "語意 inbound",
        "wiki/index.md",
        "wiki/log.md",
    ),
    "business-analysis-doc.prompt.md": (
        "references/business-analysis-workflow.md",
        "assets/business-analysis-template.md",
        "business-analysis-aligned-v1",
        "wiki/index.md",
        "wiki/log.md",
    ),
    "system-analysis-doc.prompt.md": (
        "references/system-analysis-workflow.md",
        "assets/system-analysis-template.md",
        "system-analysis-aligned-v1",
        "solution-neutral",
        "wiki/index.md",
        "wiki/log.md",
    ),
    "development-spec.prompt.md": (
        "references/development-spec-workflow.md",
        "assets/development-spec-template.md",
        "spec_status",
        "wiki/index.md",
        "wiki/log.md",
    ),
    "system-design-doc.prompt.md": (
        "references/system-design-workflow.md",
        "assets/system-design-template.md",
        "system-design-aligned-v1",
        "wiki/index.md",
        "wiki/log.md",
    ),
}


def markdown_frontmatter(text: str) -> dict[str, str] | None:
    """Parse scalar values from the small Markdown frontmatter adapters."""

    match = re.match(r"\A---\s*\n(.*?)\n---\s*\n", text, flags=re.DOTALL)
    if not match:
        return None
    values: dict[str, str] = {}
    for line in match.group(1).splitlines():
        field = re.match(r"^([A-Za-z][A-Za-z0-9_-]*):\s*(.*?)\s*$", line)
        if field and field.group(2):
            values[field.group(1)] = field.group(2).strip().strip("\"'")
    return values


def main() -> int:
    root = Path(__file__).resolve().parents[4]
    manifest_path = root / ".agents" / "skills" / "codebase-wiki" / "capabilities.json"
    issues: list[str] = []
    if not manifest_path.exists():
        issues.append("missing capabilities.json")
        manifest = {}
    else:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

    for relative in REMOVED_ACTIVE_PATHS:
        if (root / relative).exists():
            issues.append(f"removed active capability path is still present: {relative}")

    removed_reference = root / REMOVED_LIVE_DATABASE_REFERENCE
    if removed_reference.exists():
        issues.append(
            f"removed live-database reference is still present: {REMOVED_LIVE_DATABASE_REFERENCE}"
        )
    for relative in LIVE_DATABASE_CONTRACT_PATHS:
        path = root / relative
        if not path.is_file():
            issues.append(f"missing live-database contract surface: {relative}")
            continue
        text = path.read_text(encoding="utf-8").lower()
        for token in LIVE_DATABASE_ENABLEMENT_TOKENS:
            if token in text:
                issues.append(f"live-database query capability remains in {relative}: {token}")
    for relative, required_tokens in QUERY_DATABASE_BOUNDARIES.items():
        path = root / relative
        text = path.read_text(encoding="utf-8").lower() if path.is_file() else ""
        for token in required_tokens:
            if token.lower() not in text:
                issues.append(f"query live-database boundary missing in {relative}: {token}")
    for relative, required_tokens in QUERY_TGREP_BOUNDARIES.items():
        path = root / relative
        text = path.read_text(encoding="utf-8").lower() if path.is_file() else ""
        for token in required_tokens:
            if token.lower() not in text:
                issues.append(f"query tgrep boundary missing in {relative}: {token}")

    integrations = manifest.get("integrations", {})
    source_discovery = integrations.get("source_discovery") if isinstance(integrations, dict) else None
    if source_discovery != TGREP_INTEGRATION:
        issues.append("tgrep source_discovery integration metadata drifted")
    project_scanner = integrations.get("project_scanner") if isinstance(integrations, dict) else None
    if not isinstance(project_scanner, dict) or project_scanner.get("version") != "2":
        issues.append("project_scanner integration metadata is missing or stale")
    else:
        for relative in (project_scanner.get("wrapper"), project_scanner.get("module")):
            if not relative or not (root / relative).is_file():
                issues.append(f"missing project scanner surface: {relative}")
    for relative in (SOURCE_DISCOVERY_REFERENCE, TGREP_MANIFEST_PATH, TGREP_BINARY_PATH, TGREP_INTEGRATION["wrapper"]):
        if not (root / relative).is_file():
            issues.append(f"missing tgrep integration surface: {relative}")
    tgrep_manifest_path = root / TGREP_MANIFEST_PATH
    if tgrep_manifest_path.is_file():
        try:
            tgrep_manifest = json.loads(tgrep_manifest_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            issues.append(f"invalid tgrep manifest: {exc}")
            tgrep_manifest = {}
        expected_manifest = {
            "schema_version": 1,
            "tool": "tgrep",
            "version": "1.0.5",
            "platform": "windows-x86_64",
            "binary": "bin/windows-x64/tgrep.exe",
            "sha256": TGREP_SHA256,
            "upstream_release": "https://github.com/microsoft/tgrep/releases/tag/v1.0.5",
        }
        if tgrep_manifest != expected_manifest:
            issues.append("tgrep bundle manifest metadata drifted")
    tgrep_binary_path = root / TGREP_BINARY_PATH
    if tgrep_binary_path.is_file():
        digest = hashlib.sha256(tgrep_binary_path.read_bytes()).hexdigest()
        if digest != TGREP_SHA256:
            issues.append("bundled tgrep binary SHA-256 mismatch")

    for surface in ("copilot", "codex"):
        if surface not in manifest.get("surfaces", []):
            issues.append(f"manifest missing surface: {surface}")
    if manifest.get("contract_version") != 6:
        issues.append("manifest contract_version must be 6")
    guard_modes = manifest.get("guard_modes", {})
    if guard_modes.get("default") != "wiki-only" or guard_modes.get("installed") != [
        "wiki-only",
        "coexist",
    ]:
        issues.append("manifest guard mode contract is incomplete")

    intents = manifest.get("intents", {})
    if not isinstance(intents, dict) or set(intents) != EXPECTED_OPERATIONS:
        issues.append("manifest intents must define the thirteen canonical operations")
        intents = {}
    for operation, expected in EXPECTED_INTENT_CONTRACT.items():
        contract = intents.get(operation, {})
        actual = (
            contract.get("writes_by_default"),
            contract.get("requires_confirmation"),
            contract.get("authorization_policy"),
        )
        if actual != expected:
            issues.append(f"authorization drift: {operation}")

    audit_contract = intents.get("code_audit", {})
    if audit_contract.get("checks") != CODE_AUDIT_CHECKS:
        issues.append("Codebase audit checks contract is incomplete or reordered")
    if audit_contract.get("finding_classes") != CODE_AUDIT_FINDING_CLASSES:
        issues.append("Codebase audit finding classes must be BUG/RISK/BIZ")
    if audit_contract.get("scan_profiles") != ["target", "framework"]:
        issues.append("Codebase audit scan profiles must be target/framework")
    if audit_contract.get("history") != CODE_AUDIT_HISTORY:
        issues.append("Codebase audit Git history contract is incomplete")
    if audit_contract.get("report_validator") != CODE_AUDIT_REPORT_VALIDATOR:
        issues.append("Codebase audit report validator path is not canonical")

    groups = manifest.get("intent_groups", {})
    if groups != EXPECTED_GROUPS:
        issues.append("manifest must define the exact thirteen user-facing intent groups")
        groups = {}
    grouped = [operation for values in groups.values() if isinstance(values, list) for operation in values]
    if len(grouped) != len(set(grouped)) or set(grouped) != EXPECTED_OPERATIONS:
        issues.append("intent_groups must cover each canonical operation exactly once")

    entrypoints = manifest.get("entrypoints", {})
    copilot_entrypoints = entrypoints.get("copilot", {}) if isinstance(entrypoints, dict) else {}
    if set(copilot_entrypoints) != EXPECTED_OPERATIONS:
        issues.append("Copilot entrypoint mapping must cover every operation")
    else:
        for operation, filenames in copilot_entrypoints.items():
            if not isinstance(filenames, list):
                issues.append(f"Copilot entrypoints must be arrays: {operation}")
                continue
            for filename in filenames:
                if not (root / ".github" / "prompts" / filename).is_file():
                    issues.append(f"missing Copilot prompt: {filename}")
    for path in (root / ".github" / "prompts").glob("*.prompt.md"):
        relative = path.relative_to(root).as_posix()
        text = path.read_text(encoding="utf-8")
        frontmatter = markdown_frontmatter(text)
        if frontmatter is None:
            issues.append(f"Copilot prompt has no parseable frontmatter: {relative}")
            continue
        expected_name = path.name.removesuffix(".prompt.md")
        if frontmatter.get("name") != expected_name:
            issues.append(f"Copilot prompt name must match filename: {relative}")
        for field in ("description", "agent", "argument-hint"):
            if not frontmatter.get(field):
                issues.append(f"Copilot prompt missing {field}: {relative}")
        agent = frontmatter.get("agent", "")
        if agent and agent != "agent":
            issues.append(f"Copilot prompt must use built-in agent: {relative}")
    for filename, required_tokens in COPILOT_PROMPT_CONTRACT.items():
        path = root / ".github" / "prompts" / filename
        text = path.read_text(encoding="utf-8") if path.is_file() else ""
        for token in required_tokens:
            if token not in text:
                issues.append(f"Copilot workflow contract missing {token}: {filename}")
    recipe_document = entrypoints.get("codex", {}).get("recipe_document", "")
    if recipe_document != "Codex.md" or not (root / recipe_document).is_file():
        issues.append("Codex recipe document must be Codex.md")
    for relative in (
        ".agents/skills/codebase-wiki/references/ingest-workflow.md",
        ".agents/skills/codebase-wiki/references/code-archaeology-workflow.md",
    ):
        path = root / relative
        text = path.read_text(encoding="utf-8") if path.is_file() else ""
        if SOURCE_DISCOVERY_REFERENCE not in text and "source-discovery-workflow.md" not in text:
            issues.append(f"workflow missing source-discovery reference: {relative}")
    audit_workflow = root / ".agents/skills/codebase-wiki/references/code-audit-workflow.md"
    if not audit_workflow.is_file():
        issues.append("missing Codebase audit workflow")
    else:
        audit_workflow_text = audit_workflow.read_text(encoding="utf-8")
        if "do not use the optional tgrep wrapper" not in audit_workflow_text.lower():
            issues.append("Codebase audit must stay outside the tgrep source-discovery contract")
        audit_workflow_normalized = " ".join(audit_workflow_text.split()).lower()
        for token in CODE_AUDIT_WORKFLOW_TOKENS:
            if token.lower() not in audit_workflow_normalized:
                issues.append(f"Codebase audit workflow missing check: {token}")
        source_first = audit_workflow_text.find("Start with the current Codebase tree")
        wiki_context = audit_workflow_text.find(
            "Consult `wiki/index.md` and relevant Wiki pages only"
        )
        if source_first == -1 or wiki_context == -1 or source_first > wiki_context:
            issues.append("Codebase audit workflow must inventory current Codebase before Wiki context")
        if "An empty, stale, incomplete, or\n   missing Wiki must not reduce this discovery scope." not in audit_workflow_text:
            issues.append("Codebase audit workflow must keep discovery independent of Wiki coverage")
    skill_path = root / ".agents/skills/codebase-wiki/SKILL.md"
    skill_text = skill_path.read_text(encoding="utf-8") if skill_path.is_file() else ""
    if "Codebase audit is the explicit" not in skill_text or "current-source-first exception" not in skill_text:
        issues.append("shared Skill must declare the Codebase audit source-first exception")
    target_block_path = root / ".agents/skills/codebase-wiki/assets/target-agents-block.md"
    target_block_text = (
        target_block_path.read_text(encoding="utf-8")
        if target_block_path.is_file()
        else ""
    )
    if (
        "Codebase audit starts with the current Codebase tree and" not in target_block_text
        or "Wiki pages never define the audit scan boundary" not in target_block_text
    ):
        issues.append("installed root instructions must declare the Codebase audit source-first exception")
    if "Read `wiki/index.md` and relevant pages before raw sources." in target_block_text:
        issues.append("installed root instructions still require Wiki-first audit discovery")
    audit_template = root / ".agents/skills/codebase-wiki/assets/code-audit-template.md"
    if not audit_template.is_file():
        issues.append("missing Codebase audit report template")
    else:
        audit_template_text = audit_template.read_text(encoding="utf-8")
        if 'source_digest: "sha256:' not in audit_template_text:
            issues.append("Codebase audit report template must include its source digest")
        if (
            "audit_report_version: 4" not in audit_template_text
            or "scan_schema_version: 2" not in audit_template_text
            or "scan_profile: target" not in audit_template_text
            or "## 功能 Review" not in audit_template_text
            or "## 檔案處置" not in audit_template_text
        ):
            issues.append("Codebase audit report template must include the v4 scanner-bound review contract")
    validator = root / CODE_AUDIT_REPORT_VALIDATOR
    if not validator.is_file():
        issues.append("missing Codebase audit report validator")
    else:
        validator_text = validator.read_text(encoding="utf-8")
        for token in (
            "duplicate finding ID",
            "Git history section",
            "source does not exist",
            "入口覆蓋 counts do not match",
            "affected entrypoint is missing",
            "historical evidence must name a diff/blame location",
            "unknown function ID",
            "affected function/entrypoint association is missing",
            "finding rerun-state counts do not match",
            "plain-language",
            "case input/operation field",
            "P0",
            "merge commit",
        ):
            if token not in validator_text:
                issues.append(f"Codebase audit validator missing check: {token}")
    codex_text = (root / "Codex.md").read_text(encoding="utf-8") if (root / "Codex.md").is_file() else ""
    for token in (
        SOURCE_DISCOVERY_REFERENCE,
        "Query does not invoke the optional tgrep",
        "never starts `index` or `serve`",
    ):
        if token not in codex_text:
            issues.append(f"Codex recipe missing tgrep boundary: {token}")
    audit_prompt = root / ".github" / "prompts" / "code-audit.prompt.md"
    adapter_texts = {
        ".github/prompts/code-audit.prompt.md": audit_prompt.read_text(encoding="utf-8")
        if audit_prompt.is_file()
        else "",
        "Codex.md": (
            codex_text.split("Codebase audit:", 1)[1].split("Business analysis document:", 1)[0]
            if "Codebase audit:" in codex_text and "Business analysis document:" in codex_text
            else ""
        ),
    }
    for relative, (source_marker, wiki_marker) in CODE_AUDIT_SOURCE_FIRST_ADAPTERS.items():
        adapter_text = adapter_texts[relative]
        source_position = adapter_text.find(source_marker)
        wiki_position = adapter_text.find(wiki_marker)
        if source_position == -1 or wiki_position == -1 or source_position > wiki_position:
            issues.append(
                f"Codebase audit adapter must inventory current source before Wiki context: {relative}"
            )
        if "先讀少量相關 Wiki，再盤點" in adapter_text or "先查 Wiki，再盤點" in adapter_text:
            issues.append(f"Codebase audit adapter still uses Wiki-first discovery wording: {relative}")

    cli = manifest.get("cli", {})
    if not isinstance(cli, dict):
        issues.append("manifest cli must be an object")
        cli = {}
    for action in ("install", "upgrade"):
        command = cli.get(action, "")
        if not isinstance(command, str) or f"install-framework.py {action}" not in command:
            issues.append(f"manifest missing installer command: {action}")
    stale_runtime_commands = sorted(set(cli) & {"setup", "doctor", "index", "search", "show"})
    if stale_runtime_commands:
        issues.append("manifest retains removed runtime commands: " + ", ".join(stale_runtime_commands))
    for path in (
        root / ".agents" / "skills" / "codebase-wiki" / "SKILL.md",
        root / ".agents" / "skills" / "codebase-wiki" / "scripts" / "install-framework.py",
        root / ".github" / "copilot-instructions.md",
        root / "AGENTS.md",
    ):
        if not path.exists():
            issues.append(f"missing required surface: {path.relative_to(root).as_posix()}")

    follow_up_reference = root / FOLLOW_UP_REFERENCE
    if not follow_up_reference.is_file():
        issues.append(f"missing shared follow-up contract: {FOLLOW_UP_REFERENCE}")
    for relative in FOLLOW_UP_ADAPTERS:
        path = root / relative
        text = path.read_text(encoding="utf-8") if path.is_file() else ""
        if FOLLOW_UP_REFERENCE not in text.replace("\\", "/"):
            issues.append(f"surface missing follow-up contract: {relative}")

    for hook_name in ("wiki-session-init.py", "wiki-write-guard.py", "wiki-log-reminder.py"):
        if not (root / CANONICAL_HOOK_ROOT / hook_name).is_file():
            issues.append(f"missing canonical hook: {hook_name}")
    for legacy_root in (
        root / ".codex" / "hooks" / "scripts",
        root / ".github" / "hooks" / "scripts",
    ):
        if legacy_root.is_dir() and any(legacy_root.glob("*.py")):
            issues.append(f"legacy hook mirrors remain: {legacy_root.relative_to(root)}")
    hook_configs = {
        root / ".codex" / "hooks.json": "--platform codex",
        root / ".github" / "hooks" / "wiki-session-init.json": "--platform copilot",
        root / ".github" / "hooks" / "wiki-write-guard.json": "--platform copilot",
        root / ".github" / "hooks" / "wiki-log-reminder.json": "--platform copilot",
    }
    for path, platform_argument in hook_configs.items():
        text = path.read_text(encoding="utf-8") if path.is_file() else ""
        if CANONICAL_HOOK_ROOT not in text.replace("\\", "/") or platform_argument not in text:
            issues.append(f"hook config does not use canonical implementation: {path.relative_to(root)}")

    codex_hooks_path = root / ".codex" / "hooks.json"
    if codex_hooks_path.is_file():
        try:
            codex_hooks = json.loads(codex_hooks_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            issues.append(f"invalid Codex hooks JSON: {exc}")
            codex_hooks = {}
        for event_name in ("SessionStart", "PreToolUse", "PostToolUse"):
            groups = codex_hooks.get("hooks", {}).get(event_name, [])
            for group in groups:
                for handler in group.get("hooks", []):
                    command = handler.get("command", "")
                    if not command.startswith('python "$(git rev-parse --show-toplevel'):
                        issues.append(
                            f"Codex {event_name} command must resolve the Git root"
                        )
                    if "2>/dev/null || pwd" not in command:
                        issues.append(f"Codex {event_name} command must fall back to pwd")
                    command_windows = handler.get("commandWindows", "")
                    if not command_windows.startswith(
                        "powershell.exe -NoProfile -NonInteractive -Command"
                    ):
                        issues.append(
                            f"Codex {event_name} commandWindows must use the PowerShell wrapper"
                        )
                    for token in (
                        "$wikiRoot",
                        "git rev-parse --show-toplevel",
                        "Get-Location",
                        "Join-Path",
                    ):
                        if token not in command_windows:
                            issues.append(
                                f"Codex {event_name} commandWindows missing root resolver: {token}"
                            )
                    if CANONICAL_HOOK_ROOT not in command_windows.replace("\\", "/"):
                        issues.append(
                            f"Codex {event_name} commandWindows must use the canonical hook"
                        )
        session_groups = codex_hooks.get("hooks", {}).get("SessionStart", [])
        session_matchers = {str(group.get("matcher", "")) for group in session_groups}
        if CODEX_SESSION_SOURCES not in session_matchers:
            issues.append(
                "Codex SessionStart matcher must cover startup, resume, clear, and compact"
            )

    config_path = root / ".codex" / "config.toml"
    try:
        codex_config = tomllib.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError) as exc:
        issues.append(f"invalid Codex config: {exc}")
        codex_config = {}
    agents_config = codex_config.get("agents", {})
    if isinstance(agents_config, dict) and all(
        agents_config.get(key) == value
        for key, value in REMOVED_CODEX_FANOUT_CONFIG.items()
    ):
        issues.append("removed framework Codex agent fan-out config is still present")

    # The exact ten retired Wiki profiles are already enforced through
    # REMOVED_ACTIVE_PATHS. Other names belong to the platform-native extension
    # surface and are deliberately outside this framework removal.

    installer_namespace: dict[str, object] = {
        "__file__": str(root / ".agents/skills/codebase-wiki/scripts/install-framework.py"),
        "__name__": "__installer_parity__",
    }
    installer_path = root / ".agents/skills/codebase-wiki/scripts/install-framework.py"
    exec(compile(installer_path.read_text(encoding="utf-8"), str(installer_path), "exec"), installer_namespace)
    surface_files = cast(
        Callable[..., list[tuple[Path, str]]], installer_namespace["_surface_files"]
    )
    for surface in ("copilot", "codex"):
        planned = [relative for _, relative in surface_files(root, surface, "install")]
        if RELEASE_WORKFLOW_PATH in planned:
            issues.append(
                f"framework-only release workflow must not be installed: {surface}"
            )
        leaked = [
            path
            for path in planned
            if path.startswith(".agents/skills/")
            and not path.startswith(".agents/skills/codebase-wiki/")
        ]
        if leaked:
            issues.append(f"{surface} installer leaks unrelated Skills: {', '.join(leaked)}")

    for directory in (root / ".github", root / ".codex"):
        for path in directory.rglob("*") if directory.exists() else ():
            if path.is_file() and path.suffix in {".md", ".toml", ".json", ".py"}:
                # Hook audit logs are generated state, not executable entrypoint
                # instructions. They may retain historical references and must
                # not make the current surface parity check fail.
                relative_parts = path.relative_to(root).parts
                if "logs" in relative_parts:
                    continue
                text = path.read_text(encoding="utf-8", errors="replace")
                if ".github/skills" in text or ".github\\skills" in text:
                    issues.append(f"stale mirrored skill reference: {path.relative_to(root).as_posix()}")
    workflow_root = root / ".github" / "workflows"
    workflows = sorted(
        path.relative_to(root).as_posix()
        for suffix in ("*.yml", "*.yaml")
        for path in workflow_root.glob(suffix)
    )
    if workflows != [RELEASE_WORKFLOW_PATH]:
        issues.append(
            "GitHub workflow files must contain only the release workflow: "
            + ", ".join(workflows)
        )
    release_workflow = root / RELEASE_WORKFLOW_PATH
    if release_workflow.is_file():
        workflow_text = release_workflow.read_text(encoding="utf-8")
        for token in RELEASE_WORKFLOW_REQUIRED_TOKENS:
            if token not in workflow_text:
                issues.append(f"release workflow contract missing {token!r}")
        permission_names = {
            match.group(1)
            for match in re.finditer(
                r"(?m)^\s+([A-Za-z0-9_-]+):\s+(?:read|write|none)\s*$",
                workflow_text,
            )
        }
        unexpected_permissions = sorted(
            permission_names - RELEASE_WORKFLOW_ALLOWED_PERMISSION_NAMES
        )
        if unexpected_permissions:
            issues.append(
                "release workflow grants unexpected permissions: "
                + ", ".join(unexpected_permissions)
            )
        if "workflow_dispatch" in workflow_text:
            issues.append("release workflow must be tag-triggered only")
        if "dist/*" in workflow_text:
            issues.append("release workflow must list exact assets, not dist/*")
    payload = {"ok": not issues, "contract_version": manifest.get("contract_version", 0), "issues": issues}
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if not issues else 1


if __name__ == "__main__":
    raise SystemExit(main())
