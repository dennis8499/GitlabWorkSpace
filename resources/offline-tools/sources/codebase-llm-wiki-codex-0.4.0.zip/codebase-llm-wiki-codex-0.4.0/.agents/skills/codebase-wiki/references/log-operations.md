# Wiki Log Operations

Use this file as the source of truth for the `{operation}` field in
`wiki/log.md` entries.

## Format

```markdown
## [YYYY-MM-DD] {operation} | {subject}

- Change summary
- Affected pages: [[page-a]], [[page-b]]
```

`wiki/log.md` is append-only. Do not delete or rewrite existing entries.

Newly initialized logs include `<!-- codebase-wiki:log-contract-v1 -->`. Every
entry after that marker must include `Affected pages:` or `受影響頁面：` with at
least one resolvable `[[wikilink]]`. `last_updated` must not precede the newest
entry, dates are nondecreasing, and `validate-log.py` compares existing body
content with the Git baseline when available. Pre-marker legacy omissions are
reported as warnings and are never rewritten.

## Allowed Operations

| Operation | Use when |
| --- | --- |
| `ingest` | Raw source evidence was read and wiki pages were created or updated. |
| `query` | A query result was saved or materially changed wiki knowledge. Pure chat answers do not need a log entry. |
| `lint` | Wiki health checks or accepted lint repairs changed wiki state. |
| `update` | Schema, index, hooks, documentation, or framework maintenance changed durable repo behavior. |
| `init` | Initial wiki skeleton or first-time framework setup was created. |
| `adr` | An Architecture Decision Record was created or materially updated. |
| `synthesis` | Durable cross-cutting analysis or a BA／SA／SD document was saved under `wiki/synthesis/`. |
| `guide` | Legacy compatibility for existing Guide history; no active creator workflow emits new entries. |
| `archaeology` | Git history or legacy behavior findings were persisted to wiki pages. |

## Operation Selection

- Use `synthesis` for standalone BA／SA／SD documents because their output lives
  under `wiki/synthesis/`.
- Use `query` only when a query result is persisted; normal read-only query
  answers do not modify `wiki/log.md`.
- Use `update` for framework schema maintenance that changes instructions,
  hooks, scripts, prompts, or documentation without changing wiki content pages.
