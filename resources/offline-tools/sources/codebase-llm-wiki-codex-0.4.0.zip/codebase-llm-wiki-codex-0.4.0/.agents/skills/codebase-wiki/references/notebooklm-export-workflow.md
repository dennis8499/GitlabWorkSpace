# NotebookLM Enterprise Current-state BA／SA Export Workflow

Use this workflow for NotebookLM export preparation. The fixed outcome is one
NotebookLM Enterprise notebook whose static sources contain current-state BA
and SA documents derived from the full safe codebase.

Schema v6 uses knowledge contract `codebase-ba-sa-v1` and retrieval contract
`codebase-ba-sa-retrieval-v1`.

## Scope and authorization

Raw source code, configuration, behavioral tests, schemas, and project docs are
read-only analysis inputs. Wiki pages and the repository-local `.notebooklm/`
pack are the only writable surfaces. The workflow is offline: it does not call
NotebookLM, Google Cloud DLP, or an upload API.

The first phase is always read-only and always scans the full safe project
scope. Existing Wiki pages are the knowledge baseline, not a boundary on raw
discovery. Even when the Wiki is clean, show the functional-requirement,
process, rule, and file-disposition coverage preview
and wait for confirmation before updating Wiki or writing the local pack.

The displayed discovery plan has one human confirmation（一次確認）. After that
confirmation, full analysis, Wiki regeneration, readiness checks, and local
apply run without another approval gate. The codebase is the only content
authority, including README, specifications, tests, and comments; when sources
conflict, implemented code wins and the documents record the difference.

After confirmation, re-analyze the entire safe scope and regenerate managed BA／SA
sections; do not limit work to previously stale pages. Preserve user-authored
notes, synchronize `wiki/index.md`, and append one valid operation selected from
`log-operations.md` (normally `ingest`, or `update` for framework maintenance)
covering the complete preparation. Raw project sources remain read-only.

## Safe project scope

Include every UTF-8 project-owned text file in these categories:

- runtime source and production entrypoints;
- runtime-required config and dependency manifests;
- database schemas, migrations, messages, and interface schemas;
- existing README, specifications, and project documentation;
- behavioral tests and acceptance specifications (included by default).
- project-owned CI/CD, IaC, deployment manifests, engineering scripts, tools,
  examples, and bin entrypoints that explain system operation.

`notebooklm.toml` may designate exact repo-relative UTF-8 files or directories
as `business_source_paths`. These are business-owned requirements, process
definitions, decision tables, or acceptance specifications. They may opt
selected text into the scan from dev-tooling scope, but never override
secret, binary/generated/dependency, configured exclusion, Wiki, output, or
symlink/reparse safety boundaries. PDF, Word,
and Excel are not parsed in v1;
record them as explicit knowledge gaps.

Exclude dependency and generated directories, binaries, credentials/secrets,
the Wiki, export output, and installed Codebase LLM Wiki adapter/schema files.
Classify project-owned CI/CD, IaC, and engineering tooling as evidence rather
than excluding them by directory name. Versioned product
requirements, historical change summaries, and plans remain normal
documentation inputs. A production entrypoint is
runtime source even if it lives under a scripts directory. Walk the filesystem
top-down beneath the explicit `--root`, pruning an excluded directory before
enumerating its descendants; this keeps the fallback bounded without dropping
ignored, untracked, or nested-repository runtime source. Git status, a clean
worktree, or a root `.git` are not prerequisites. Nested repositories are
ordinary subdirectories: their project files follow the same rules, while
their `.git` metadata remains excluded as generated state. Each pruned root is
reported as a directory-level exclusion with bounded metadata-only counts; the
report never reads or hashes content from that tree.

Set `analysis_include_tests = false` only when the user explicitly narrows the
analysis contract. Every included safe file must be classified in
`wiki/synthesis/codebase-functional-coverage.md` as `functional-evidence`,
`supporting-technical`, `no-observable-behavior`, or `analysis-gap`. Coverage
schema v2 records the exact path, scanner SHA-256, category, function/process
association, and disposition reason; a directory prefix or stale hash never
satisfies the gate. Export is blocked for uncovered files, any remaining
`analysis-gap`, a missing required functional-requirement link, or a dangling
requirement link.

## Source order

1. Run the shared source-first inventory before using Wiki coverage:

   ```powershell
   python .agents\skills\codebase-wiki\scripts\scan-project.py `
     --root . --profile target --format json
   ```

   The returned `snapshot_id` binds every file hash, category, exclusion, read
   issue, and entrypoint candidate to this discovery. The scanner includes
   nested repositories and ignored/untracked files under the explicit root.
2. Read `wiki/index.md` and every Wiki Markdown page except `wiki/log.md`.
3. Run the deterministic frontmatter, stale-source, and Wiki lint checks.
   NotebookLM preflight keeps the structural and content checks but disables
   Git dirty-path, commit-date, and log-baseline lookups; the preflight remains
   filesystem-only.
4. Run the read-only exporter preflight:

   ```powershell
   python .agents\skills\codebase-wiki\scripts\export-notebooklm.py `
     --root . --preflight --format json
   ```

Treat this first result as the discovery preflight. Its `discovery_id` binds raw
safe sources, exclusion policy, scan configuration, and semantic contracts; Wiki
bytes are deliberately excluded so regenerated documentation does not invalidate
the user's confirmed source scope. `ready_to_export` is true only when all
mandatory BA／SA documents are active, the structural contract and full
file-disposition ledger are complete,
required-document evidence is fresh, deterministic lint has no Critical
findings, and the exact post-mask payload fits the configured limits.

4. Read designated business sources first, then project documentation,
   use-case entrypoints, orchestration/services, state/data boundaries,
   messages, public interfaces, and integrations. Identify functional
   requirements by observable behavior, then trace every end-to-end process
   from its entrypoint through the actual call chain. For each step record the
   trigger or condition, actor, operation, data read/write, state before and
   after, success result, blocking condition, failure destination, retry or
   rollback behavior, and a source locator. Connect actor, precondition,
   outcome, rule, exception, state transition, and stable acceptance criteria
   across capability boundaries; do not replace the trace with a short
   directory summary or a four-step outline.
5. Preview included file counts and reasons, pruned excluded-root counts and
   bounded metadata summaries, requirement/capability/process/rule/term
   coverage, Wiki pages to regenerate, disposition results, capacity estimate, and every
   unresolved gap. A truncated or unreadable excluded-root summary is a
   warning, not evidence that the root was included. Wait for confirmation.
6. After confirmation, create or update the required current-state documentation set:
   - `wiki/overview.md`;
   - `wiki/synthesis/functional-requirement-catalog.md`;
   - `wiki/synthesis/business-process-catalog.md`;
   - `wiki/synthesis/business-rule-catalog.md`;
   - `wiki/synthesis/business-glossary.md`;
   - `wiki/synthesis/business-knowledge-gaps.md`;
   - `wiki/synthesis/codebase-functional-coverage.md` (local-only gate);
   - one `wiki/requirements/` page per independently testable capability;
   - one `wiki/processes/` page per cataloged end-to-end process;
   - one `wiki/rules/` page per independently queryable business rule.
   For every active `cap-*`, also create exactly
   `wiki/synthesis/{cap}-ba.md` from `notebooklm-ba-template.md` and
   `wiki/synthesis/{cap}-sa.md` from `notebooklm-sa-template.md`. These export
   profiles are current-state codebase documents. Standalone BA/SA and System
   Design retain their separate workflows and do not become upload candidates.
7. Each requirement uses stable `fr-*` and `cap-*` IDs, links at least one
   process, and contains `## 驗收條件` with stable `AC-*` IDs. Use stable
   `business-{capability}` `notebooklm_group` values. Capability BA uses
   `codebase-business-analysis-v1`, `notebooklm_document: ba`, role `business`;
   capability SA uses `codebase-system-analysis-v1`, `notebooklm_document: sa`,
   role `analysis`. Both declare real sources and `path:line` locators, link each
   other, and use Traditional Chinese while retaining identifiers/API names.
8. Label claims as `business-confirmed`, `implementation-observed`, `inference`,
   or `gap`. Track the analysis state separately from evidence coverage:
   `analysis-gap` means the call chain has not been traced to completion and
   blocks export; `evidence-gap` means the sources were checked but do not
   provide the fact; `business-confirmation` means implementation behavior is
   observable but an operational policy, owner, approval role, retry right, or
   SLA still needs business confirmation. Code/config/schema can prove
   observed behavior, not approved policy. When the repository supplies no
   evidence, write exactly `Codebase 未提供證據`; do not use that phrase to
   hide an unfinished analysis.
9. Regenerate content inside `codebase-wiki:managed` markers, preserve content
   inside `codebase-wiki:user-notes` markers, and place reviewer-only paths or
   symbols inside `notebooklm:local-only` markers. Synchronize index/log and
   rerun Wiki checks. Before declaring readiness, verify the exact masked
   `sources/*.md` payload: every active evidence-backed process must retain
   its concrete steps, conditions, data/state changes, branches, and applicable
   requirement/rule bodies. A title, a four-step summary, or a rule link without
   the rule text fails this check. Record the confirmed discovery ID in the
   coverage ledger only after the full snapshot is processed. Then run a
   readiness preflight and use its new ID for apply:

   ```powershell
   python .agents\skills\codebase-wiki\scripts\export-notebooklm.py `
     --root . --preflight --format json
   ```

10. Check the readiness result, exact `pack_plan`, capacity, DLP masking status,
    and migration mode automatically. Do not request another confirmation. Apply
    with the confirmed discovery ID and latest readiness ID:

   ```powershell
   python .agents\skills\codebase-wiki\scripts\export-notebooklm.py `
     --root . --apply --discovery-id <confirmed-id> `
     --preflight-id <latest-id> --output .notebooklm --format json
   ```

   Apply rescans the Wiki, safe inventory, and configuration. Raw/config/scope
   drift requires a new preview and confirmation; Wiki-only rebuilds retain the
   discovery ID and use a new readiness ID. Direct export without
   `--preflight` followed by `--apply` is rejected.

## Output contract

The exporter owns `.notebooklm/manifest.json`, `.notebooklm/upload-plan.md`,
`.notebooklm/README.md`, local-only `.notebooklm/governance.md`, complete
`.notebooklm/documents/{cap}-ba.md`／`-sa.md`, and upload candidates in
`.notebooklm/sources/*.md`. Unknown files inside the output directory are preserved.

Each generated source has a stable `logical_source_id`:

- `query-index` for the BA／SA capability router;
- `project-map` for the generated navigation source;
- `shared-business-context` for the shared glossary, process catalog, and
  active evidence-backed cross-capability process bodies, with applicable
  requirement and rule 正文 included for independent reading;
- `capability:<capability-id>` for one complete BA／SA pair;
- `capability:combined` only when slot pressure requires lossless compaction;
- `#part-###` suffixes for sources split at safe boundaries.

Each document records its role, export profile, capability, group, locators,
hashes, and upload paths in `document_source_mapping`. Both BA and SA map to all
source parts that contain their paired capability.

The exporter accepts previous schema-v1 through v5 manifests. The first export
from an older schema or retrieval contract sets
`migration.requires_full_rebuild=true` and
instructs the uploader to remove all old static sources before uploading the new
pack. The schema-v6 manifest records audience `business-and-system-analyst`, source roles,
functional/business coverage, and scan summary, including
file-level exclusions and pruned excluded-root summaries,
requirement/process/rule coverage, file dispositions, input/output hashes,
limits, the offline DLP profile/safe finding summary, and the
`codebase-ba-sa-retrieval-v1` retrieval contract. The retrieval contract points
to `query-index.md`, limits the primary route to at most five source groups, and
keeps the copy/paste Custom instructions in the local README. The upload plan
contains:

- `added`: upload the new source;
- `changed`: remove the old static source, then upload the replacement;
- `deleted`: remove the old source;
- `unchanged`: no NotebookLM action.

Only upload `sources/*.md`. Do not upload `documents/`, `manifest.json`,
`upload-plan.md`, `governance.md`, or the README as Notebook sources.

The generated README also documents a one-time rebuild procedure: remove old
static sources from the same NotebookLM notebook, upload every Markdown file
under `sources/`, and apply the Custom instructions when the tenant UI exposes
them. The exporter remains offline and does not delete or upload cloud sources.

## Limits and safety

The default Enterprise profile is bounded to 300 sources, 500 MB per source,
and 500,000 words per source. The exporter uses lower safety defaults of 450 MB
and 450,000 estimated words, supports `reserved_source_slots`, and rejects any
configuration above the Enterprise hard limits. `estimated_words` uses the
`han_characters_plus_non_han_tokens` model: Han/CJK characters are counted
individually and non-Han, non-whitespace token runs are counted separately, so
mixed Traditional Chinese and code content is not underestimated. A different
Workspace tier must lower `source_limit` in `notebooklm.toml`.

The query index, project map, shared business context, and every capability
BA／SA pair are mandatory. Raw business
evidence, source code, configuration, and technical traceability are never
direct upload candidates. If complete BA／SA content cannot fit, combine/split it
losslessly or fail; never omit a capability or required content.

Excluded-root summaries use a fixed metadata entry bound. They may report
`truncated` or metadata errors, but they never inspect file content and do not
turn excluded files into evidence.

If mandatory documentation cannot fit after deterministic compaction/splitting,
or any source remains oversized, the exporter fails before committing a new
pack and preserves the previous pack.

The final-source flow-integrity check runs after masking and splitting, against
the exact bytes planned for `sources/`. It blocks an unfinished trace, a
process whose concrete content is absent, a missing failure branch, or an
applicable rule that is represented only by a title or Wiki link. It reports
structural content and traceability coverage; it does not claim that NotebookLM
will answer every question correctly, which still requires tenant-side
question-and-answer validation.

`notebooklm.toml` may set `scan_profile = "target" | "framework"`,
`content_mode = "ba_sa"`, `analysis_include_tests`, and
`business_source_paths`. Schema v6 rejects `ba_only` with full-rebuild guidance
and rejects legacy `include_traceability`,
`include_evidence`, and `dlp_allowlist` settings with a migration message.
`target` is
the default and excludes installed framework adapters. The framework repository
uses `framework`, which treats its `.agents`, `.codex`, non-CI `.github`, and
release tooling as product evidence while retaining secret/generated/CI
exclusions. The target adapter boundary covers `.agents/skills/codebase-wiki`,
`.codex`, `.github/prompts`, `.github/hooks`, `.github/instructions`, and managed
Copilot instruction files; project-owned `.github/workflows` remains evidence.
The standalone scanner and exporter share the scanner-owned configuration parser:
an unreadable, malformed, mistyped, or path-escaping `notebooklm.toml` fails closed
before a source inventory is accepted. A symlink/reparse `notebooklm.toml` is
rejected before reading configuration.

## Offline DLP masking

The exporter runs a local deterministic DLP profile during analysis, final
`documents/` materialization, and exact `sources/` planning. It does not call
Google Cloud, Model Armor, or NotebookLM. The
`notebooklm-enterprise-ba-sa-mask-v1` profile checks high-confidence
`CREDIT_CARD_NUMBER`, `FINANCIAL_ACCOUNT_NUMBER`, `GCP_CREDENTIALS`,
`GCP_API_KEY`, and `PASSWORD` patterns. Existing sensitive filename exclusions
remain a separate safety layer.

Analysis operates on an in-memory copy and replaces matches with
`[MASKED:<RULE>]`; raw repository files are never modified. Documents and upload
sources are masked, hashed, and independently rescanned; any residual finding blocks commit and preserves
the previous pack. Reports contain only path, line, rule, severity, and a
SHA-256 fingerprint; matched values and surrounding text are never persisted.
There is no allowlist.

The local-only `governance.md` separates local checks from tenant-admin
verification for IAM, VPC Service Controls, CMEK, data location, and Sensitive
Data Protection. Sensitive Data Protection governs source content; Model Armor
governs prompt/response interaction when applicable. Neither is declared enabled
without tenant evidence. Verify the current [Google Cloud Gemini Notebook Enterprise limits](https://docs.cloud.google.com/gemini/enterprise/notebooklm-enterprise/docs/overview)
and [sensitive data controls](https://docs.cloud.google.com/gemini/enterprise/notebooklm-enterprise/docs/protect-sensitive-data).

## Completion Criterion

Export is complete only when the entire safe scope was regenerated into paired
current-state BA／SA documents, user notes were preserved, every safe file has a non-gap disposition,
every active requirement is cataloged and has stable acceptance criteria, Wiki
checks pass, the exact final payload passes post-mask DLP and capacity limits,
`query-index`, `project-map`, and `shared-business-context` are present,
the shared source contains the glossary and every active evidence-backed
cross-capability process with concrete steps, conditions, branches, and its
applicable requirement/rule 正文, every document has a source mapping,
the final-source flow-integrity report is complete,
the schema-v6 manifest and upload
plan were written atomically, and the final report lists actions, coverage, DLP
masking counts, migration mode, and unresolved business-confirmation gaps.
Preflight alone never writes `.notebooklm/`.
