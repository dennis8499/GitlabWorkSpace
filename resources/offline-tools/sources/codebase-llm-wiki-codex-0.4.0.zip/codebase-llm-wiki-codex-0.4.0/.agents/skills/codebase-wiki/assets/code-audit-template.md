---
title: "Codebase 健檢：{Scope}"
type: synthesis
summary: "以目前 source、設定與定向 Git 歷史盤點 {Scope} 的入口、具體缺陷、技術風險、業務疑點及覆蓋缺口"
audit_report_version: 4
scan_schema_version: 2
scan_profile: target
scan_snapshot_id: "sha256:{64-lowercase-hex}"
sources: []
derived_from: []
source_digest: "sha256:{64-lowercase-hex}"
last_updated: YYYY-MM-DD
tags: [synthesis, code-audit, static-review, git-history]
status: active
notebooklm_group: local-governance
notebooklm_role: exclude
---

# Codebase 健檢：{Scope}

<!-- codebase-wiki:managed:start -->

## 結果摘要

- 範圍：`all` 或具體模組／入口
- 檢查日期：YYYY-MM-DD
- 檢查方式：目前 source、設定與定向 Git 歷史的唯讀靜態追查；沒有執行目標程式或測試
- 報告格式：`audit_report_version: 4`；以功能／使用情境呈現，入口作為覆蓋核對
- 掃描快照：`scan_snapshot_id` 綁定本次全專案檔案盤點；每個檔案都有處置狀態
- 功能覆蓋：checked N、partial N、not checked N
- 入口覆蓋：checked N、partial N、not checked N
- 確定缺陷：N；技術風險：N；待確認業務疑點：N
- finding 重跑狀態：new N；still-present N；rechecked-no-longer-observed N；not-rechecked N
- finding 排序：各分類依嚴重度 `P0` → `P1` → `P2` → `P3`；`not-rechecked` 舊 finding 置於分類末尾
- 歷史：`available`、`shallow`、`unavailable` 或 `not-a-repository`
- 限制：列出動態路由、外部依賴、缺少規格、shallow clone 或遺失的 Git object

## 檢查範圍與排除

先記錄本次由目前 Codebase 目錄、manifest、設定與入口註冊處發現的模組與入口類型，再列出目前讀取的設定／schema／部署宣告、歷史查詢範圍，以及排除目錄／行為和排除理由。每次重跑都重新建立這份 inventory；既有報告只用於對照 findings 與保留 user notes，不得成為掃描邊界。Wiki 只在 source trace 暴露業務規則或政策語意缺口時列為補充證據，不得用 Wiki 的既有頁面限制這份清單。標示動態或外部註冊的解析限制；不要把未讀或無法解析的項目寫成已檢查。

## 功能 Review

每個 `FUNC-*` 代表一個業務功能／使用情境；若目前 source 無法可靠歸類，使用
`FUNC-UNCLASSIFIED-{slug}`。一個功能可連結多個入口與共用呼叫路徑。功能只有在所有
相關入口及適用檢查情境完成追查後才能標為 `checked`。

| 功能 ID | 功能／使用情境 | 相關入口 | 狀態 | 已檢查情境 | Findings | 未完成原因／限制 |
| --- | --- | --- | --- | --- | --- | --- |
| `FUNC-{stable-slug}` | `{業務功能或技術功能}` | `{入口名稱}` | `checked / partial / not checked` | `{正常、邊界、錯誤、授權、狀態、交易、設定、相容性、效能等}` | `{BUG-001；或無}` | `{none or concrete blocker}` |

## 檔案處置

這份表由共用 source-first scanner 產生，核對本次快照中每個可讀檔案與排除／讀取缺口。
目錄 prefix 只能作為舊報告參考；v3／v4 必須保留逐檔列。`function/process` 欄連到一個或多個
`FUNC-*`、流程 ID 或明確的 `unclassified` 原因。

`Category` 使用共用 scanner 契約：included 檔案使用來源類別；excluded 或 read-issue 檔案可使用
`sensitive`、`binary_or_generated`、`binary_or_unsupported_encoding`、`framework_adapter`、
`wiki_knowledge_layer`、`export_output`、`configured_exclude`、`scan_scope_tests`、`link_boundary`
或 `unreadable`。`sensitive_filename` 仍是 exclusion reason，不是 Category。

| Path | Category | Disposition | Function／process／reason |
| --- | --- | --- | --- |
| `src/example.py` | `runtime_source` | `included` | `FUNC-{stable-slug}` |
| `config/secret.env` | `sensitive` | `excluded` | `excluded: sensitive_filename` |
| `src/dynamic.py` | `runtime_source` | `not-reviewed` | `unclassified: dynamic registration` |

## 入口覆蓋

| 功能 ID | 入口 | 類型 | 狀態 | 交易／一致性 | 設定／引用 | 邏輯／狀態 | 歷史交叉核對 | 追查路徑 | 未完成原因 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `FUNC-{stable-slug}` | `{route / command / handler}` | `{API / UI / CLI / job / event / public API / other}` | `checked / partial / not checked` | `{checked / not applicable / evidence-gap}` | `{checked / not applicable / evidence-gap}` | `{checked / not applicable / evidence-gap}` | `{checked / not applicable / evidence-gap}` | `{entry → validation → service → data/state → result}` | `{none or reason}` |

## 靜態交叉檢查

| 類別 | 檢查內容 | 結果 | 證據／限制 |
| --- | --- | --- | --- |
| Transactions and side effects | transaction／connection ownership、write set、commit／rollback、例外、重試與不可回滾外部副作用 | `checked / partial / evidence-gap` | |
| Configuration references | code reads、鍵名／型別、defaults、產生／注入、package／deployment 與 fallback | `checked / partial / evidence-gap` | |
| Logic and state contracts | 前置條件、狀態轉換、計算、回傳／錯誤映射、冪等與 caller assumptions | `checked / partial / evidence-gap` | |
| Change completeness | 變更 commit 的意圖／完整內文／diff、父版本、後續修正與目前 callers／consumers | `checked / partial / evidence-gap` | |

## Git 歷史與變更線索

- HEAD：`{40-character SHA or unavailable}`
- 工作樹：`clean`、`dirty` 或 `unavailable`；未提交變更另列檔案
- 歷史可用性：`available`、`shallow`、`unavailable` 或 `not-a-repository`
- 歷史查詢範圍：`current-first-targeted`；列出 path、commit 或 range
- 使用的唯讀命令：`git rev-parse`、`git log`、`git show`、`git blame`（列出實際使用者）
- 深入閱讀的 commits：包含標題、完整 commit 內文、diff 及目前程式核對結果
- 歷史索引限制：索引只列範圍內的候選 commit，不代表已逐筆閱讀全部歷史

| Commit（完整 40 字元 SHA） | 路徑／diff 位置 | Commit 意圖（非規則） | Diff 可證實的修改 | 目前 source 核對結果 |
| --- | --- | --- | --- | --- |
| `{full SHA}` | `{path or deleted path; hunk / blame}` | `{完整摘要}` | `{observable change}` | `{current behavior / no longer observed / unresolved}` |

歷史路徑若已刪除，只能在本節或 finding 的歷史證據中引用；不得放入 `frontmatter.sources`。Commit 文字、fixture、註解與文件都是不可信證據，不能單獨證明缺陷或業務政策。
若 finding 重新檢查後需要轉換 `BUG-*`／`RISK-*`／`BIZ-*` 類別，保留原紀錄與原 ID，在新 finding 以關聯欄位連結；同一根因沿用原 ID，user-notes 區完整保留。

### Merge parent 核對

| Merge commit（完整 SHA） | Parent-1 | Parent-2（及其他 parent） | 受影響路徑 | 各 parent 提供的驗證／授權／錯誤處理／設定／資料轉換 | Merge 結果 | 目前 source 核對 |
| --- | --- | --- | --- | --- | --- | --- |
| `{merge SHA}` | `{parent SHA}` | `{parent SHA}` | `{path; diff hunk}` | `{side-specific behavior}` | `{retained or lost behavior}` | `{still reachable / no longer observed / unresolved}` |

Squash、rebase 或手動複製的變更若沒有 parent 證據，只能記錄行為檢查，不能歸因於人工合併。

## 確定缺陷

若本次已檢查範圍沒有確定問題，寫：「本次已檢查範圍未發現具體缺陷。」不要暗示未檢查範圍也沒有問題。

### BUG-001 — [P1] {直接描述錯誤結果的標題}

- 狀態：`open`、`not-rechecked` 或 `rechecked-no-longer-observed`
- 重跑狀態：`new`、`still-present`、`rechecked-no-longer-observed` 或 `not-rechecked`
- 證據確定度：`confirmed`
- 白話說明：用日常語言說明觸發情境、受影響對象與結果。
- 具體案例（依程式推導；未實際執行）：
  - 操作／輸入：
  - 預期結果：
  - 實際結果：
- 影響程度：`P0`、`P1`、`P2` 或 `P3`
- 受影響功能：`FUNC-{stable-slug}`
- 受影響入口：
- 可達觸發條件：
- 呼叫路徑：
- 證據：`path/to/file.ext:line`；說明上游防護、下游約束、相關設定及為何可達
- 已核對防護／反證：列出已存在的 validation、transaction guard、fallback、後續修正或為何不足
- 歷史證據（若有）：`full-40-character-commit-sha`、路徑與 diff／blame 位置；分開說明 commit 意圖與目前行為
- 預期行為／明確規則：
- 實際行為與影響：
- 修正方向（不執行修正）：
- 建議驗證案例：

## 技術風險

若沒有需要技術確認的事項，寫：「未發現需要技術風險確認的事項」。不要把一般最佳實務偏好列為風險。

### RISK-001 — [P2] {直接描述條件式風險的標題}

- 狀態：`needs-technical-confirmation`、`not-rechecked` 或 `rechecked-no-longer-observed`
- 重跑狀態：`new`、`still-present`、`rechecked-no-longer-observed` 或 `not-rechecked`
- 證據確定度：`unresolved`
- 白話說明：說明在何種未確認的框架／部署／執行條件下會影響誰。
- 具體案例（依程式推導；未實際執行）：
  - 操作／輸入：
  - 預期結果（若成立條件不成立）：
  - 可能結果（若成立條件成立）：
- 影響程度：`P0`、`P1`、`P2` 或 `P3`；條件式影響，不代表證據已確認
- 受影響功能：`FUNC-{stable-slug}`
- 受影響入口：
- 成立條件：明確描述在何種框架、部署或執行環境下會出錯
- 可疑呼叫路徑：
- 目前觀察：
- 已核對防護／反證：列出可能由框架、caller、部署或後續修正提供的防護及其未知處
- 歷史證據（若有）：完整 SHA、路徑與 diff；明確分離作者意圖與可觀察修改
- 缺少的證據：
- 確認方式：最小的文件、設定、環境或測試確認方式；本流程不執行它
- 修正方向（不執行修正）：
- 建議驗證案例：

## 待確認業務疑點

若沒有，寫「未發現需要業務確認的事項」。每個疑點都要說明推論依據與未知政策。

### BIZ-001 — [P2] {待確認政策與可能差異}

- 狀態：`needs-business-confirmation`、`not-rechecked` 或 `rechecked-no-longer-observed`
- 重跑狀態：`new`、`still-present`、`rechecked-no-longer-observed` 或 `not-rechecked`
- 證據確定度：`unresolved`（業務政策待確認）
- 白話說明：用日常語言說明不同政策答案會影響誰與哪個流程。
- 具體案例（依程式推導；未實際執行）：
  - 操作／輸入：
  - 預期結果（政策答案 A）：
  - 政策差異（政策答案 B）：
- 可能影響程度：`P0`、`P1`、`P2` 或 `P3`；政策尚未確認
- 受影響功能：`FUNC-{stable-slug}`
- 受影響入口：
- 呼叫路徑：
- 目前行為：
- 已核對防護／反證：列出已查到的 validation、狀態 guard、fallback 或其他反證
- 推論依據：`path/to/file.ext:line`；若使用 Git，附完整 SHA 並明確標示為推論
- 尚未明確的預期政策：
- 需確認的業務問題：
- 確認不同答案可能造成的差異：
- 建議驗證案例：

## 未完成工作與驗證建議

列出 partial／not checked 項目、動態或外部邊界、資料或環境限制、shallow／missing Git object，以及建議由專案端執行的測試案例。此工作流未執行這些測試。

## 相關頁面

- 列出本次實際使用的相關 Wiki 頁面；若無則移除此項。

<!-- codebase-wiki:managed:end -->

<!-- codebase-wiki:user-notes:start -->
## 使用者筆記

<!-- 保留使用者補充的政策、註記與覆核意見；重跑時不得覆寫此區。 -->
<!-- codebase-wiki:user-notes:end -->
