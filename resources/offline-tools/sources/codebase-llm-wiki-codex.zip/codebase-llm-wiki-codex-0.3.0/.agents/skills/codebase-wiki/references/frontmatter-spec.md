# Frontmatter 欄位完整規格

本檔是 wiki page frontmatter 的權威規格。頂層 instruction、agent prompt
與文件可以摘要必填欄位，但 allowed values、type-specific 欄位與驗證規則
以本檔為準。

## 共用欄位（所有頁面類型必填）

| 欄位           | 型別     | 必填 | 說明                               | 範例                            |
| -------------- | -------- | ---- | ---------------------------------- | ------------------------------- |
| `title`        | string   | ✅    | 頁面標題（人類可讀）               | `"User Authentication Service"` |
| `type`         | enum     | ✅    | 頁面類型                           | `module`                        |
| `sources`      | string[] | ✅    | 引用的原始碼路徑（相對 repo root） | `["src/auth/service.ts"]`       |
| `last_updated` | string   | ✅    | 最後更新日期（YYYY-MM-DD）         | `"2026-04-16"`                  |
| `tags`         | string[] | ✅    | 分類標籤                           | `["auth", "security"]`          |
| `status`       | enum     | ✅    | 頁面狀態                           | `active`                        |

### 證據與衍生欄位（選填、增量採用）

| 欄位 | 型別 | 規則 |
| --- | --- | --- |
| `summary` | string | 一句話結論；新增或重大更新的 evidence-backed 頁面必填。 |
| `derived_from` | string[] | Wiki 衍生證據，使用 `[[page-name]]`；不得放入 `sources`。 |
| `source_digest` | string | `sha256:<64 lowercase hex>`；新增或重大更新且 `sources` 非空的頁面必填。 |
| `standards_profile` | string | 選填、kebab-case；新 BA／SA／SD 工作流必填，legacy SA 缺少時仍相容。 |
| `coverage_status` | enum | 選填 `covered` / `partial` / `gap`；新 BA／SA／SD 與 business-process 必填。 |
| `analysis_status` | enum | 選填 `untraced` / `traced` / `complete` / `evidence-gap` / `business-confirmation`；更新後的流程與 BA／SA 文件用來標示追查是否完成。 |
| `gap_classification` | enum | 選填 `none` / `analysis-gap` / `evidence-gap` / `business-confirmation`；分開標示未追查、來源缺證據與待業務確認。 |
| `audit_report_version` | integer | Codebase audit report 選填；缺少時以 legacy report contract 驗證，`2` 啟用功能／入口關聯與重跑狀態契約，`3` 啟用 scanner-bound file inventory，`4` 再啟用白話案例、P0–P3 分級與 merge parent review。 |
| `scan_schema_version` | integer | `audit_report_version: 3` 或 `4` 必填且目前必須為 `2`；validator 依此選擇 scanner inventory contract。 |
| `scan_profile` | enum | `audit_report_version: 3` 或 `4` 必填且只能是 `target` 或 `framework`；validator 不從舊報告推定。 |
| `scan_snapshot_id` | string | `audit_report_version: 3` 或 `4` 必填，格式為 `sha256:<64 lowercase hex>`，綁定本次 shared scanner inventory。 |

`source_digest` 對排序後的 `repo-relative-path + NUL + file-sha256` records
再做 SHA-256。目錄來源展開 Git tracked 與 non-ignored untracked files，並排除
Wiki、dependency、generated、cache 與 export output。舊頁面缺少這些欄位時
Lint 先回報 Info，不作為 schema failure。

### NotebookLM 業務分組與角色（選填）

| 欄位 | 型別 | 必填 | 說明 | 範例 |
| --- | --- | --- | --- | --- |
| `notebooklm_group` | string | NotebookLM preparation 建立或更新的頁面必填；其他頁面選填 | 穩定的業務能力群組，使用 kebab-case | `business-order-cancellation` |
| `notebooklm_role` | enum | NotebookLM preparation 建立或更新的頁面必填；其他頁面選填 | `business` / `analysis` / `traceability` / `exclude` | `business` |
| `notebooklm_terms` | string[] | `notebooklm_role: business` 時必填且不可為空 | BA 查詢用角色、流程、規則與詞彙 | `[訂單取消, 客服]` |
| `notebooklm_document` | enum | schema-v6 per-capability export 文件必填 | `ba` / `sa` | `sa` |
| `source_locators` | string[] | schema-v6 per-capability export 文件必填 | real source 的 `path:line` 定位；有 source 時不可為空 | `["src/orders.py:42"]` |

允許值必須符合 `^[a-z0-9]+(?:-[a-z0-9]+)*$`。同一功能域重跑時沿用既有值；
BA 高階頁面使用 `business-core`，流程／規則與其追溯頁面共用
`business-{capability}`。缺少 `notebooklm_role` 的舊頁面不會自動成為 BA source；
exporter 會省略並回報 warning。Current-state BA／SA export pages 另需
`capability_id`、固定 `{capability}-ba.md`／`-sa.md` path、專用 profile、相同 group、
雙向 wikilink 與可驗證 locators；SA 使用 `notebooklm_role: analysis`。Standalone
standards-aligned BA／SA 不因 role 自動成為 schema-v6 upload candidate。

### Standard-aligned synthesis metadata（選填、增量採用）

新產出的 BA／SA／SD synthesis 必須分別使用
`business-analysis-aligned-v1`、`system-analysis-aligned-v1`、
`system-design-aligned-v1`，並填寫 `coverage_status`。兩欄在共用 validator
維持選填，讓尚未重跑的 legacy SA 與一般 synthesis 繼續相容；工作流與模板負責
要求新文件填寫。Profile 的標準版本、coverage 語意與 traceability contract 見
`analysis-document-standards.md`。

`status: active` 只代表 Wiki freshness；`coverage_status` 描述文件證據是否完整，
兩者不得互相代替。`analysis_status: untraced` 或 `gap_classification: analysis-gap`
代表追查尚未完成，會阻擋 NotebookLM 匯出；`evidence-gap` 與
`business-confirmation` 會保留已知的實作內容並明確標示未知政策，不得改寫成
「Codebase 未提供證據」。未標示 `analysis_status` 的舊頁面仍以 legacy 相容模式處理，
但新模板產生的流程、BA／SA 文件應填寫這兩欄。

### `type` 允許值

| 值             | 對應目錄             | 說明                         |
| -------------- | -------------------- | ---------------------------- |
| `business-process` | `wiki/processes/` | 端到端業務流程 |
| `business-requirement` | `wiki/requirements/` | 可驗收、可查詢的功能需求 |
| `business-rule` | `wiki/rules/` | 可獨立查詢的業務條件與決策 |
| `module`       | `wiki/modules/`      | 按模組/目錄的文件頁面        |
| `entity`       | `wiki/entities/`     | 類別、服務、API 端點、DB 表  |
| `pattern`      | `wiki/patterns/`     | 設計模式                     |
| `decision`     | `wiki/decisions/`    | Architecture Decision Record |
| `dependency`   | `wiki/dependencies/` | 外部相依套件                 |
| `guide`        | `wiki/guides/`       | 操作指南                     |
| `synthesis`    | `wiki/synthesis/`    | 綜合分析                     |
| `overview`     | `wiki/` (root)       | Codebase 高階總覽            |
| `architecture` | `wiki/architecture/` | 架構文件                     |
| `index`        | `wiki/` (root)       | 索引頁（僅 `index.md`）      |
| `log`          | `wiki/` (root)       | 活動日誌（僅 `log.md`）      |

### `type` 對應路徑規則

| `type` | 合法位置 |
| --- | --- |
| `business-process` | `wiki/processes/*.md` |
| `business-requirement` | `wiki/requirements/*.md` |
| `business-rule` | `wiki/rules/*.md` |
| `module` | `wiki/modules/*.md` |
| `entity` | `wiki/entities/*.md` |
| `pattern` | `wiki/patterns/*.md` |
| `decision` | `wiki/decisions/*.md` |
| `dependency` | `wiki/dependencies/*.md` |
| `guide` | `wiki/guides/*.md` |
| `synthesis` | `wiki/synthesis/*.md` |
| `overview` | `wiki/overview.md` |
| `architecture` | `wiki/architecture/*.md` |
| `index` | `wiki/index.md` |
| `log` | `wiki/log.md` |

### `status` 允許值

| 值            | 語意                     | 何時使用                  |
| ------------- | ------------------------ | ------------------------- |
| `active`      | 內容準確且最新           | 剛 ingest 或驗證過的頁面  |
| `stale`       | 內容可能過時             | source 已變更但頁面未更新 |
| `placeholder` | 佔位符，尚未填入實質內容 | 已知需要但尚未 ingest     |

### 日期格式

所有日期欄位必須使用 `YYYY-MM-DD`，且必須是有效日期，例如
`2026-07-01`。不得使用相對日期、時間戳、民國年、或含時間的 ISO 字串。

---

## 類型特定欄位

### `type: decision`（ADR 專用）

| 欄位              | 型別   | 必填 | 說明                                          | 範例                 |
| ----------------- | ------ | ---- | --------------------------------------------- | -------------------- |
| `decision_date`   | string | ✅    | 決策日期（YYYY-MM-DD）                        | `"2026-04-16"`       |
| `decision_status` | enum   | ✅    | proposed / accepted / deprecated / superseded | `"accepted"`         |
| `superseded_by`   | string | ❌    | 取代此 ADR 的頁面名                           | `"adr-005-new-auth"` |

`decision_status` 只描述決策生命週期；共用欄位 `status` 仍描述 wiki 頁面
狀態，只能使用 `active` / `stale` / `placeholder`。

### `type: entity`（Entity 專用）

| 欄位            | 型別   | 必填 | 說明                                            | 範例            |
| --------------- | ------ | ---- | ----------------------------------------------- | --------------- |
| `entity_type`   | enum   | 建議 | class / service / api-endpoint / database-table | `"service"`     |
| `parent_module` | string | 建議 | 所屬模組的 wiki 頁面名                          | `"auth-module"` |

### `type: dependency`（Dependency 專用）

| 欄位           | 型別   | 必填 | 說明                       | 範例             |
| -------------- | ------ | ---- | -------------------------- | ---------------- |
| `package_name` | string | ✅    | 套件全名（含 scope）       | `"@nestjs/core"` |
| `version`      | string | ✅    | 目前使用版本               | `"^10.3.0"`      |
| `registry`     | string | 建議 | npm / pypi / maven / nuget | `"npm"`          |

### `type: business-process`

| 欄位 | 型別 | 必填 | 說明 |
| --- | --- | --- | --- |
| `process_id` | string | ✅ | 穩定 kebab-case ID，建議 `bp-{domain}-{process}` |
| `actors` | string[] | ✅ | 參與角色；未知時可為空並在 body 登錄 gap |
| `coverage_status` | enum | ✅ | `covered` / `partial` / `gap` |
| `analysis_status` | enum | 新頁面建議 | `traced` 表示已沿呼叫鏈完成追查；`untraced` 會阻擋匯出 |
| `gap_classification` | enum | 新頁面建議 | `none` / `analysis-gap` / `evidence-gap` / `business-confirmation` |
| `notebooklm_group` | string | ✅ | `business-{capability}` |
| `notebooklm_role` | enum | ✅ | 固定為 `business` |
| `notebooklm_terms` | string[] | ✅ | 非空的流程、角色、觸發與同義詞 |

### `type: business-rule`

| 欄位 | 型別 | 必填 | 說明 |
| --- | --- | --- | --- |
| `rule_id` | string | ✅ | 穩定 kebab-case ID，建議 `br-{domain}-{rule}` |
| `applies_to` | string[] | ✅ | 至少一個 `[[business-process]]` wikilink |
| `evidence_state` | enum | ✅ | `business-confirmed` / `implementation-observed` / `inference` / `gap` |
| `notebooklm_group` | string | ✅ | 與適用流程相同的 business group |
| `notebooklm_role` | enum | ✅ | 固定為 `business` |
| `notebooklm_terms` | string[] | ✅ | 非空的規則、條件、結果與同義詞 |

### `type: business-requirement`

| 欄位 | 型別 | 必填 | 說明 |
| --- | --- | --- | --- |
| `requirement_id` | string | ✅ | 穩定 kebab-case ID，建議 `fr-{domain}-{capability}` |
| `capability_id` | string | ✅ | 穩定 kebab-case 能力 ID，建議 `cap-{domain}-{capability}` |
| `applies_to` | string[] | ✅ | 至少一個 `[[business-process]]` wikilink |
| `evidence_state` | enum | ✅ | `business-confirmed` / `implementation-observed` / `inference` / `gap` |
| `notebooklm_group` | string | ✅ | 與適用流程相同的 business group |
| `notebooklm_role` | enum | ✅ | 固定為 `business` |
| `notebooklm_terms` | string[] | ✅ | 非空的功能、角色、結果、驗收與同義詞 |

Body 必須包含 `## 驗收條件`，且至少有一個穩定的 `AC-*` ID。功能需求頁的
自動萃取內容置於 `codebase-wiki:managed` markers；人工 BA 補充置於
`codebase-wiki:user-notes` markers。只供本機追溯的 path、symbol 或技術細節置於
`notebooklm:local-only` markers，匯出時會移除。

### `type: index` 與 `type: log`

| 頁面 | 必填值 |
| --- | --- |
| `wiki/index.md` | `type: index`、`sources: []`、`tags: [index]` |
| `wiki/log.md` | `type: log`、`sources: []`、`tags: [log]` |

`wiki/log.md` 的內容區塊為 append-only；可更新 frontmatter 的
`last_updated`，但不得刪除或改寫既有 log entries。

---

## Templates

Frontmatter examples live only in the exact assets selected by
`page-types.md`. This file remains the schema source of truth; assets remain the
page-shape source of truth.

---

## sources 填寫規範

1. 路徑相對於 repo root，且只引用 raw repository evidence；Wiki 頁面改用 `derived_from`
2. 指向目錄時以 `/` 結尾：`src/modules/auth/`
3. 指向檔案時不加 `/`：`src/modules/auth/service.ts`
4. 只列出最核心的 1-5 個 source，不需窮舉
5. **禁止填入不存在的路徑**——Lint 會檢查
6. sources 可為空陣列 `[]`（如 guide、synthesis 可能無直接 raw source）

---

## 驗證規則

`validate-frontmatter.py` 依此規格執行 deterministic validation：

1. 所有 wiki markdown 檔必須有 YAML frontmatter。
2. 共用必填欄位不得缺漏。
3. `title` 必須是非空字串。
4. `type` 必須是本檔列出的允許值。
5. `sources` 必須是陣列；可為空陣列。
6. `last_updated` 必須是有效 `YYYY-MM-DD` 日期。
7. `tags` 必須是陣列。
8. `status` 必須是 `active` / `stale` / `placeholder`。
9. `type: decision` 必須有有效 `decision_date` 與 `decision_status`。
10. `type: dependency` 必須有非空 `package_name` 與 `version`。
11. `type: index` / `type: log` 必須位於指定 root 檔名。
12. `notebooklm_group` 若存在，必須是非空 kebab-case 字串。
13. `summary` 若存在，必須是非空字串。
14. `derived_from` 若存在，必須是由 `[[wikilink]]` 組成的陣列。
15. `source_digest` 若存在，必須符合 `sha256:<64 lowercase hex>`。
16. `notebooklm_role` 與 `notebooklm_terms` 必須符合上述角色契約。
17. Business Requirement/Process/Rule 頁面必須位於指定目錄且通過其 type-specific 驗證。
18. `standards_profile` 若存在，必須是非空 kebab-case 字串。
19. `coverage_status` 若存在，必須是 `covered` / `partial` / `gap`；
    business-process 仍強制必填，新 BA／SA／SD 由工作流契約強制必填。
20. `analysis_status` 若存在，必須是 `untraced` / `traced` / `complete` /
    `evidence-gap` / `business-confirmation`。
21. `gap_classification` 若存在，必須是 `none` / `analysis-gap` /
    `evidence-gap` / `business-confirmation`。

### Development specifications

`development-spec` synthesis pages use `spec_revision` (positive integer), `spec_status: draft | ready`, `blocking_questions` (string list), and `notebooklm_role: exclude`. A ready page has no blocking questions; freshness `status` is independent. Validate with `scripts/validate-development-spec.py`.
