# Codebase LLM Wiki — OpenAI Codex package

This is the OpenAI Codex surface of Codebase LLM Wiki, version 0.2.1. It contains the shared codebase-wiki skill and only the selected platform adapter.

## Install

From this package directory, preview the installation first:

```powershell
python .agents/skills/codebase-wiki/scripts/install-framework.py install --target C:\path\to\your-repo --surface codex --guard-mode wiki-only --format json
```

Review the JSON plan, then apply it:

```powershell
python .agents/skills/codebase-wiki/scripts/install-framework.py install --target C:\path\to\your-repo --surface codex --guard-mode wiki-only --apply --format json
```

For an existing installation, use the same command with `upgrade`:

```powershell
python .agents/skills/codebase-wiki/scripts/install-framework.py upgrade --target C:\path\to\your-repo --surface codex --guard-mode wiki-only --format json
```

The installer preserves target Wiki content and reports conflicts before writing. The framework is based on the upstream LLM Wiki method; see https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f.
