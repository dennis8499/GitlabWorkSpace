"""Project-scoped, deterministic Codex PermissionRequest approvals (Python 3.11+)."""
from __future__ import annotations

import argparse
import base64
import fnmatch
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import tomllib
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any

from project_config import MISSING, edit_toml, load_toml, lookup

VERSION = "1.0.1"
ASSETS = ("autohook.py", "project_config.py", "parse_powershell.ps1", "default.rules", "policy.json")
MANAGED_SETTINGS = {
    ("approval_policy",): "on-request",
    ("approvals_reviewer",): "user",
    ("features", "hooks"): True,
}
STATUS_MESSAGE = "AutoHook: project approval rules"
MAX_INPUT_BYTES = 1024 * 1024
HOOK_TIMEOUT = 10
ALLOW_OUTPUT = {"hookSpecificOutput": {"hookEventName": "PermissionRequest", "decision": {"behavior": "allow"}}}


class AutoHookError(Exception):
    pass


@dataclass(frozen=True)
class Decision:
    decision: str
    rule: str
    reason: str

    @property
    def allowed(self) -> bool:
        return self.decision == "allow"


def manual(reason: str) -> Decision:
    return Decision("manual", "", reason)


def allowed(rule: str, reason: str) -> Decision:
    return Decision("allow", rule, reason)


def runtime_dir(project: Path) -> Path:
    return project / ".codex" / "autohook"


def _json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _read_json(path: Path) -> Any:
    with path.open("rb") as stream:
        raw = stream.read(MAX_INPUT_BYTES + 1)
    if len(raw) > MAX_INPUT_BYTES:
        raise AutoHookError("JSON input is too large")
    return json.loads(raw.decode("utf-8-sig"))


def _within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _safe_target(project: Path, path: Path) -> None:
    """Never install through a symlink/junction or overwrite a linked file."""
    if not _within(path.absolute(), project):
        raise AutoHookError("Installation target is outside the project")
    current = project
    for component in path.relative_to(project).parts:
        current /= component
        if current.is_symlink() or current.resolve() != current.absolute():
            raise AutoHookError("Installation target contains a symlink or junction")
    if path.exists() and path.is_file() and path.stat().st_nlink > 1:
        raise AutoHookError("Installation target is a hard link")


def _atomic_write(project: Path, path: Path, raw: bytes) -> None:
    _safe_target(project, path)
    path.parent.mkdir(parents=True, exist_ok=True)
    _safe_target(project, path)
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(prefix=".autohook-", dir=path.parent, delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def _restore_file(project: Path, path: Path, raw: bytes | None) -> None:
    if raw is None:
        _safe_target(project, path)
        if path.exists():
            path.unlink()
    else:
        _atomic_write(project, path, raw)


def _read_optional(path: Path) -> bytes | None:
    return path.read_bytes() if path.exists() else None


def _pack(raw: bytes | None) -> str | None:
    return None if raw is None else base64.b64encode(raw).decode("ascii")


def _unpack(raw: str | None) -> bytes | None:
    return None if raw is None else base64.b64decode(raw, validate=True)


def _powershell_quote(text: str) -> str:
    return "'" + text.replace("'", "''") + "'"


def _hook_handler(project: Path, python_path: str) -> dict[str, Any]:
    script = runtime_dir(project) / "autohook.py"
    command = "& " + " ".join(_powershell_quote(value) for value in
                               (python_path, str(script), "hook", "--project", str(project)))
    return {
        "type": "command", "command": command, "commandWindows": command,
        "timeout": HOOK_TIMEOUT, "async": False, "statusMessage": STATUS_MESSAGE,
    }


def _load_hooks(raw: bytes | None) -> dict[str, Any]:
    value = {"hooks": {}} if raw is None else json.loads(raw.decode("utf-8-sig"))
    if not isinstance(value, dict) or not isinstance(value.get("hooks", {}), dict):
        raise AutoHookError("hooks.json must contain a hooks object")
    value.setdefault("hooks", {})
    for groups in value["hooks"].values():
        if not isinstance(groups, list):
            raise AutoHookError("Hook event entries must be arrays")
        for group in groups:
            if not isinstance(group, dict) or not isinstance(group.get("hooks"), list):
                raise AutoHookError("Invalid hook matcher group")
    return value


def _remove_handler(hooks: dict[str, Any], handler: dict[str, Any]) -> None:
    groups = hooks["hooks"].get("PermissionRequest", [])
    kept = []
    for group in groups:
        handlers = [item for item in group["hooks"] if item != handler]
        if len(handlers) != len(group["hooks"]):
            if handlers:
                kept.append({**group, "hooks": handlers})
        else:
            kept.append(group)
    if kept:
        hooks["hooks"]["PermissionRequest"] = kept
    else:
        hooks["hooks"].pop("PermissionRequest", None)


def _has_handler(hooks: dict[str, Any], handler: dict[str, Any]) -> bool:
    return any(group.get("matcher") == "^(Bash|apply_patch)$" and handler in group["hooks"]
               for group in hooks["hooks"].get("PermissionRequest", []))


class ProcessTools:
    """Only run the trusted parser and Codex's non-executing policy checker."""
    def __init__(self, codex: str, powershell: str, root: Path, deadline: float | None = None):
        self.codex = codex
        self.powershell = powershell
        self.root = root
        self.deadline = deadline or time.monotonic() + 8

    def _run(self, argv: list[str], stdin: str | None = None) -> str:
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise AutoHookError("tool-timeout")
        result = subprocess.run(
            argv, input=stdin, stdin=None if stdin is not None else subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8", errors="strict",
            cwd=self.root, shell=False, timeout=min(remaining, 4),
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if result.returncode:
            raise AutoHookError("tool-failed")
        return result.stdout.strip()

    def version(self) -> str:
        value = self._run([self.codex, "--version"])
        if not re.fullmatch(r"codex-cli [0-9][^\r\n]*", value):
            raise AutoHookError("unsupported-codex-version-output")
        return value

    def parse(self, command: str, parser_file: Path) -> list[str]:
        # -Command runs our fixed, integrity-checked parser, not the request.
        # This works with Restricted execution policy without changing it.
        parser_source = parser_file.read_text(encoding="utf-8-sig")
        raw = self._run([self.powershell, "-NoLogo", "-NoProfile", "-NonInteractive",
                         "-Command", parser_source], json.dumps({"command": command}, ensure_ascii=True))
        parsed = json.loads(raw)
        if not isinstance(parsed, dict) or parsed.get("ok") is not True:
            raise AutoHookError("unsupported-powershell-syntax")
        argv = parsed.get("argv")
        if (not isinstance(argv, list) or not argv or len(argv) > 128 or
                any(not isinstance(item, str) or "\x00" in item for item in argv)):
            raise AutoHookError("invalid-parser-output")
        return argv

    def execpolicy(self, argv: list[str], rule_files: list[Path]) -> dict[str, Any]:
        args = [self.codex, "execpolicy", "check"]
        for rule in rule_files:
            args += ["--rules", str(rule)]
        value = json.loads(self._run(args + ["--"] + argv))
        if not isinstance(value, dict) or not isinstance(value.get("matchedRules"), list):
            raise AutoHookError("unsupported-execpolicy-output")
        return value


def _compatibility_probe(tools: ProcessTools, assets: Path) -> str:
    version = tools.version()
    rules = [assets / "default.rules"]
    yes = tools.execpolicy(["Get-Location"], rules)
    no = tools.execpolicy(["__autohook_unknown_probe__"], rules)
    if yes.get("decision") != "allow" or not yes["matchedRules"] or no.get("decision") == "allow":
        raise AutoHookError("Codex execpolicy compatibility probe failed")
    if tools.parse("Get-Location", assets / "parse_powershell.ps1") != ["Get-Location"]:
        raise AutoHookError("PowerShell AST compatibility probe failed")
    try:
        tools.parse("Get-Location; Get-Location", assets / "parse_powershell.ps1")
    except AutoHookError:
        pass
    else:
        raise AutoHookError("PowerShell parser did not reject compound commands")
    return version


def _tools_from_settings(settings: dict[str, Any], project: Path) -> ProcessTools:
    for key in ("codex_path", "powershell_path"):
        value = settings.get(key)
        if (not isinstance(value, str) or not Path(value).is_absolute() or
                Path(value).suffix.casefold() != ".exe" or not Path(value).is_file()):
            raise AutoHookError("configured-tool-is-missing")
    return ProcessTools(settings["codex_path"], settings["powershell_path"], project)


def _validate_settings(settings: Any, project: Path, *, require_policy: bool = True) -> None:
    if not isinstance(settings, dict) or settings.get("schema_version") != 1:
        raise AutoHookError("unsupported-settings-schema")
    if settings.get("project") != str(project) or require_policy and settings.get("policy_version") != VERSION:
        raise AutoHookError("project-or-policy-version-mismatch")


def _validate_assets(settings: dict[str, Any], assets: Path) -> None:
    hashes = settings.get("asset_sha256")
    if not isinstance(hashes, dict) or set(hashes) != set(ASSETS):
        raise AutoHookError("missing-asset-manifest")
    for name in ASSETS:
        path = assets / name
        _safe_target(Path(settings["project"]), path)
        if hashlib.sha256(path.read_bytes()).hexdigest() != hashes[name]:
            raise AutoHookError("installed-assets-have-changed")


class Policy:
    def __init__(self, project: Path, policy: dict[str, Any]):
        self.project = project.resolve()
        if policy.get("schema_version") != 1 or policy.get("policy_version") != VERSION:
            raise AutoHookError("unsupported-policy-schema")
        self.protected_components = set(policy["protected_components"])
        self.protected_filenames = set(policy["protected_filenames"])
        self.protected_suffixes = tuple(policy["protected_suffixes"])
        self.test_commands = {tuple(row) for row in policy["test_build_commands"]}

    def _protected(self, path: Path) -> bool:
        relative = path.relative_to(self.project)
        parts = [part.casefold() for part in relative.parts]
        for part in parts:
            if (part in self.protected_components or part in self.protected_filenames or
                    part == ".env" or part.startswith(".env.") or
                    part.endswith(self.protected_suffixes) or
                    fnmatch.fnmatchcase(part, "*credentials*") or
                    fnmatch.fnmatchcase(part, "*secret*")):
                return True
        return False

    def path(self, text: str, cwd: Path, *, kind: str = "any", relative_only: bool = False) -> Path:
        if not text or any(ord(char) < 32 for char in text) or any(char in text for char in "*?\x00"):
            raise AutoHookError("unsupported-path")
        # Check Windows-specific syntax even in portable unit tests.
        normalized = text.replace("\\", "/")
        parts = normalized.split("/")
        if ".." in parts or normalized.startswith(("//", "~")):
            raise AutoHookError("path-traversal-or-network-path")
        windows_absolute = bool(re.match(r"^[a-zA-Z]:/", normalized))
        if relative_only and (normalized.startswith("/") or windows_absolute):
            raise AutoHookError("absolute-patch-path")
        for index, part in enumerate(parts):
            if index == 0 and windows_absolute:
                continue
            if ":" in part or part.endswith((" ", ".")) and part not in ("", "."):
                raise AutoHookError("alternate-stream-or-ambiguous-path")
            stem = part.split(".")[0].rstrip(" ").casefold()
            if stem in {"con", "prn", "aux", "nul"} or re.fullmatch(r"(?:com|lpt)[1-9¹²³]", stem):
                raise AutoHookError("device-path")
        candidate = Path(text if os.name == "nt" else normalized)
        if not candidate.is_absolute():
            if windows_absolute or normalized.startswith("/") and os.name == "nt":
                raise AutoHookError("ambiguous-absolute-path")
            candidate = cwd / candidate
        lexical = Path(os.path.abspath(candidate))
        resolved = candidate.resolve()
        if not _within(lexical, self.project) or not _within(resolved, self.project):
            raise AutoHookError("outside-project")
        if self._protected(lexical) or self._protected(resolved):
            raise AutoHookError("protected-path")
        if resolved.exists():
            metadata = resolved.stat()
            if stat.S_ISREG(metadata.st_mode) and metadata.st_nlink > 1:
                raise AutoHookError("hard-linked-file")
        if kind == "file" and not resolved.is_file():
            raise AutoHookError("expected-existing-file")
        if kind == "directory" and not resolved.is_dir():
            raise AutoHookError("expected-existing-directory")
        return resolved

    def working_directory(self, value: Any) -> Path:
        if not isinstance(value, str) or not Path(value).is_absolute():
            raise AutoHookError("missing-absolute-working-directory")
        return self.path(value, self.project, kind="directory")

    def command(self, argv: list[str], cwd: Path) -> tuple[list[str], Decision]:
        if not argv or any(not isinstance(item, str) or any(ord(ch) < 32 for ch in item) for item in argv):
            return argv, manual("invalid-command-tokens")
        normalized = list(argv)
        program = argv[0].casefold()
        canonical = {"get-location": "Get-Location", "get-childitem": "Get-ChildItem",
                     "get-content": "Get-Content", **{name: name for name in
                     ("git", "rg", "npm", "pnpm", "pytest", "python", "dotnet", "cargo", "go")}}
        normalized[0] = canonical.get(program, argv[0])
        args = argv[1:]
        try:
            if tuple(normalized) in self.test_commands:
                self._test_project(normalized[0], cwd)
                return normalized, allowed("build.standard", "Exact trusted-project test/build template")
            if program == "get-location" and not args:
                return normalized, allowed("read.location", "Read the project working directory")
            if program in ("get-childitem", "get-content"):
                if len(args) < 2 or args[0].casefold() != "-literalpath":
                    return normalized, manual("literal-path-is-required")
                normalized[1] = "-LiteralPath"
                self.path(args[1], cwd, kind="directory" if program == "get-childitem" else "file")
                tail = args[2:]
                if program == "get-childitem":
                    flags = {"-force", "-name", "-file", "-directory"}
                    if len(set(flag.casefold() for flag in tail)) != len(tail) or any(flag.casefold() not in flags for flag in tail):
                        return normalized, manual("unsupported-list-argument")
                elif tail and not (len(tail) == 1 and tail[0].casefold() == "-raw"):
                    return normalized, manual("unsupported-read-argument")
                return normalized, allowed("read.list" if program == "get-childitem" else "read.content",
                                           "Literal project path and approved read-only arguments")
            if program == "rg":
                if len(args) in (1, 2) and args[0] == "--files":
                    self.path(args[1] if len(args) == 2 else ".", cwd, kind="directory")
                    return normalized, allowed("read.files", "List project filenames")
                if len(args) == 5 and args[:3] == ["-n", "-F", "--"]:
                    self.path(args[4], cwd, kind="file")
                    return normalized, allowed("read.search", "Literal text search in one project file")
                return normalized, manual("unsupported-search-template")
            if program == "git":
                return normalized, self._git(args, cwd)
        except (OSError, RuntimeError, AutoHookError) as error:
            return normalized, manual(str(error) if isinstance(error, AutoHookError) else "path-check-failed")
        return normalized, manual("command-not-in-built-in-templates")

    def _test_project(self, program: str, cwd: Path) -> None:
        markers = {
            "npm": ("package.json",), "pnpm": ("package.json",),
            "pytest": ("pyproject.toml", "pytest.ini", "setup.cfg", "tests", "test"),
            "python": ("pyproject.toml", "pytest.ini", "setup.cfg", "tests", "test"),
            "cargo": ("Cargo.toml",), "go": ("go.mod", "go.work"),
        }
        current = cwd
        while _within(current, self.project):
            candidates = list(markers.get(program, ()))
            if program == "dotnet":
                candidates = [p.name for pattern in ("*.sln", "*.slnx", "*.csproj", "*.fsproj", "*.vbproj")
                              for p in current.glob(pattern)]
            for marker in candidates:
                path = current / marker
                if path.exists():
                    self.path(str(path), cwd)
                    return
            if current == self.project:
                break
            current = current.parent
        raise AutoHookError("no-project-marker-for-test-or-build")

    def _git(self, args: list[str], cwd: Path) -> Decision:
        if args[:1] == ["--no-pager"]:
            args = args[1:]
        if not args:
            return manual("unsupported-git-template")
        action, rest = args[0], args[1:]
        if "--" in rest:
            split = rest.index("--")
            paths, rest = rest[split + 1:], rest[:split]
            for path in paths:
                self.path(path, cwd)
        if action == "status" and all(item in {"--short", "--porcelain", "--porcelain=v1", "--branch", "-s", "-sb"} for item in rest):
            return allowed("git.status", "Git status with read-only arguments")
        if action == "diff":
            flags = {"--no-ext-diff", "--no-textconv", "--stat", "--numstat", "--name-only",
                     "--name-status", "--summary", "--cached", "--staged"}
            if any(item not in flags for item in rest):
                return manual("unsupported-git-diff-argument")
            if not {"--no-ext-diff", "--no-textconv"}.issubset(rest):
                return manual("git-diff-requires-no-ext-diff-and-no-textconv")
            return allowed("git.diff", "Git diff without external diff or textconv programs")
        if action == "ls-files" and all(item in {"--cached", "--modified", "--others", "--exclude-standard", "--stage"} for item in rest):
            return allowed("git.files", "List Git project filenames")
        if action == "log":
            index = 0
            while index < len(rest):
                if rest[index] in {"--oneline", "--stat", "--name-only", "--decorate", "--all"}:
                    index += 1
                elif rest[index] in {"-n", "--max-count"} and index + 1 < len(rest) and re.fullmatch(r"[0-9]{1,3}", rest[index + 1]) and 1 <= int(rest[index + 1]) <= 100:
                    index += 2
                else:
                    return manual("unsupported-git-log-argument")
            return allowed("git.log", "Read Git history without executing diff programs")
        return manual("git-write-or-unsupported-command")

    def patch(self, patch: str, cwd: Path) -> Decision:
        if not isinstance(patch, str) or "\x00" in patch or len(patch.encode("utf-8")) > MAX_INPUT_BYTES:
            return manual("invalid-patch")
        lines = patch.replace("\r\n", "\n").removesuffix("\n").split("\n")
        if not lines or lines[0] != "*** Begin Patch" or lines[-1] != "*** End Patch":
            return manual("unsupported-patch-envelope")
        index = 1
        touched: set[Path] = set()
        try:
            while index < len(lines) - 1:
                header = lines[index]
                if header.startswith("*** Add File: "):
                    operation, name = "add", header[len("*** Add File: "):]
                elif header.startswith("*** Update File: "):
                    operation, name = "update", header[len("*** Update File: "):]
                else:
                    return manual("patch-delete-move-or-unknown-operation")
                path = self.path(name, cwd, kind="file" if operation == "update" else "any", relative_only=True)
                if path in touched or path == self.project:
                    return manual("duplicate-or-invalid-patch-target")
                touched.add(path)
                if operation == "add" and path.exists():
                    return manual("add-target-already-exists")
                index += 1
                saw_hunk = operation == "add"
                hunk_has_line = False
                ended_file = False
                while index < len(lines) - 1 and not lines[index].startswith(("*** Add File: ", "*** Update File: ", "*** Delete File: ")):
                    line = lines[index]
                    if operation == "add":
                        if not line.startswith("+"):
                            return manual("unsupported-add-patch-body")
                    elif ended_file:
                        return manual("data-after-end-of-file")
                    elif line == "@@" or line.startswith("@@ "):
                        saw_hunk = True
                    elif line == "*** End of File" and saw_hunk and hunk_has_line:
                        ended_file = True
                    elif not saw_hunk or not line.startswith((" ", "+", "-")):
                        return manual("unsupported-update-patch-body")
                    else:
                        hunk_has_line = True
                    index += 1
                if operation == "update" and not hunk_has_line:
                    return manual("empty-update-patch")
            if not touched:
                return manual("empty-patch")
            return allowed("patch.project-add-update", "Only add/update operations on unprotected project paths")
        except (OSError, RuntimeError, AutoHookError) as error:
            return manual(str(error) if isinstance(error, AutoHookError) else "patch-path-check-failed")


def evaluate_request(payload: Any, policy: Policy, tools: ProcessTools, assets: Path) -> Decision:
    if not isinstance(payload, dict) or payload.get("hook_event_name") != "PermissionRequest":
        return manual("not-a-permission-request")
    tool = payload.get("tool_name")
    if tool not in {"Bash", "apply_patch"}:
        return manual("unsupported-tool")
    tool_input = payload.get("tool_input")
    if not isinstance(tool_input, dict) or not isinstance(tool_input.get("command"), str):
        return manual("unsupported-tool-input")
    command = tool_input["command"]
    if len(command.encode("utf-8")) > MAX_INPUT_BYTES:
        return manual("command-is-too-large")
    try:
        cwd = policy.working_directory(payload.get("cwd"))
        explicit_cwds = [tool_input[key] for key in ("cwd", "workdir") if key in tool_input]
        if explicit_cwds:
            parsed_cwds = [policy.working_directory(value) for value in explicit_cwds]
            if any(value != parsed_cwds[0] for value in parsed_cwds):
                return manual("conflicting-working-directories")
            cwd = parsed_cwds[0]
        if tool == "apply_patch":
            return policy.patch(command, cwd)
        shell = tool_input.get("shell")
        if shell is not None and (not isinstance(shell, str) or shell.replace("\\", "/").split("/")[-1].casefold() not in
                                  {"powershell", "powershell.exe", "pwsh", "pwsh.exe"}):
            return manual("unsupported-shell")
        argv = tools.parse(command, assets / "parse_powershell.ps1")
        argv, decision = policy.command(argv, cwd)
        if not decision.allowed:
            return decision
        rules = [assets / "default.rules"]
        local_rules = policy.project / ".codex" / "rules"
        if local_rules.exists():
            _safe_target(policy.project, local_rules)
            for rule in sorted(local_rules.glob("*.rules")):
                _safe_target(policy.project, rule)
                rules.append(rule)
        result = tools.execpolicy(argv, rules)
        if result.get("decision") != "allow" or not result["matchedRules"]:
            return manual("native-rule-did-not-explicitly-allow")
        return decision
    except (AutoHookError, OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        return manual(str(error) if isinstance(error, AutoHookError) else "parser-or-rule-check-failed")


def evaluate_installed(project: Path, payload: Any) -> Decision:
    try:
        if os.name != "nt":
            return manual("windows-powershell-is-required")
        assets = runtime_dir(project)
        settings_file = assets / "settings.json"
        _safe_target(project, settings_file)
        settings = _read_json(settings_file)
        _validate_settings(settings, project)
        if settings.get("enabled") is not True:
            return manual("autohook-is-disabled")
        _validate_assets(settings, assets)
        config_path = project / ".codex" / "config.toml"
        _safe_target(project, config_path)
        config = load_toml(config_path.read_text(encoding="utf-8-sig"))
        if any(lookup(config, key) != value for key, value in MANAGED_SETTINGS.items()):
            return manual("project-settings-have-changed")
        tools = _tools_from_settings(settings, project)
        if tools.version() != settings.get("codex_version"):
            return manual("codex-version-changed-run-enable-to-revalidate")
        policy = Policy(project, _read_json(assets / "policy.json"))
        return evaluate_request(payload, policy, tools, assets)
    except (AutoHookError, OSError, ValueError, KeyError, TypeError, RuntimeError, subprocess.SubprocessError) as error:
        return manual(str(error) if isinstance(error, AutoHookError) else "installation-or-compatibility-check-failed")


def _log_decision(project: Path, decision: Decision) -> None:
    path = runtime_dir(project) / "decisions.jsonl"
    _safe_target(project, path)
    if not path.parent.is_dir():
        return
    if path.exists() and path.stat().st_size >= MAX_INPUT_BYTES:
        archive = path.with_name("decisions.previous.jsonl")
        _safe_target(project, archive)
        os.replace(path, archive)
    entry = {"time": datetime.now(timezone.utc).isoformat(), **asdict(decision), "policy_version": VERSION}
    # Do not record commands, transcripts, file contents or credential values.
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(entry, ensure_ascii=True) + "\n")


def _resolve_codex(value: str | None = None) -> str:
    """Use a native exe; never pass untrusted command tokens through a .cmd shim."""
    found = value or shutil.which("codex.exe") or shutil.which("codex")
    if not found:
        raise AutoHookError("codex must be available on PATH, or supplied using --codex")
    path = Path(found).resolve()
    if path.suffix.casefold() == ".exe" and path.is_file():
        return str(path)
    if value is None and path.suffix.casefold() in {".cmd", ".bat", ".ps1"}:
        npm_root = path.parent / "node_modules" / "@openai"
        patterns = (
            "codex/vendor/*/codex/codex.exe",
            "codex/node_modules/@openai/codex-win32-*/vendor/*/codex/codex.exe",
            "codex-win32-*/vendor/*/codex/codex.exe",
        )
        candidates = {p.resolve() for pattern in patterns for p in npm_root.glob(pattern) if p.is_file()}
        if len(candidates) == 1:
            return str(candidates.pop())
    raise AutoHookError("A native codex.exe is required; use enable --codex <path-to-codex.exe>")


@dataclass
class PreparedChange:
    """A project-relative write set. Preparing never changes the project."""
    files: dict[str, bytes | None]
    result: dict[str, Any]


def prepare_enable(project: Path, source: Path | None = None, *, codex: str | None = None,
                   powershell: str | None = None,
                   base_files: dict[str, bytes | None] | None = None) -> PreparedChange:
    if os.name != "nt":
        raise AutoHookError("AutoHook v1 requires Windows PowerShell")
    source = source or Path(__file__).resolve().parent
    codex = _resolve_codex(codex)
    powershell = powershell or shutil.which("powershell.exe")
    if not codex or not powershell:
        raise AutoHookError("codex and powershell.exe must be available on PATH")
    codex, powershell = str(Path(codex).resolve()), str(Path(powershell).resolve())
    if Path(powershell).suffix.casefold() != ".exe":
        raise AutoHookError("A native powershell.exe is required")
    bundle = {name: (source / name).read_bytes() for name in ASSETS}
    policy = json.loads(bundle["policy.json"])
    Policy(project, policy)
    tools = ProcessTools(codex, powershell, project, time.monotonic() + 20)
    version = _compatibility_probe(tools, source)
    assets = runtime_dir(project)
    config_path, hooks_path = project / ".codex" / "config.toml", project / ".codex" / "hooks.json"
    settings_path = assets / "settings.json"
    ignore_path = assets / ".gitignore"
    paths = [config_path, hooks_path, settings_path, ignore_path] + [assets / name for name in ASSETS]
    for path in paths:
        _safe_target(project, path)
    if assets.exists() and any(assets.iterdir()) and not settings_path.exists():
        raise AutoHookError("The AutoHook directory already contains unmanaged files")
    config_raw, hooks_raw = _read_optional(config_path), _read_optional(hooks_path)
    if base_files is not None:
        config_raw, hooks_raw = base_files[".codex/config.toml"], base_files[".codex/hooks.json"]
    config_text = (config_raw or b"").decode("utf-8-sig")
    load_toml(config_text)
    hooks = _load_hooks(hooks_raw)
    previous: dict[str, Any] | None = None
    if settings_path.exists():
        previous = _read_json(settings_path)
        _validate_settings(previous, project, require_policy=False)
    continuing = previous is not None and (previous.get("enabled") is True or previous.get("cleanup_complete") is False)
    if continuing:
        _remove_handler(hooks, previous["hook_handler"])
    for key, value in MANAGED_SETTINGS.items():
        config_text = edit_toml(config_text, key, value)
    new_config = config_text.encode("utf-8")
    handler = _hook_handler(project, str(Path(sys.executable).resolve()))
    _remove_handler(hooks, handler)
    hooks["hooks"].setdefault("PermissionRequest", []).append({"matcher": "^(Bash|apply_patch)$", "hooks": [handler]})
    new_hooks = _json_bytes(hooks)
    backup = previous["backup"] if continuing and base_files is None else {"config_original": _pack(config_raw), "hooks_original": _pack(hooks_raw)}
    settings = {
        "schema_version": 1, "policy_version": VERSION, "enabled": True, "cleanup_complete": False,
        "project": str(project),
        "codex_path": codex, "powershell_path": powershell, "codex_version": version,
        "asset_sha256": {name: hashlib.sha256(raw).hexdigest() for name, raw in bundle.items()},
        "hook_handler": handler, "backup": backup,
        "config_installed": _pack(new_config), "hooks_installed": _pack(new_hooks),
    }
    if len(_json_bytes(settings)) > MAX_INPUT_BYTES:
        raise AutoHookError("Project settings are too large to back up safely")
    files = {f".codex/autohook/{name}": raw for name, raw in bundle.items()}
    files.update({".codex/autohook/.gitignore": b"*\n", ".codex/config.toml": new_config,
                  ".codex/hooks.json": new_hooks, ".codex/autohook/settings.json": _json_bytes(settings)})
    return PreparedChange(files, {"enabled": True, "project": str(project), "policy_version": VERSION,
                                 "codex_version": version, "trust_required": True})


def apply_prepared(project: Path, change: PreparedChange) -> dict[str, Any]:
    paths = [project / name for name in change.files]
    for path in paths:
        _safe_target(project, path)
    snapshot = {path: _read_optional(path) for path in paths}
    settings_path = runtime_dir(project) / "settings.json"
    try:
        if ".codex/autohook/settings.json" in change.files:
            settings = json.loads(change.files[".codex/autohook/settings.json"])
            _atomic_write(project, settings_path, _json_bytes({**settings, "enabled": False}))
        for name, raw in change.files.items():
            if name != ".codex/autohook/settings.json":
                _restore_file(project, project / name, raw)
        if ".codex/autohook/settings.json" in change.files:
            _restore_file(project, settings_path, change.files[".codex/autohook/settings.json"])
    except Exception:
        # Restore assets/config before republishing the old enabled state.
        for path, raw in snapshot.items():
            if path != settings_path:
                _restore_file(project, path, raw)
        if settings_path in snapshot:
            _restore_file(project, settings_path, snapshot[settings_path])
        raise
    return change.result


def enable(project: Path, source: Path | None = None, *, codex: str | None = None,
           powershell: str | None = None) -> dict[str, Any]:
    return apply_prepared(project, prepare_enable(project, source, codex=codex, powershell=powershell))


def prepare_disable(project: Path) -> PreparedChange:
    assets = runtime_dir(project)
    settings_path = assets / "settings.json"
    _safe_target(project, settings_path)
    if not settings_path.exists():
        return PreparedChange({}, {"enabled": False, "project": str(project), "messages": ["AutoHook is not installed"]})
    settings = _read_json(settings_path)
    _validate_settings(settings, project, require_policy=False)
    if settings.get("enabled") is not True and settings.get("cleanup_complete") is True:
        return PreparedChange({}, {"enabled": False, "project": str(project), "messages": ["AutoHook is already disabled"]})
    files: dict[str, bytes | None] = {}
    messages: list[str] = []
    config_path, hooks_path = project / ".codex" / "config.toml", project / ".codex" / "hooks.json"
    for path in (config_path, hooks_path):
        _safe_target(project, path)
    current_hooks = _read_optional(hooks_path)
    if current_hooks == _unpack(settings["hooks_installed"]):
        files[".codex/hooks.json"] = _unpack(settings["backup"]["hooks_original"])
    elif current_hooks is not None:
        hooks = _load_hooks(current_hooks)
        _remove_handler(hooks, settings["hook_handler"])
        files[".codex/hooks.json"] = _json_bytes(hooks)
        messages.append("Preserved unrelated hook edits")
    current_config = _read_optional(config_path)
    if current_config == _unpack(settings["config_installed"]):
        files[".codex/config.toml"] = _unpack(settings["backup"]["config_original"])
    elif current_config is not None:
        text = current_config.decode("utf-8-sig")
        original_raw = _unpack(settings["backup"]["config_original"])
        original = load_toml((original_raw or b"").decode("utf-8-sig"))
        for key, installed_value in MANAGED_SETTINGS.items():
            if lookup(load_toml(text), key) == installed_value:
                text = edit_toml(text, key, lookup(original, key))
            else:
                messages.append("Preserved user edit to " + ".".join(key))
        files[".codex/config.toml"] = text.encode("utf-8")
        messages.append("Preserved unrelated config edits")
    files[".codex/autohook/settings.json"] = _json_bytes({**settings, "enabled": False, "cleanup_complete": True})
    return PreparedChange(files, {"enabled": False, "project": str(project), "messages": messages})


def disable(project: Path) -> dict[str, Any]:
    settings_path = runtime_dir(project) / "settings.json"
    _safe_target(project, settings_path)
    if settings_path.exists():
        settings = _read_json(settings_path)
        _validate_settings(settings, project, require_policy=False)
        if settings.get("enabled") is True:
            # The standalone CLI remains fail-closed even if a malformed hook
            # prevents preparing the cleanup. The installer uses its journal.
            _atomic_write(project, settings_path, _json_bytes({**settings, "enabled": False, "cleanup_complete": False}))
    return apply_prepared(project, prepare_disable(project))


def status(project: Path) -> dict[str, Any]:
    result: dict[str, Any] = {"enabled": False, "configuration_ready": False, "project": str(project), "messages": []}
    try:
        assets = runtime_dir(project)
        _safe_target(project, assets / "settings.json")
        if not (assets / "settings.json").exists():
            result["messages"].append("AutoHook is not installed")
            return result
        settings = _read_json(assets / "settings.json")
        _validate_settings(settings, project, require_policy=False)
        result["enabled"] = settings.get("enabled") is True
        result["policy_version"] = VERSION
        if not result["enabled"]:
            return result
        if settings.get("policy_version") != VERSION:
            raise AutoHookError("AutoHook policy version changed; run enable again to update")
        _validate_assets(settings, assets)
        _safe_target(project, project / ".codex" / "config.toml")
        _safe_target(project, project / ".codex" / "hooks.json")
        config = load_toml((project / ".codex" / "config.toml").read_text(encoding="utf-8-sig"))
        if any(lookup(config, key) != value for key, value in MANAGED_SETTINGS.items()):
            raise AutoHookError("Project approval settings have changed")
        hooks = _load_hooks(_read_optional(project / ".codex" / "hooks.json"))
        if not _has_handler(hooks, settings["hook_handler"]):
            raise AutoHookError("AutoHook PermissionRequest handler is missing or changed")
        tools = _tools_from_settings(settings, project)
        current_version = _compatibility_probe(tools, assets)
        result["codex_version"] = current_version
        if current_version != settings["codex_version"]:
            raise AutoHookError("Codex version changed; run enable again to revalidate")
        result["configuration_ready"] = True
        result["messages"].append("Review project trust and the hook in Codex /hooks; persisted trust is not checked here")
        result["messages"].append("CLI/profile/managed settings and other hooks can affect the final approval flow")
    except (AutoHookError, OSError, ValueError, KeyError, TypeError, RuntimeError, subprocess.SubprocessError) as error:
        result["messages"].append(str(error) if isinstance(error, AutoHookError) else "Configuration/compatibility check failed")
    return result


def _project(value: str) -> Path:
    project = Path(value).resolve(strict=True)
    if not project.is_dir() or project.parent == project:
        raise AutoHookError("--project must name an existing project directory")
    return project


def _stdin_payload() -> Any:
    raw = sys.stdin.buffer.read(MAX_INPUT_BYTES + 1)
    if len(raw) > MAX_INPUT_BYTES:
        raise AutoHookError("hook-input-too-large")
    return json.loads(raw.decode("utf-8-sig"))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Project-scoped Codex approvals with explicit rules; no AI reviewer")
    parser.add_argument("--version", action="version", version=f"AutoHook {VERSION}")
    sub = parser.add_subparsers(dest="action", required=True)
    for action in ("enable", "disable", "status", "check", "hook"):
        command = sub.add_parser(action)
        command.add_argument("--project", default=".", help="Project directory (default: current directory)")
        if action in {"enable", "disable", "status"}:
            command.add_argument("--json", action="store_true", help="Print machine-readable status")
        if action == "enable":
            command.add_argument("--codex", help="Absolute path to a native codex.exe (optional)")
        if action == "check":
            group = command.add_mutually_exclusive_group(required=True)
            group.add_argument("--command", help="Inspect a PowerShell command without executing it")
            group.add_argument("--patch", type=Path, help="Inspect an apply_patch text file")
            group.add_argument("--input", type=Path, help="Inspect a PermissionRequest JSON file; '-' reads stdin")
            command.add_argument("--cwd", help="Working directory for --command/--patch")
    args = parser.parse_args(argv)
    try:
        project = _project(args.project)
        if args.action == "hook":
            try:
                decision = evaluate_installed(project, _stdin_payload())
            except (AutoHookError, OSError, ValueError, TypeError, UnicodeError):
                decision = manual("invalid-hook-input")
            try:
                _log_decision(project, decision)
            except (AutoHookError, OSError, ValueError, RuntimeError):
                decision = manual("decision-log-unavailable")
            if decision.allowed:
                print(json.dumps(ALLOW_OUTPUT, separators=(",", ":")))
            return 0
        if args.action == "check":
            if args.input is not None:
                payload = _stdin_payload() if str(args.input) == "-" else _read_json(args.input)
            else:
                command = args.command if args.command is not None else args.patch.read_text(encoding="utf-8-sig")
                payload = {"hook_event_name": "PermissionRequest", "tool_name": "Bash" if args.command is not None else "apply_patch",
                           "cwd": str(Path(args.cwd).resolve()) if args.cwd else str(project), "tool_input": {"command": command}}
            print(json.dumps(asdict(evaluate_installed(project, payload)), ensure_ascii=True, indent=2))
            return 0
        if args.action == "enable":
            result = enable(project, codex=args.codex)
        else:
            result = {"disable": disable, "status": status}[args.action](project)
        if args.json:
            print(json.dumps(result, ensure_ascii=True, indent=2))
        else:
            print(f"AutoHook {'enabled' if result['enabled'] else 'disabled'}: {project}")
            if args.action == "enable":
                print("Restart Codex in this project; review project trust and the new hook using /hooks.")
                print("Use status and check to inspect configuration and rule decisions.")
            for message in result.get("messages", []):
                print(message)
        return 1 if args.action == "status" and result["enabled"] and not result["configuration_ready"] else 0
    except (AutoHookError, OSError, ValueError, KeyError, TypeError, RuntimeError, subprocess.SubprocessError) as error:
        if args.action == "hook":
            # Empty stdout + exit 0 means normal manual approval, never a deny.
            return 0
        print(f"AutoHook: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    raise SystemExit(main())
