#!/usr/bin/env python3
"""check-stale.py — 比對 wiki frontmatter sources 與實際檔案，找出陳舊頁面。

用法：
    python .agents/skills/codebase-wiki/scripts/check-stale.py [wiki_dir] [repo_root]

預設 wiki_dir 為 wiki/，repo_root 為當前目錄。
"""

import argparse
import pathlib
import datetime as _datetime
import hashlib
import re
import subprocess
from offline_git import ProcessLimitError, run_git
import sys
from typing import Any

from frontmatter import configure_utf8_stdio, parse_frontmatter_text, validate_regular_tree


DIGEST_EXCLUDED_PARTS = {
    ".bundle",
    ".git",
    ".gradle",
    ".m2",
    ".notebooklm",
    ".nuget",
    ".pnpm-store",
    ".venv",
    ".yarn",
    "__pycache__",
    "bin",
    "build",
    "cache",
    "coverage",
    "dist",
    "logs",
    "node_modules",
    "obj",
    "target",
    "vendor",
    "wiki",
}


def digest_excluded(relative: pathlib.Path) -> bool:
    return bool(set(relative.parts) & DIGEST_EXCLUDED_PARTS)


def parse_frontmatter(filepath: pathlib.Path) -> dict:
    """解析 markdown 檔案的 YAML frontmatter。"""
    return parse_frontmatter_text(filepath.read_text(encoding="utf-8"))


def git_dirty_paths(repo_root: pathlib.Path) -> set[str]:
    try:
        result = run_git(repo_root, "status", "--porcelain", "-z", "--untracked-files=all")
    except (OSError, subprocess.CalledProcessError, ProcessLimitError):
        return set()
    paths: set[str] = set()
    records = iter(result.stdout.split("\0"))
    for line in records:
        if len(line) < 4:
            continue
        value = line[3:]
        if "R" in line[:2] or "C" in line[:2]:
            next(records, None)  # -z emits destination then original name.
        paths.add(value.replace("\\", "/"))
    return paths


def latest_source_date(repo_root: pathlib.Path, source: str) -> _datetime.date | None:
    try:
        result = run_git(repo_root, "log", "-1", "--format=%cs", "--", source)
        value = result.stdout.strip()
        return _datetime.date.fromisoformat(value) if value else None
    except (OSError, subprocess.CalledProcessError, ProcessLimitError, ValueError):
        return None


def _source_path(repo_root: pathlib.Path, source: str) -> pathlib.Path:
    """Resolve a validated repo-relative source independent of host separators."""

    normalized = source.replace("\\", "/").rstrip("/")
    pure = pathlib.PurePosixPath(normalized)
    return repo_root.joinpath(*pure.parts)


def _filesystem_source_files(
    repo_root: pathlib.Path, source_path: pathlib.Path
) -> list[pathlib.Path]:
    """Enumerate a source directory without descending into digest exclusions."""

    pending = [source_path]
    candidates: list[pathlib.Path] = []
    resolved_root = repo_root.resolve()
    while pending:
        current = pending.pop()
        try:
            entries = sorted(current.iterdir(), key=lambda item: item.name)
        except OSError:
            continue
        for path in entries:
            try:
                relative = path.resolve().relative_to(resolved_root)
            except ValueError:
                continue
            if digest_excluded(relative):
                continue
            try:
                if path.is_dir() and not path.is_symlink():
                    pending.append(path)
                elif path.is_file() or path.is_symlink():
                    candidates.append(path)
            except OSError:
                continue
    return candidates


def _source_files(
    repo_root: pathlib.Path, source: str, *, use_git: bool = True
) -> list[pathlib.Path]:
    source_path = _source_path(repo_root, source).resolve()
    try:
        source_path.relative_to(repo_root.resolve())
    except ValueError:
        return []
    if source_path.is_file():
        return [source_path]
    if not source_path.is_dir():
        return []

    if not use_git:
        candidates = _filesystem_source_files(repo_root, source_path)
    else:
        relative_source = source_path.relative_to(repo_root.resolve()).as_posix()
        try:
            result = run_git(repo_root,
                    "ls-files",
                    "--cached",
                    "--others",
                    "--exclude-standard",
                    "-z",
                    "--",
                    relative_source,
                text=False,
            )
            candidates = [
                repo_root / value.decode("utf-8", errors="surrogateescape")
                for value in result.stdout.split(b"\0")
                if value
            ]
        except (OSError, subprocess.CalledProcessError, ProcessLimitError):
            candidates = _filesystem_source_files(repo_root, source_path)

    files: list[pathlib.Path] = []
    for path in candidates:
        if not path.is_file():
            continue
        try:
            relative = path.resolve().relative_to(repo_root.resolve())
        except ValueError:
            continue
        if digest_excluded(relative):
            continue
        files.append(path)
    return sorted(set(files), key=lambda item: item.resolve().as_posix())


def hash_source_file(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


class SourceCache:
    """One check's source snapshot; never retain Git/filesystem data across calls."""

    def __init__(self, repo_root: pathlib.Path, use_git: bool, source_hashes: dict | None = None):
        self.repo_root = repo_root
        self.use_git = use_git
        self.dates: dict[str, _datetime.date | None] = {}
        self.files: dict[str, list[pathlib.Path]] = {}
        self.hashes: dict[pathlib.Path, str] = {path.resolve(): digest for path, digest in (source_hashes or {}).items()}

    @staticmethod
    def key(source: str) -> str:
        return source.replace("\\", "/").rstrip("/")

    def latest_date(self, source: str) -> _datetime.date | None:
        key = self.key(source)
        if key not in self.dates:
            self.dates[key] = latest_source_date(self.repo_root, key)
        return self.dates[key]

    def source_files(self, source: str) -> list[pathlib.Path]:
        key = self.key(source)
        if key not in self.files:
            self.files[key] = _source_files(self.repo_root, key, use_git=self.use_git)
        return self.files[key]

    def file_digest(self, path: pathlib.Path) -> str:
        key = path.resolve()
        if key not in self.hashes:
            self.hashes[key] = hash_source_file(path)
        return self.hashes[key]


def compute_source_digest(
    repo_root: pathlib.Path, sources: list[str], *, use_git: bool = True,
    cache: SourceCache | None = None,
) -> str:
    """Return the stable aggregate digest for existing raw source files."""

    cache = cache if cache is not None else SourceCache(repo_root, use_git)
    records: dict[str, str] = {}
    for source in sources:
        for path in cache.source_files(source):
            relative = path.resolve().relative_to(repo_root.resolve()).as_posix()
            records[relative] = cache.file_digest(path)
    aggregate = hashlib.sha256()
    for relative, digest in sorted(records.items()):
        aggregate.update(relative.encode("utf-8"))
        aggregate.update(b"\0")
        aggregate.update(digest.encode("ascii"))
        aggregate.update(b"\n")
    return f"sha256:{aggregate.hexdigest()}"


def check_stale(
    wiki_dir: pathlib.Path, repo_root: pathlib.Path, *, use_git: bool = True,
    page_frontmatter: dict | None = None, source_hashes: dict | None = None,
):
    """檢查每個 wiki 頁面的 sources 是否仍存在。"""
    validate_regular_tree(wiki_dir)
    md_files = sorted(wiki_dir.rglob("*.md"))
    results: dict[str, list[Any]] = {"critical": [], "warning": [], "ok": []}

    dirty_paths = git_dirty_paths(repo_root) if use_git else set()
    cache = SourceCache(repo_root, use_git, source_hashes)
    for fp in md_files:
        fm = page_frontmatter[fp] if page_frontmatter is not None and fp in page_frontmatter else parse_frontmatter(fp)
        sources = fm.get("sources", [])
        if not sources:
            continue

        title = fm.get("title", fp.stem)
        rel_path = fp.relative_to(wiki_dir)
        try:
            repo_page_path = fp.resolve().relative_to(repo_root.resolve()).as_posix()
        except ValueError:
            repo_page_path = ""
        page_is_dirty = repo_page_path in dirty_paths
        # Exact content fingerprints determine freshness without one Git log
        # process per source. Legacy pages still use commit dates as a fallback.
        has_content_digest = bool(re.fullmatch(r"sha256:[0-9a-f]{64}", str(fm.get("source_digest", ""))))
        missing = []
        existing = []
        stale = []
        invalid = []
        digest_mismatch = None

        if not isinstance(sources, list):
            results["critical"].append({"page": str(rel_path), "title": title, "invalid_sources": "sources must be a list"})
            continue
        page_date = None
        try:
            page_date = _datetime.date.fromisoformat(str(fm.get("last_updated", "")))
        except ValueError:
            pass

        for src in sources:
            normalized_source = src.replace("\\", "/") if isinstance(src, str) else ""
            pure_source = pathlib.PurePath(normalized_source) if isinstance(src, str) else None
            if (
                not isinstance(src, str)
                or not src.strip()
                or pure_source is None
                or pure_source.is_absolute()
                or ".." in pure_source.parts
                or re.fullmatch(r"[A-Za-z]:.*", normalized_source)
            ):
                invalid.append(src)
                continue
            src_path = _source_path(repo_root, src)
            try:
                src_path.resolve(strict=False).relative_to(repo_root.resolve())
            except ValueError:
                invalid.append(src)
                continue
            # 檢查檔案或目錄是否存在
            if src_path.exists() or src_path.is_dir():
                existing.append(src)
            else:
                # 若路徑以 / 結尾，也嘗試不帶 / 的目錄
                if src_path.exists():
                    existing.append(src)
                else:
                    missing.append(src)
                    continue
            normalized = src.rstrip("/").replace("\\", "/")
            dirty = not page_is_dirty and (
                normalized in dirty_paths
                or any(item.startswith(normalized + "/") for item in dirty_paths)
            )
            changed_after_page = bool(
                use_git
                and not has_content_digest
                and page_date
                and (latest := cache.latest_date(normalized))
                and latest > page_date
            )
            if dirty or changed_after_page:
                stale.append(src)

        declared_digest = fm.get("source_digest")
        if isinstance(declared_digest, str) and existing and not missing and not invalid:
            current_digest = compute_source_digest(repo_root, existing, use_git=use_git, cache=cache)
            if declared_digest != current_digest:
                digest_mismatch = {
                    "declared": declared_digest,
                    "current": current_digest,
                }
            else:
                # A matching content fingerprint is stronger evidence than Git
                # commit dates or dirty-path heuristics.
                stale = []

        if invalid:
            results["critical"].append({"page": str(rel_path), "title": title, "invalid_sources": invalid})
        elif missing and not existing:
            results["critical"].append({
                "page": str(rel_path),
                "title": title,
                "all_missing": missing,
            })
        elif missing or stale or digest_mismatch:
            warning = {
                "page": str(rel_path),
                "title": title,
                "missing": missing,
                "existing": existing,
                "stale": stale,
            }
            if digest_mismatch:
                warning["digest_mismatch"] = digest_mismatch
            results["warning"].append(warning)
        else:
            results["ok"].append(str(rel_path))

    return results


def main(argv: list[str] | None = None):
    configure_utf8_stdio()
    parser = argparse.ArgumentParser(
        prog="check-stale.py",
        description="Check Wiki sources for missing or stale raw files.",
    )
    parser.add_argument("wiki_dir", nargs="?", type=pathlib.Path, default=pathlib.Path("wiki"))
    parser.add_argument("repo_root", nargs="?", type=pathlib.Path, default=pathlib.Path("."))
    args = parser.parse_args(argv)
    wiki_dir = args.wiki_dir
    repo_root = args.repo_root

    if not wiki_dir.is_dir():
        print(f"Error: wiki directory not found: {wiki_dir}", file=sys.stderr)
        sys.exit(1)

    try:
        results = check_stale(wiki_dir, repo_root)
    except (OSError, UnicodeError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(2)

    print("=" * 60)
    print("Wiki Stale Check Report")
    print("=" * 60)

    if results["critical"]:
        print(f"\n🔴 CRITICAL — Invalid or missing sources ({len(results['critical'])} pages):\n")
        for item in results["critical"]:
            print(f"  {item['page']} ({item['title']})")
            if "invalid_sources" in item:
                invalid = item["invalid_sources"]
                values = invalid if isinstance(invalid, list) else [invalid]
                for src in values:
                    print(f"    invalid: {src}")
            for src in item.get("all_missing", []):
                print(f"    missing: {src}")

    if results["warning"]:
        print(f"\n🟡 WARNING — Some sources missing or stale ({len(results['warning'])} pages):\n")
        for item in results["warning"]:
            print(f"  {item['page']} ({item['title']})")
            if item.get("missing"):
                print(f"    missing: {', '.join(item['missing'])}")
            if item.get("stale"):
                print(f"    stale: {', '.join(item['stale'])}")
            if item.get("digest_mismatch"):
                mismatch = item["digest_mismatch"]
                print(f"    source_digest: {mismatch['declared']} -> {mismatch['current']}")
            for src in item["missing"]:
                print(f"    ✗ {src}")

    ok_count = len(results["ok"])
    total = ok_count + len(results["critical"]) + len(results["warning"])
    print(f"\n🟢 OK: {ok_count}/{total} pages have no missing or stale sources.\n")

    if results["critical"] or results["warning"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
