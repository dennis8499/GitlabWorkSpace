"""Isolated, current-login Codex reviews for one PermissionRequest.

Only the transcript explicitly supplied by this Hook is read. No credentials are
opened here, and reviewed actions are never executed by this module.
"""
from __future__ import annotations

import ctypes
import hashlib
import json
import os
from pathlib import Path
import queue
import re
import signal
import stat
import subprocess
import tempfile
import threading
import time
from typing import Any

DEFAULT_REVIEWER = {"model": "gpt-6-luna", "reasoning_effort": "low", "timeout_seconds": 30}
EFFORTS = frozenset({"none", "minimal", "low", "medium", "high", "xhigh", "max", "ultra"})
MAX_TRANSCRIPT_BYTES = 8 * 1024 * 1024
MAX_CONTEXT_BYTES = 64 * 1024
MAX_ACTION_BYTES = 256 * 1024
MAX_OUTPUT_BYTES = 1024 * 1024
MAX_LINE_BYTES = 512 * 1024
DISABLED_FEATURES = ("hooks", "plugins", "apps", "shell_tool", "multi_agent", "multi_agent_v2",
                     "code_mode_host", "browser_use", "browser_use_external", "in_app_browser",
                     "computer_use", "image_generation", "goals", "memories", "skill_search",
                     "tool_suggest", "view_image", "sleep_tool")


class ReviewerError(Exception):
    """An intentionally non-sensitive failure code suitable for the decision log."""


def validate_settings(value: Any) -> dict[str, Any]:
    if value is None:
        value = {}
    if not isinstance(value, dict) or set(value) - set(DEFAULT_REVIEWER):
        raise ReviewerError("reviewer-invalid-settings")
    result = {**DEFAULT_REVIEWER, **value}
    if not isinstance(result["model"], str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}", result["model"]):
        raise ReviewerError("reviewer-invalid-model")
    if not isinstance(result["reasoning_effort"], str) or result["reasoning_effort"] not in EFFORTS:
        raise ReviewerError("reviewer-invalid-effort")
    if type(result["timeout_seconds"]) is not int or result["timeout_seconds"] != 30:
        raise ReviewerError("reviewer-invalid-timeout")
    return result


def _json(raw: Any) -> Any:
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate JSON key")
            result[key] = value
        return result
    def constant(_value):
        raise ValueError("non-finite JSON value")
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)


def _remaining(deadline: float) -> float:
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise ReviewerError("reviewer-timeout")
    return remaining


def _within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _regular(path: Path) -> Path:
    """Reject links, reparse points and hard links before opening local evidence."""
    if not path.is_absolute():
        raise ReviewerError("reviewer-invalid-transcript")
    for part in (path, *path.parents):
        info = part.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise ReviewerError("reviewer-invalid-transcript")
    info = path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ReviewerError("reviewer-invalid-transcript")
    return path.resolve(strict=True)


def _text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(item["text"] for item in content if isinstance(item, dict)
                         and isinstance(item.get("text"), str) and item.get("type") in {"input_text", "output_text", "text"})
    return ""


def transcript_context(payload: dict[str, Any], settings: dict[str, Any], deadline: float) -> dict[str, Any]:
    """Read a bounded recent window from this Hook's corroborated session file."""
    session = payload.get("session_id")
    if not isinstance(session, str) or not re.fullmatch(r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", session):
        raise ReviewerError("reviewer-missing-session-context")
    supplied = payload.get("transcript_path")
    if not isinstance(supplied, str) or not supplied or "\x00" in supplied:
        raise ReviewerError("reviewer-missing-session-context")
    project = Path(settings["project"]).resolve(strict=True)
    cwd_value = payload.get("cwd")
    if not isinstance(cwd_value, str) or not Path(cwd_value).is_absolute():
        raise ReviewerError("reviewer-invalid-context-cwd")
    cwd = Path(cwd_value).resolve(strict=True)
    if not _within(cwd, project):
        raise ReviewerError("reviewer-invalid-context-cwd")
    path = _regular(Path(supplied))
    home = Path(os.environ.get("CODEX_HOME", str(Path.home() / ".codex"))).resolve()
    if not (_within(path, home / "sessions") or _within(path, project / ".codex")):
        raise ReviewerError("reviewer-untrusted-transcript-location")
    _remaining(deadline)
    with path.open("rb") as stream:
        before = os.fstat(stream.fileno())
        head = stream.read(64 * 1024)
        offset = max(0, before.st_size - MAX_TRANSCRIPT_BYTES)
        stream.seek(offset)
        if offset:
            stream.readline(MAX_LINE_BYTES + 1)
        tail = stream.read(MAX_TRANSCRIPT_BYTES + 1)
        after = os.fstat(stream.fileno())
    if before.st_ino != after.st_ino or before.st_size != after.st_size or len(tail) > MAX_TRANSCRIPT_BYTES:
        raise ReviewerError("reviewer-transcript-changed")
    metadata = None
    for raw in head.splitlines():
        try:
            record = _json(raw)
        except (ValueError, UnicodeError):
            continue
        if isinstance(record, dict) and record.get("type") == "session_meta":
            metadata = record.get("payload")
            break
    if not isinstance(metadata, dict) or not isinstance(metadata.get("id"), str) or metadata["id"].lower() != session.lower():
        raise ReviewerError("reviewer-session-mismatch")
    meta_cwd = metadata.get("cwd")
    if not isinstance(meta_cwd, str) or not _within(Path(meta_cwd).resolve(), project):
        raise ReviewerError("reviewer-session-mismatch")
    entries: list[dict[str, str]] = []
    current_turn = None
    truncated = offset > 0
    for raw in tail.splitlines():
        _remaining(deadline)
        if len(raw) > MAX_LINE_BYTES:
            truncated = True
            continue
        try:
            record = _json(raw)
        except (ValueError, UnicodeError):
            # A currently appended partial record is not safe authorization evidence.
            raise ReviewerError("reviewer-invalid-transcript")
        if not isinstance(record, dict) or not isinstance(record.get("payload"), dict):
            continue
        item = record["payload"]
        if record.get("type") == "event_msg" and item.get("type") == "thread_rolled_back":
            raise ReviewerError("reviewer-unsupported-rollback-context")
        if record.get("type") == "turn_context":
            current_turn = item
            continue
        role, text = "", ""
        if record.get("type") == "event_msg" and item.get("type") == "user_message":
            role, text = "user", _text(item.get("message"))
        elif record.get("type") == "response_item":
            if item.get("type") == "message" and item.get("role") in {"user", "assistant", "tool", "developer", "system"}:
                role = "contextual_evidence" if item["role"] == "user" else item["role"]
                text = _text(item.get("content"))
            elif item.get("type") in {"function_call_output", "custom_tool_call_output"}:
                role, text = "tool", _text(item.get("output"))
            elif item.get("type") in {"function_call", "custom_tool_call"}:
                role, text = "assistant_tool_request", json.dumps(item, ensure_ascii=True)
        if not text:
            continue
        if role == "user" and entries and entries[-1] == {"role": role, "text": text}:
            continue
        encoded = text.encode("utf-8")
        if len(encoded) > 8192:
            text = encoded[:4096].decode("utf-8", errors="ignore") + "\n<autohook_omitted />\n" + encoded[-4096:].decode("utf-8", errors="ignore")
            truncated = True
        entries.append({"role": role, "text": text})
    if current_turn is not None:
        if not isinstance(current_turn.get("cwd"), str) or Path(current_turn["cwd"]).resolve() != cwd:
            raise ReviewerError("reviewer-turn-mismatch")
        if payload.get("turn_id") is not None and current_turn.get("turn_id") != payload["turn_id"]:
            raise ReviewerError("reviewer-turn-mismatch")
    elif payload.get("turn_id") is not None or Path(meta_cwd).resolve() != cwd:
        raise ReviewerError("reviewer-turn-mismatch")
    kept: list[dict[str, str]] = []
    size = 0
    for entry in reversed(entries):
        length = len(json.dumps(entry, ensure_ascii=False).encode("utf-8"))
        if size + length > MAX_CONTEXT_BYTES:
            truncated = True
            break
        kept.append(entry)
        size += length
    kept.reverse()
    if not any(entry["role"] == "user" for entry in kept):
        raise ReviewerError("reviewer-missing-user-context")
    return {"session_id": session, "cwd": str(cwd), "messages": kept, "context_truncated": truncated}


class _ProcessTree:
    """Own a Windows kill-on-close Job, or a POSIX process group in tests."""
    def __init__(self, argv: list[str], *, cwd: Path, env: dict[str, str]):
        self.job = None
        self.kernel = None
        if os.name == "nt":
            from ctypes import wintypes
            class IO(ctypes.Structure):
                _fields_ = [(name, ctypes.c_ulonglong) for name in ("ReadOperationCount", "WriteOperationCount", "OtherOperationCount", "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]
            class BASIC(ctypes.Structure):
                _fields_ = [("PerProcessUserTimeLimit", ctypes.c_longlong), ("PerJobUserTimeLimit", ctypes.c_longlong), ("LimitFlags", wintypes.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t), ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", wintypes.DWORD), ("Affinity", ctypes.c_size_t), ("PriorityClass", wintypes.DWORD), ("SchedulingClass", wintypes.DWORD)]
            class EXTENDED(ctypes.Structure):
                _fields_ = [("BasicLimitInformation", BASIC), ("IoInfo", IO), ("ProcessMemoryLimit", ctypes.c_size_t), ("JobMemoryLimit", ctypes.c_size_t), ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t)]
            kernel = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel.CreateJobObjectW.argtypes = (ctypes.c_void_p, wintypes.LPCWSTR)
            kernel.CreateJobObjectW.restype = wintypes.HANDLE
            kernel.SetInformationJobObject.argtypes = (wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD)
            kernel.AssignProcessToJobObject.argtypes = (wintypes.HANDLE, wintypes.HANDLE)
            kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
            kernel.TerminateJobObject.argtypes = (wintypes.HANDLE, wintypes.UINT)
            kernel.QueryInformationJobObject.argtypes = (wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p)
            job = kernel.CreateJobObjectW(None, None)
            info = EXTENDED()
            info.BasicLimitInformation.LimitFlags = 0x2000
            if not job or not kernel.SetInformationJobObject(job, 9, ctypes.byref(info), ctypes.sizeof(info)):
                if job:
                    kernel.CloseHandle(job)
                raise ReviewerError("reviewer-process-isolation-unavailable")
            self.job, self.kernel = job, kernel
        try:
            self.process = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                            stderr=subprocess.DEVNULL, shell=False,
                                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) | (0x4 if os.name == "nt" else 0),
                                            start_new_session=os.name != "nt")
            if self.job and not self.kernel.AssignProcessToJobObject(self.job, int(self.process._handle)):
                self.process.kill()
                self.process.wait(timeout=2)
                raise ReviewerError("reviewer-process-isolation-unavailable")
            if self.job:
                self._resume()
        except BaseException:
            if self.job:
                self.kernel.CloseHandle(self.job)
                self.job = None
            raise

    def _resume(self) -> None:
        # Popen closes the primary thread handle; reopen our suspended child's
        # thread through documented Toolhelp APIs after Job assignment.
        from ctypes import wintypes
        class THREAD(ctypes.Structure):
            _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD), ("th32ThreadID", wintypes.DWORD), ("th32OwnerProcessID", wintypes.DWORD), ("tpBasePri", wintypes.LONG), ("tpDeltaPri", wintypes.LONG), ("dwFlags", wintypes.DWORD)]
        kernel = self.kernel
        kernel.CreateToolhelp32Snapshot.argtypes = (wintypes.DWORD, wintypes.DWORD)
        kernel.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
        kernel.Thread32First.argtypes = (wintypes.HANDLE, ctypes.POINTER(THREAD))
        kernel.Thread32Next.argtypes = (wintypes.HANDLE, ctypes.POINTER(THREAD))
        kernel.OpenThread.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
        kernel.OpenThread.restype = wintypes.HANDLE
        kernel.ResumeThread.argtypes = (wintypes.HANDLE,)
        kernel.ResumeThread.restype = wintypes.DWORD
        snapshot = kernel.CreateToolhelp32Snapshot(4, 0)
        if snapshot in (None, ctypes.c_void_p(-1).value):
            raise ReviewerError("reviewer-process-isolation-unavailable")
        try:
            entry = THREAD()
            entry.dwSize = ctypes.sizeof(entry)
            found = kernel.Thread32First(snapshot, ctypes.byref(entry))
            while found:
                if entry.th32OwnerProcessID == self.process.pid:
                    thread = kernel.OpenThread(2, False, entry.th32ThreadID)
                    if not thread:
                        break
                    try:
                        if kernel.ResumeThread(thread) != 0xFFFFFFFF:
                            return
                    finally:
                        kernel.CloseHandle(thread)
                    break
                found = kernel.Thread32Next(snapshot, ctypes.byref(entry))
        finally:
            kernel.CloseHandle(snapshot)
        raise ReviewerError("reviewer-process-isolation-unavailable")

    def close(self) -> None:
        if self.job:
            from ctypes import wintypes
            class ACCOUNTING(ctypes.Structure):
                _fields_ = [(name, ctypes.c_longlong) for name in ("TotalUserTime", "TotalKernelTime", "ThisPeriodTotalUserTime", "ThisPeriodTotalKernelTime")] + [(name, wintypes.DWORD) for name in ("TotalPageFaultCount", "TotalProcesses", "ActiveProcesses", "TotalTerminatedProcesses")]
            self.kernel.TerminateJobObject(self.job, 1)
            stopped = time.monotonic() + 2
            while time.monotonic() < stopped:
                info = ACCOUNTING()
                if not self.kernel.QueryInformationJobObject(self.job, 1, ctypes.byref(info), ctypes.sizeof(info), None) or info.ActiveProcesses == 0:
                    break
                time.sleep(0.01)
            self.kernel.CloseHandle(self.job)
            self.job = None
        elif os.name != "nt":
            try:
                os.killpg(self.process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        if self.process.poll() is None:
            self.process.kill()
        try:
            self.process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            pass
        for stream in (self.process.stdin, self.process.stdout):
            if stream:
                stream.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


class _Lines:
    def __init__(self, stream):
        self.events: queue.Queue[Any] = queue.Queue(maxsize=2048)
        def read():
            total = 0
            try:
                while True:
                    raw = stream.readline(MAX_LINE_BYTES + 1)
                    if not raw:
                        self.events.put_nowait(None)
                        return
                    total += len(raw)
                    if len(raw) > MAX_LINE_BYTES or total > MAX_OUTPUT_BYTES:
                        raise ReviewerError("reviewer-output-too-large")
                    self.events.put_nowait(raw)
            except Exception:
                try:
                    self.events.put_nowait(ReviewerError("reviewer-invalid-process-output"))
                except queue.Full:
                    pass
        threading.Thread(target=read, daemon=True).start()

    def next(self, deadline: float):
        try:
            value = self.events.get(timeout=_remaining(deadline))
        except queue.Empty:
            raise ReviewerError("reviewer-timeout") from None
        if isinstance(value, Exception):
            raise value
        return value


def _environment() -> dict[str, str]:
    result = dict(os.environ)
    for key in list(result):
        if key.startswith(("CODEX_THREAD", "CODEX_PARENT_THREAD", "CODEX_REMOTE_")) or key == "CODEX_PROFILE":
            result.pop(key)
    result["AUTOHOOK_REVIEWER"] = "1"
    return result


def _overrides(directory: Path | None = None) -> list[str]:
    values = [f"features.{name}=false" for name in DISABLED_FEATURES]
    values += ['features.code_mode.enabled=false', 'web_search="disabled"',
               'apps._default.enabled=false', 'project_doc_max_bytes=0', 'approval_policy="never"',
               'approvals_reviewer="user"', 'model_provider="openai"']
    if directory is not None:
        values += ["sqlite_home=" + json.dumps(str(directory)), "log_dir=" + json.dumps(str(directory))]
    return [part for value in values for part in ("-c", value)]


def _rpc(process, lines: _Lines, method: str, params: dict[str, Any], identifier: int, deadline: float) -> Any:
    request = {"id": identifier, "method": method, "params": params}
    process.stdin.write((json.dumps(request) + "\n").encode("utf-8"))
    process.stdin.flush()
    while True:
        raw = lines.next(deadline)
        if raw is None:
            raise ReviewerError("reviewer-catalog-unavailable")
        try:
            response = _json(raw)
        except ValueError:
            raise ReviewerError("reviewer-invalid-rpc-response") from None
        if not isinstance(response, dict):
            raise ReviewerError("reviewer-invalid-rpc-response")
        if response.get("id") == identifier:
            if "error" in response or "result" not in response:
                raise ReviewerError("reviewer-catalog-unavailable")
            return response["result"]
        if "id" in response:
            raise ReviewerError("reviewer-unexpected-server-request")


def _discover(codex: str, directory: Path, deadline: float, env: dict[str, str]) -> tuple[list[dict[str, Any]], list[str]]:
    argv = [codex, "app-server", "--listen", "stdio://", "--strict-config", *_overrides(directory)]
    with _ProcessTree(argv, cwd=directory, env=env) as tree:
        lines = _Lines(tree.process.stdout)
        _rpc(tree.process, lines, "initialize", {"clientInfo": {"name": "autohook-reviewer", "version": "1.2.0"}}, 1, deadline)
        tree.process.stdin.write(b'{"method":"initialized"}\n')
        tree.process.stdin.flush()
        config = _rpc(tree.process, lines, "config/read", {"includeLayers": False}, 2, deadline)
        if not isinstance(config, dict) or not isinstance(config.get("config"), dict):
            raise ReviewerError("reviewer-invalid-rpc-response")
        servers = config["config"].get("mcp_servers", {})
        if servers is None:
            servers = {}
        if not isinstance(servers, dict) or any(not isinstance(key, str) or not key or len(key) > 256 for key in servers):
            raise ReviewerError("reviewer-invalid-rpc-response")
        models: list[dict[str, Any]] = []
        cursor = None
        for page in range(10):
            result = _rpc(tree.process, lines, "model/list", {"limit": 100, "cursor": cursor}, 3 + page, deadline)
            if not isinstance(result, dict) or not isinstance(result.get("data"), list):
                raise ReviewerError("reviewer-invalid-rpc-response")
            for model in result["data"]:
                if not isinstance(model, dict):
                    raise ReviewerError("reviewer-invalid-rpc-response")
                identifier = model.get("model", model.get("id"))
                efforts = model.get("supportedReasoningEfforts", [])
                if not isinstance(identifier, str) or not isinstance(efforts, list):
                    raise ReviewerError("reviewer-invalid-rpc-response")
                supported = [item.get("reasoningEffort") for item in efforts if isinstance(item, dict)]
                if not supported or any(item not in EFFORTS for item in supported):
                    continue
                models.append({"id": identifier, "model": identifier, "display_name": model.get("displayName") or identifier,
                               "default_reasoning_effort": model.get("defaultReasoningEffort", supported[0]),
                               "supported_reasoning_efforts": supported})
            cursor = result.get("nextCursor")
            if cursor is None:
                return models, list(servers)
            if not isinstance(cursor, str) or not cursor:
                raise ReviewerError("reviewer-invalid-rpc-response")
        raise ReviewerError("reviewer-catalog-too-large")


def _capture(argv: list[str], directory: Path, env: dict[str, str], deadline: float) -> str:
    with _ProcessTree(argv, cwd=directory, env=env) as tree:
        lines = _Lines(tree.process.stdout)
        tree.process.stdin.close()
        output = []
        while True:
            raw = lines.next(deadline)
            if raw is None:
                break
            output.append(raw)
        if tree.process.wait(timeout=_remaining(deadline)) != 0:
            raise ReviewerError("reviewer-compatibility-probe-failed")
        try:
            return b"".join(output).decode("utf-8")
        except UnicodeError:
            raise ReviewerError("reviewer-compatibility-probe-failed") from None


def probe(codex_path: str, *, timeout_seconds: int = 10) -> dict[str, Any]:
    """Validate native CLI flags with a clean home; never log in or infer."""
    deadline = time.monotonic() + timeout_seconds
    with tempfile.TemporaryDirectory(prefix="autohook-probe-") as temporary:
        directory = Path(temporary)
        environment = _environment()
        environment["CODEX_HOME"] = str(directory)
        help_text = _capture([codex_path, "exec", "--help"], directory, environment, deadline)
        required = ("--ignore-user-config", "--ignore-rules", "--ephemeral", "--skip-git-repo-check",
                    "--sandbox", "--strict-config", "--output-schema", "--json")
        if any(flag not in help_text for flag in required):
            raise ReviewerError("reviewer-incompatible-codex-flags")
        listing = _capture([codex_path, "features", "list", *_overrides(directory)], directory, environment, deadline)
        flags = {}
        for line in listing.splitlines():
            fields = line.split()
            if fields and fields[-1] in {"true", "false"}:
                flags[fields[0]] = fields[-1]
        if any(flags.get(name) != "false" for name in (*DISABLED_FEATURES, "code_mode")):
            raise ReviewerError("reviewer-incompatible-isolation-flags")
    return {"compatible": True, "inference_performed": False}


def model_catalog(codex_path: str, *, timeout_seconds: int = 10) -> dict[str, Any]:
    deadline = time.monotonic() + timeout_seconds
    with tempfile.TemporaryDirectory(prefix="autohook-catalog-") as temporary:
        models, _ = _discover(codex_path, Path(temporary), deadline, _environment())
    return {"models": models, "default_model": DEFAULT_REVIEWER["model"],
            "default_reasoning_effort": DEFAULT_REVIEWER["reasoning_effort"]}


def _decision(value: Any, request_id: str) -> dict[str, Any]:
    required = {"request_id", "decision", "risk_level", "user_authorization", "reason_code"}
    if not isinstance(value, dict) or set(value) != required or value.get("request_id") != request_id:
        raise ReviewerError("reviewer-invalid-decision")
    if any(not isinstance(value[key], str) for key in required) or value["decision"] not in {"allow", "manual"} or value["risk_level"] not in {"low", "medium", "high", "critical", "unknown"} or value["user_authorization"] not in {"high", "medium", "low", "unknown"}:
        raise ReviewerError("reviewer-invalid-decision")
    if value["reason_code"] not in {"low-risk", "bounded-risk", "authorized-high-risk", "requires-human", "insufficient-context", "policy-blocked"}:
        raise ReviewerError("reviewer-invalid-decision")
    if value["decision"] == "allow" and (value["risk_level"] in {"critical", "unknown"} or
            value["risk_level"] == "high" and value["user_authorization"] not in {"medium", "high"} or
            value["reason_code"] in {"requires-human", "insufficient-context", "policy-blocked"}):
        raise ReviewerError("reviewer-inconsistent-decision")
    return {"decision": value["decision"], "rule": "reviewer." + value["decision"],
            "reason": "reviewer-" + value["reason_code"], "risk_level": value["risk_level"],
            "user_authorization": value["user_authorization"]}


def _run_review(argv: list[str], packet: bytes, directory: Path, env: dict[str, str], deadline: float) -> Any:
    with _ProcessTree(argv, cwd=directory, env=env) as tree:
        lines = _Lines(tree.process.stdout)
        written = threading.Event()
        write_errors = []
        def write_input():
            try:
                tree.process.stdin.write(packet)
                tree.process.stdin.close()
            except (OSError, ValueError):
                write_errors.append(True)
            finally:
                written.set()
        threading.Thread(target=write_input, daemon=True).start()
        final = None
        completed = False
        while True:
            raw = lines.next(deadline)
            if raw is None:
                break
            try:
                event = _json(raw)
            except ValueError:
                raise ReviewerError("reviewer-invalid-process-output") from None
            if not isinstance(event, dict):
                raise ReviewerError("reviewer-invalid-process-output")
            kind = event.get("type")
            if kind in {"error", "turn.failed"}:
                raise ReviewerError("reviewer-execution-failed")
            if kind == "turn.completed":
                completed = True
            elif kind in {"item.started", "item.updated", "item.completed"}:
                item = event.get("item")
                if not isinstance(item, dict) or item.get("type") not in {"agent_message", "reasoning"}:
                    raise ReviewerError("reviewer-unexpected-tool-use")
                if kind == "item.completed" and item.get("type") == "agent_message":
                    if final is not None or not isinstance(item.get("text"), str):
                        raise ReviewerError("reviewer-invalid-decision")
                    final = item["text"]
            elif kind not in {"thread.started", "turn.started"}:
                raise ReviewerError("reviewer-invalid-process-output")
        try:
            code = tree.process.wait(timeout=_remaining(deadline))
        except subprocess.TimeoutExpired:
            raise ReviewerError("reviewer-timeout") from None
        if not written.wait(timeout=_remaining(deadline)):
            raise ReviewerError("reviewer-timeout")
        if code != 0 or not completed or final is None or write_errors:
            raise ReviewerError("reviewer-execution-failed")
        try:
            return _json(final)
        except ValueError:
            raise ReviewerError("reviewer-invalid-decision") from None


def review_request(payload: Any, settings: dict[str, Any], assets: Path, *, deadline: float | None = None) -> dict[str, Any]:
    started = time.monotonic()
    options = dict(DEFAULT_REVIEWER)
    try:
        options = validate_settings(settings.get("reviewer", DEFAULT_REVIEWER))
        deadline = min(deadline or started + options["timeout_seconds"], started + options["timeout_seconds"])
        if os.environ.get("AUTOHOOK_REVIEWER") == "1":
            raise ReviewerError("reviewer-recursion-blocked")
        if not isinstance(payload, dict) or payload.get("hook_event_name") != "PermissionRequest" or not isinstance(payload.get("tool_name"), str) or not payload["tool_name"] or not isinstance(payload.get("tool_input"), dict):
            raise ReviewerError("reviewer-invalid-request")
        action = {"tool_name": payload["tool_name"], "tool_input": payload["tool_input"], "cwd": payload.get("cwd")}
        action_raw = json.dumps(action, ensure_ascii=True, sort_keys=True, allow_nan=False).encode("utf-8")
        if len(action_raw) > MAX_ACTION_BYTES:
            raise ReviewerError("reviewer-action-too-large")
        context = transcript_context(payload, settings, deadline)
        request_id = hashlib.sha256(action_raw + context["session_id"].encode("ascii")).hexdigest()
        packet = json.dumps({"request_id": request_id, "planned_action": action, "session_evidence": context}, ensure_ascii=True).encode("utf-8")
        codex = settings["codex_path"]
        if not isinstance(codex, str) or not Path(codex).is_absolute() or Path(codex).suffix.lower() != ".exe":
            raise ReviewerError("reviewer-invalid-codex")
        schema = assets / "review-schema.json"
        instructions = assets / "review-instructions.md"
        if not schema.is_file() or not instructions.is_file():
            raise ReviewerError("reviewer-missing-assets")
        with tempfile.TemporaryDirectory(prefix="autohook-review-") as temporary:
            directory = Path(temporary)
            env = _environment()
            models, servers = _discover(codex, directory, deadline, env)
            selected = next((model for model in models if model["id"] == options["model"]), None)
            if selected is None or options["reasoning_effort"] not in selected["supported_reasoning_efforts"]:
                raise ReviewerError("reviewer-model-unavailable")
            review_instructions = directory / "instructions.md"
            template = (assets / "guardian-policy-template.md").read_text(encoding="utf-8-sig")
            policy = (assets / "guardian-policy.md").read_text(encoding="utf-8-sig")
            policy = template.replace("{{ tenant_policy_config }}", policy).replace("{{ extra_policy }}", "")
            if "{{" in policy:
                raise ReviewerError("reviewer-invalid-policy-template")
            review_instructions.write_text(instructions.read_text(encoding="utf-8-sig").replace("{{ guardian_policy }}", policy), encoding="utf-8")
            argv = [codex, "exec", "--ignore-user-config", "--ignore-rules", "--ephemeral", "--skip-git-repo-check",
                    "--sandbox", "read-only", "--strict-config", "--color", "never", "--json", "--output-schema", str(schema.resolve()),
                    "--model", options["model"], *_overrides(directory), "-c", "model_reasoning_effort=" + json.dumps(options["reasoning_effort"]),
                    "-c", "model_instructions_file=" + json.dumps(str(review_instructions.resolve()))]
            for server in servers:
                argv += ["-c", "mcp_servers." + json.dumps(server) + ".enabled=false"]
            argv.append("-")
            result = _decision(_run_review(argv, packet, directory, env, deadline), request_id)
            if result["decision"] == "allow" and result["risk_level"] == "high" and context["context_truncated"]:
                raise ReviewerError("reviewer-incomplete-authorization")
    except (ReviewerError, OSError, ValueError, KeyError, TypeError, RuntimeError, subprocess.SubprocessError) as error:
        result = {"decision": "manual", "rule": "reviewer.manual",
                  "reason": str(error) if isinstance(error, ReviewerError) else "reviewer-unavailable"}
    return {**result, "source": "reviewer", "model": options["model"], "reasoning_effort": options["reasoning_effort"],
            "duration_ms": round((time.monotonic() - started) * 1000)}
