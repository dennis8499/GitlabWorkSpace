# Extract command tokens as data for explicit project-rule vetoes. Never execute the request.
$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$commands = [System.Collections.Generic.List[object]]::new()
$script:complete = $true
function Scan-Source([string]$Text, [int]$Depth) {
    if ($Depth -gt 4) { $script:complete = $false; return }
    $tokens = $null
    $errors = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseInput($Text, [ref]$tokens, [ref]$errors)
    if (@($errors).Count -ne 0) { throw 'parse-error' }
    if (@($ast.FindAll({ param($node) $node -is [System.Management.Automation.Language.InvokeMemberExpressionAst] }, $true)).Count -gt 0 -or
        @($ast.UsingStatements).Count -gt 0) { $script:complete = $false }
    foreach ($command in $ast.FindAll({ param($node) $node -is [System.Management.Automation.Language.CommandAst] }, $true)) {
        $argv = [System.Collections.Generic.List[string]]::new()
        $static = $true
        foreach ($element in $command.CommandElements) {
            if ($element -is [System.Management.Automation.Language.StringConstantExpressionAst]) {
                $argv.Add($element.Value)
            } elseif ($element -is [System.Management.Automation.Language.ConstantExpressionAst] -and
                      ($element.Value -is [int] -or $element.Value -is [long]) -and
                      $element.Extent.Text -cmatch '^(0|[1-9][0-9]*)$') {
                $argv.Add($element.Value.ToString([System.Globalization.CultureInfo]::InvariantCulture))
            } elseif ($element -is [System.Management.Automation.Language.CommandParameterAst] -and $null -eq $element.Argument) {
                $argv.Add('-' + $element.ParameterName)
            } else { $static = $false; break }
        }
        if ($argv.Count -gt 0) { $commands.Add([object]$argv.ToArray()) }
        if (-not $static -or $argv.Count -eq 0) { $script:complete = $false; continue }
        $program = [System.IO.Path]::GetFileName($argv[0]).ToLowerInvariant()
        if ($program -in @('powershell', 'powershell.exe', 'pwsh', 'pwsh.exe')) {
            $flag = -1
            for ($i = 1; $i -lt $argv.Count; $i++) { if ($argv[$i].ToLowerInvariant() -in @('-command', '-c')) { $flag = $i; break } }
            if ($flag -gt 0 -and $flag + 2 -eq $argv.Count) { Scan-Source $argv[$flag + 1] ($Depth + 1) }
            else { $script:complete = $false }
        } elseif ($program -in @('cmd', 'cmd.exe', 'bash', 'bash.exe', 'sh', 'sh.exe', 'zsh', 'zsh.exe',
                                'invoke-expression', 'iex', 'invoke-command', 'icm', 'start-process', 'saps')) {
            $script:complete = $false
        }
    }
}
try {
    $request = [Console]::In.ReadToEnd() | ConvertFrom-Json
    if ($request.command -isnot [string] -or $request.command.Length -gt 1048576 -or $request.command.Contains([char]0)) { throw 'invalid-command' }
    Scan-Source $request.command 0
    @{ ok = $true; complete = $script:complete; commands = @($commands.ToArray()) } | ConvertTo-Json -Depth 8 -Compress
} catch {
    @{ ok = $false; complete = $false; commands = @(); reason = 'parse-failed' } | ConvertTo-Json -Compress
}
