"""Small, source-preserving TOML edits for the settings owned by AutoHook.

tomllib validates the complete document; this scanner locates statements only.
Unrelated tables, comments and values are never regenerated.
"""
from __future__ import annotations

import copy
import datetime
import json
import math
import tomllib
from dataclasses import dataclass
from typing import Any

MISSING = object()


def load_toml(text: str) -> dict[str, Any]:
    return tomllib.loads(text.lstrip("\ufeff"))


def lookup(data: dict[str, Any], path: tuple[str, ...]) -> Any:
    value: Any = data
    for key in path:
        if not isinstance(value, dict) or key not in value:
            return MISSING
        value = value[key]
    return value


def literal(value: Any) -> str:
    if isinstance(value, str):
        # Keep Unicode literal: TOML rejects JSON's surrogate-pair escapes.
        return json.dumps(value, ensure_ascii=False).replace("\x7f", "\\u007f")
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if math.isnan(value):
            return "nan"
        if math.isinf(value):
            return "inf" if value > 0 else "-inf"
        return repr(value)
    if isinstance(value, (datetime.datetime, datetime.date, datetime.time)):
        return value.isoformat()
    if isinstance(value, list):
        return "[" + ", ".join(literal(item) for item in value) + "]"
    if isinstance(value, dict):
        return "{ " + ", ".join(f"{literal(str(k))} = {literal(v)}" for k, v in value.items()) + " }"
    raise ValueError("Unsupported TOML value")


def _statements(text: str):
    start = index = 0
    quote = ""
    triple = False
    depth = 0
    comment = False
    while index < len(text):
        char = text[index]
        if comment:
            if char != "\n":
                index += 1
                continue
            comment = False
        elif quote:
            if quote == '"' and char == "\\":
                index += 2
                continue
            if char == quote:
                if triple:
                    run = 1
                    while index + run < len(text) and text[index + run] == quote:
                        run += 1
                    if run >= 3:
                        quote = ""
                    index += run
                    continue
                quote = ""
            index += 1
            continue
        elif char in "\"'":
            quote = char
            triple = text[index:index + 3] == char * 3
            index += 3 if triple else 1
            continue
        elif char == "#":
            comment = True
        elif char in "[{":
            depth += 1
        elif char in "]}":
            depth -= 1
        if char == "\n" and depth == 0:
            yield start, index + 1, text[start:index + 1]
            start = index + 1
        index += 1
    if start < len(text):
        yield start, len(text), text[start:]


def _single_path(value: Any, marker: Any, prefix: tuple[str, ...] = ()) -> tuple[str, ...]:
    if value == marker and not isinstance(value, (dict, list)):
        return prefix
    if isinstance(value, dict):
        for key, child in value.items():
            try:
                return _single_path(child, marker, prefix + (key,))
            except ValueError:
                pass
    if isinstance(value, list):
        for child in value:
            try:
                return _single_path(child, marker, prefix + ("#array",))
            except ValueError:
                pass
    raise ValueError("Cannot locate TOML key")


def _assignment_key(source: str) -> str:
    quote = ""
    escaped = False
    for index, char in enumerate(source):
        if quote:
            if escaped:
                escaped = False
            elif quote == '"' and char == "\\":
                escaped = True
            elif char == quote:
                quote = ""
        elif char in "\"'":
            quote = char
        elif char == "=":
            return source[:index].strip()
    raise ValueError("Cannot locate TOML assignment")


@dataclass
class Statement:
    start: int
    end: int
    path: tuple[str, ...]
    header: bool
    source: str


def inspect_statements(text: str) -> list[Statement]:
    load_toml(text)
    context: tuple[str, ...] = ()
    result = []
    for start, end, source in _statements(text):
        clean = source.strip()
        if not clean or clean.startswith("#"):
            continue
        if clean.startswith("["):
            marker_key = "__autohook_statement_locator__"
            parsed = tomllib.loads(source + f'\n{marker_key} = "__marker__"\n')
            context = _single_path(parsed, "__marker__")[:-1]
            result.append(Statement(start, end, context, True, source))
        else:
            key = _assignment_key(source)
            path = context + _single_path(tomllib.loads(key + ' = "__marker__"'), "__marker__")
            result.append(Statement(start, end, path, False, source))
    return result


def edit_toml(text: str, target: tuple[str, ...], value: Any = MISSING) -> str:
    """Set/delete a key, including inline or ordinary tables, without blind regexes."""
    bom = "\ufeff" if text.startswith("\ufeff") else ""
    text = text.removeprefix("\ufeff")
    parsed = load_toml(text)
    statements = inspect_statements(text)
    newline = "\r\n" if "\r\n" in text else "\n"
    replacements: list[tuple[int, int, str]] = []
    parent_assignment = next((s for s in statements if not s.header and
                              len(s.path) < len(target) and target[:len(s.path)] == s.path), None)
    if parent_assignment:
        parent_value = copy.deepcopy(lookup(parsed, parent_assignment.path))
        cursor = parent_value
        rest = target[len(parent_assignment.path):]
        for key in rest[:-1]:
            cursor = cursor.setdefault(key, {})
        if value is MISSING:
            cursor.pop(rest[-1], None)
        else:
            cursor[rest[-1]] = value
        key = _assignment_key(parent_assignment.source)
        replacement = f"{key} = {literal(parent_value)}{newline}"
        replacements.append((parent_assignment.start, parent_assignment.end, replacement))
    else:
        for statement in statements:
            if statement.path[:len(target)] == target:
                replacements.append((statement.start, statement.end, ""))
        if value is not MISSING:
            parent_header = next((s for s in statements if s.header and s.path == target[:-1]), None)
            if parent_header and len(target) > 1:
                replacements.append((parent_header.end, parent_header.end,
                                     f"{literal(target[-1])} = {literal(value)}{newline}"))
            else:
                key = ".".join(literal(part) for part in target)
                replacements.append((0, 0, f"{key} = {literal(value)}{newline}"))
    for start, end, replacement in sorted(replacements, key=lambda item: (item[0], item[1]), reverse=True):
        text = text[:start] + replacement + text[end:]
    load_toml(text)
    actual = lookup(load_toml(text), target)
    if (value is MISSING and actual is not MISSING) or (value is not MISSING and actual != value):
        raise ValueError("TOML edit did not produce the requested setting")
    return bom + text
