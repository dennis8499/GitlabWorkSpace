# Parse untrusted command text as data. Never invoke or evaluate the parsed AST.
$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)

function Reject-Command([string]$Reason) {
    @{ ok = $false; reason = $Reason } | ConvertTo-Json -Compress
    exit 0
}

try {
    $request = [Console]::In.ReadToEnd() | ConvertFrom-Json
    if ($request.command -isnot [string] -or $request.command.Length -gt 65536) {
        Reject-Command 'invalid-command'
    }
    $commandText = $request.command
    if ($commandText.Contains([char]0) -or $commandText.Contains("`r") -or $commandText.Contains("`n")) {
        Reject-Command 'multiline-or-control-character'
    }
    $parseTokens = $null
    $parseErrors = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseInput(
        $commandText, [ref]$parseTokens, [ref]$parseErrors
    )
    if (@($parseErrors).Count -ne 0) { Reject-Command 'parse-error' }
    if ($ast.ParamBlock -or $ast.BeginBlock -or $ast.ProcessBlock -or $ast.DynamicParamBlock -or
        @($ast.UsingStatements).Count -ne 0 -or @($ast.Attributes).Count -ne 0) {
        Reject-Command 'script-block'
    }
    if (-not $ast.EndBlock -or -not $ast.EndBlock.Unnamed -or
        @($ast.EndBlock.Statements).Count -ne 1 -or $ast.EndBlock.Traps) {
        Reject-Command 'compound-command'
    }
    $pipeline = $ast.EndBlock.Statements[0]
    if ($pipeline -isnot [System.Management.Automation.Language.PipelineAst] -or
        @($pipeline.PipelineElements).Count -ne 1) {
        Reject-Command 'pipeline-or-expression'
    }
    $command = $pipeline.PipelineElements[0]
    if ($command -isnot [System.Management.Automation.Language.CommandAst] -or
        $command.InvocationOperator -ne [System.Management.Automation.Language.TokenKind]::Unknown -or
        @($command.Redirections).Count -ne 0) {
        Reject-Command 'invocation-or-redirection'
    }
    foreach ($token in $parseTokens) {
        if ($token.Text -eq '--%' -or
            $token.Kind.ToString() -in @('StopParsing', 'HereStringLiteral', 'HereStringExpandable', 'LineContinuation')) {
            Reject-Command 'unsupported-token'
        }
    }
    $argv = [System.Collections.Generic.List[string]]::new()
    foreach ($element in $command.CommandElements) {
        if ($element -is [System.Management.Automation.Language.StringConstantExpressionAst]) {
            $argv.Add($element.Value)
        } elseif ($element -is [System.Management.Automation.Language.ConstantExpressionAst] -and
                  ($element.Value -is [int] -or $element.Value -is [long]) -and
                  $element.Extent.Text -cmatch '^(0|[1-9][0-9]*)$') {
            # Canonical integers serialize exactly as they do at execution time.
            # Reject leading zeros, hex, suffixes and expressions rather than guessing.
            $argv.Add($element.Value.ToString([System.Globalization.CultureInfo]::InvariantCulture))
        } elseif ($element -is [System.Management.Automation.Language.CommandParameterAst] -and
                  $null -eq $element.Argument) {
            $argv.Add('-' + $element.ParameterName)
        } else {
            Reject-Command 'dynamic-argument'
        }
    }
    if ($argv.Count -eq 0) { Reject-Command 'empty-command' }
    @{ ok = $true; argv = @($argv.ToArray()); parser = 'WindowsPowerShell-AST' } |
        ConvertTo-Json -Depth 4 -Compress
} catch {
    Reject-Command 'parser-failure'
}
