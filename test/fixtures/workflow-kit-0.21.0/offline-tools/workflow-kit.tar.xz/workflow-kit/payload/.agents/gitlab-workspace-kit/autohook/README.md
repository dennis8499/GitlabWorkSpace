# AutoHook

在指定專案中，以**明文規則**自動接受 Codex CLI 與共用專案設定的 VS Code Codex Chat 的部分工具權限請求。使用 `PermissionRequest` Hook，不呼叫 AI 審查、不擷取畫面、不模擬按鍵。

符合規則時只接受當次請求；不符合、無法解析或檢查失敗時，保留 Codex 原本的人工核准。一般對話問題仍由你回答。

這是獨立的規則版本。原生 `Approve for me` 會用 AI 判斷風險與使用者授權，AutoHook 的結果無法與它完全相同。

## 需求

- Windows、Windows PowerShell 5.1、Python 3.11 以上。
- PATH 上有支援 `PermissionRequest` Hooks 及 `codex execpolicy check` 的 Codex CLI。
- 原生解析器與 Hook 協定測試使用本機 `codex-cli 0.162.0-alpha.17.2`、Windows PowerShell 5.1、Python 3.14；互動工作階段驗收另見下方。
- 專案設定與本機 Hook 必須獲 Codex 信任；企業設定仍須允許本機 Hooks。

只使用 Python 標準函式庫，無須安裝套件或提供 API key。解析器以固定行內程式呼叫 PowerShell AST，不變更 PowerShell 執行原則，也不執行待核准的命令。

原生規則解析器使用 `codex.exe`。若 PATH 指向 npm 的 `codex.cmd`，工具會尋找套件內的原生執行檔；找不到時可在 `enable` 加上 `--codex 'C:\path\to\codex.exe'`。待核准的參數不會經過 `.cmd`／`.bat` 轉送。

## 啟用

在本工具目錄執行，將路徑換成要使用的專案：

```powershell
python .\autohook.py enable --project 'C:\Work\MyProject'
```

啟用會複製執行所需檔案至該專案，合併既有 Hooks，並設定：

```toml
approval_policy = "on-request"
approvals_reviewer = "user"

[features]
hooks = true
```

接著在目標專案重新啟動 Codex，依畫面確認專案信任，再以 `/hooks` 檢查並信任新的 AutoHook。這個首次信任步驟需要由你操作。

介面仍會顯示 `Ask for approval`；符合規則的請求會由 Hook 自動處理。啟用只修改指定專案的設定。

```powershell
python .\autohook.py status --project 'C:\Work\MyProject'
python .\autohook.py status --project 'C:\Work\MyProject' --json
```

`configuration_ready: true` 表示安裝、設定及相容性檢查通過；它無法透過穩定介面確認 Codex 是否已保存 Hook 信任。Codex 的啟動參數、profile、企業設定、個別 App reviewer 設定及其他 Hooks 仍可能影響最後結果。請使用新開啟的標準 Codex 工作階段，避免以 `--approve-for-me` 覆寫專案的人工 reviewer。

## 檢查規則

以下指令只分析請求，**不執行命令、不套用 patch**：

```powershell
python .\autohook.py check --project 'C:\Work\MyProject' --command 'Get-Location'
python .\autohook.py check --project 'C:\Work\MyProject' --command 'npm test'
python .\autohook.py check --project 'C:\Work\MyProject' --command 'npm install'
python .\autohook.py check --project 'C:\Work\MyProject' --command 'git diff --no-ext-diff --no-textconv --stat'
python .\autohook.py check --project 'C:\Work\MyProject' --patch .\example.patch
python .\autohook.py check --project 'C:\Work\MyProject' --input .\permission-request.json
```

`check` 的 JSON 結果包含 `decision`（`allow`／`manual`）、`rule`、`reason`。可用 `--cwd` 檢查子目錄中的命令；`--input -` 讀取 stdin 上的 Hook JSON。沒有啟用的專案會回傳 `manual`。

## 預設規則

第一道檢查限制語法、參數與實際路徑；通過後，再由 Codex 原生 `prefix_rule` 解析器確認明確的 `allow`。

| 類型 | 允許的形式 |
|---|---|
| 目前目錄 | `Get-Location` |
| 目錄清單 | `Get-ChildItem -LiteralPath PATH`，可加 `-Force`、`-Name`、`-File`、`-Directory` |
| 讀取文字 | `Get-Content -LiteralPath FILE`，可加 `-Raw` |
| 檔案名稱清單 | `rg --files` 或 `rg --files PATH` |
| 單一檔案文字搜尋 | `rg -n -F -- '文字' FILE` |
| Git 狀態 | `git status`，可加 `--short`、`--porcelain`、`--porcelain=v1`、`--branch`、`-s`、`-sb` |
| Git 差異 | `git diff --no-ext-diff --no-textconv`，可加 `--stat`、`--numstat`、`--name-only`、`--name-status`、`--summary`、`--cached`、`--staged` |
| Git 歷史 | `git log`，可加 `--oneline`、`--stat`、`--name-only`、`--decorate`、`--all`，以及 `-n N`／`--max-count N`（1–100） |
| Git 檔案清單 | `git ls-files`，可加 `--cached`、`--modified`、`--others`、`--exclude-standard`、`--stage` |
| 專案檔案修改 | `apply_patch` 的 `Add File`、`Update File` |

Git 查閱命令可在 `git` 後加 `--no-pager`，或在尾端以 `-- PATH` 指定專案內路徑。一般 `git diff` 若缺少 `--no-ext-diff --no-textconv`，會交給人工核准，避免自動執行外部 diff／textconv 程式。

測試與建置只接受下列**完整命令，不接受額外參數**，並要求專案內有對應的專案標記檔：

| 專案 | 命令 | 標記 |
|---|---|---|
| Node | `npm test`、`npm run test`、`npm run build`，以及相同的 `pnpm` 形式 | `package.json` |
| Python | `pytest`、`python -m pytest` | `pyproject.toml`、`pytest.ini`、`setup.cfg`、`tests` 或 `test` |
| .NET | `dotnet test`、`dotnet build` | `.sln`、`.slnx`、`.csproj`、`.fsproj` 或 `.vbproj` |
| Rust | `cargo test`、`cargo build`、`cargo check` | `Cargo.toml` |
| Go | `go test ./...`、`go build ./...` | `go.mod` 或 `go.work` |

測試與建置會執行受信任專案的程式；AutoHook 不審查腳本內容或推斷其所有副作用。Hook 是核准流程的一部分，原本的 sandbox 與企業限制仍由 Codex 執行。

以下情況保留人工決定：

- 刪除、搬移、安裝依賴、Git 寫入、外部路徑、資料庫與權限設定。
- `.codex`、`.git`、`.agents`、`.aws`、`.ssh`、`.azure`、`.kube`、秘密目錄、`.env*`、憑證私鑰等敏感路徑。
- 路徑穿越、外部 junction／符號連結、硬連結、NTFS alternate data streams 或裝置路徑。
- 命令串接、pipeline、重新導向、變數、插值、子命令、呼叫運算子、ScriptBlock、未支援的 Shell。
- MCP 等未知工具、解析錯誤、規則錯誤、逾時、安裝檔案改變、Codex 版本變更。

專案已有的 `.codex/rules/*.rules` 也會交給原生解析器合併檢查；符合 `prompt` 或 `forbidden` 時，AutoHook 不會自動放行。其他 Hook 的 `deny` 仍具有優先權。

`default.rules` 放在 AutoHook 目錄中，請保留這個位置；它必須在語法與路徑檢查之後才由工具載入。規則與解析器有完整性檢查；修改已安裝檔案會轉回人工。規則變更應更新本工具來源及測試，再重新 `enable`。

## 停用與更新

```powershell
python .\autohook.py disable --project 'C:\Work\MyProject'
```

停用會先關閉自動核准，再移除工具註冊的 Hook 並還原原設定。若期間修改了其他設定或 Hooks，會保留這些修改；你自行改過的核准設定也會保留。執行檔與本機備份留在 `.codex/autohook/`，方便檢查與再次啟用。

Codex 更新後，工具因版本不同而轉回人工；重新執行 `enable` 會檢查原生解析器介面、PowerShell AST 及規則，再更新版本記錄。重新安裝改變 Hook 定義時，請再檢查 `/hooks`。

`.codex/autohook/decisions.jsonl` 只記錄時間、結果、規則與原因，不記錄原始命令、對話、檔案內容或憑證。超過 1 MiB 保留一份前期紀錄。設定備份可能包含原有專案設定中的秘密，因此工具會在這個目錄建立 `.gitignore`，將執行檔、紀錄與備份保留在本機；請保留這項排除設定。

## 驗證

### 安裝包整合介面（1.1.0）

`prepare_enable(project, source, base_files=...)` 與 `prepare_disable(project)` 回傳 `PreparedChange`：`files` 為專案相對路徑到 bytes／None 的變更，`result` 為操作結果。準備階段只讀取及檢查，不修改專案；`apply_prepared` 才套用。`base_files` 可提供最新的 Codex 設定及 Hooks 底稿，讓整包安裝器合併 Wiki 後重新建立停用還原點。所有產生的路徑仍指向實際專案。

可重現來源包：`python scripts/package_release.py dist/autohook-1.1.0.zip`。GitLab Workspace 隨包提供工具，預設關閉，由 **設定 → 工作區與 Skills → AutoHook → 啟用 AutoHook** CheckBox 管理。勾選狀態來自目前 Skills 根目錄的實際安裝，不另存 VS Code 布林設定；取消勾選執行停用。首次信任仍需在 Codex `/hooks` 完成。

`status` 與 `PreparedChange.result` 增加 `policy_source`、`policy_coverage`，保留既有 CLI 與整合介面。

### 官方政策快照與涵蓋範圍

`policy-source.json` 固定 OpenAI Codex 上游 commit、下載日期、來源 URL 與逐檔 SHA-256；`guardian-policy.md`、`guardian-policy-template.md` 保存公開原文，授權與歸屬見 `UPSTREAM-LICENSE`、`UPSTREAM-NOTICE`。這些資料隨離線包安裝並接受完整性檢查，執行時不連網。它們是對照資料，不是額外執行指令。

`policy.json` 的 `coverage.mappings` 逐組列出固定規則對應的官方文件與標題：

| 分類 | 規則 | 判定邊界 |
|---|---|---|
| 可程式判定的部分 | 專案內固定讀取、Git 查閱 | AST、參數、路徑及完整性檢查；不是完整的敏感資料分類 |
| 專案預授權 | 指定測試／建置、檔案新增／更新 | 勾選即預授權這些模板；專案腳本與內容副作用未經語意審查 |
| 人工判斷 | 對話授權、注入、憑證、外傳目的地、正式環境、破壞及規則外操作 | 固定規則無法判定，交回人工核准 |

固定規則不能完整重現原生 AI 審查。專案範圍檢查限制的是命令的目標路徑，不能保證專案程式不存取外部資源；只有信任專案的測試與建置程式時才啟用。

維護者更新快照：`python scripts/snapshot_policy.py --revision <40字元commit>`，再人工檢視條文對照、調整規則、提高版本並執行測試。此下載工具不會在 Hook 或安裝時執行。

```powershell
python -m unittest discover -s tests -v
```

測試涵蓋原生 PowerShell／Codex 解析器、Hook stdin／stdout 協定、人工回退、命令注入、敏感路徑、NTFS junction／硬連結、安裝失敗還原、設定及 Hooks 共存、停用與版本變更。測試使用暫存專案，不呼叫模型，也不變更使用者全域設定。未以模型工作階段實測 Codex 的首次信任畫面；請依啟用步驟完成。

### 互動工作階段驗收

此項必須在已登入且能操作信任畫面的 Windows 本機完成，不能以解析器／stdin 測試代替。CLI 與 VS Code Codex Chat 各開啟一個以相同 Skills 根目錄為 cwd 的新工作階段，依官方流程信任專案及 Hook，維持 `on-request`／`user`，再分別驗證：

1. 要求 Codex 以 PowerShell 單獨執行 `Get-Location`，明確指定工具的 `sandbox_permissions = "require_escalated"`，以確保觸發核准請求。預期 Hook 自動允許，紀錄為 `allow`／`read.location`。
2. 以相同方式要求執行 `Write-Output 'AutoHook-manual-check'`。這個無副作用的命令不在模板中，預期出現人工核准；取消該請求，紀錄為 `manual`。
3. 取消勾選後開啟新工作階段，重複第一項，預期不再由 AutoHook 自動允許。介面名稱可以維持 `Ask for approval`。

若命令未請求核准，就沒有驗證到 `PermissionRequest`。記錄兩個客戶端的版本、cwd、信任步驟、核准畫面結果與相應決策紀錄。受企業設定、其他 Hooks 或不同工作目錄影響時應先排除差異，不能將本機設定檢查視為互動驗收通過。

## 依據

- [OpenAI Docs：Hooks](https://learn.chatgpt.com/docs/hooks)
- [OpenAI Docs：Rules](https://learn.chatgpt.com/docs/agent-configuration/rules)
- [OpenAI Docs：Auto-review](https://learn.chatgpt.com/docs/sandboxing/auto-review)
- [OpenAI Docs：Configuration Reference](https://learn.chatgpt.com/docs/config-file/config-reference)
