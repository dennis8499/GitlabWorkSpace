# GitLab Workspace single-repository profile

Use the installed native Codebase LLM Wiki, Megin, MergeReviewer and ReleaseReviewer Skills from this Git repository root. This repository is the complete scope of each task. Source references are relative to this repository. Keep knowledge under `wiki/`, work records under `docs/work/<Work ID>/` and reports under `review-reports/`.

AutoHook 1.0.1 is bundled under `.agents/gitlab-workspace-kit/autohook/` as an optional tool, disabled by default. Manage it in Workspace settings at this Skills root, without modifying child repositories. Enabled runtime files live in `.codex/autohook/`; updates validate and update them atomically with the kit, preserving the latest Wiki baseline, other hooks/settings, and decision logs. Windows, Windows PowerShell and a compatible native Codex executable are required to enable it. Reopen Codex and confirm trust in `/hooks` after setup; Workspace does not verify Codex trust.

Use native Megin's repository workflow, approved plan, Repo lock, independent review, executed verification, human acceptance and local delivery gates. Keep its twelve Skills together. Preserve the original Work ID, installed Skills fingerprint and approved versions when resuming a task.

Run review helpers from this repository and pass this repository as `--workspace`. Require explicit base/head versions for version reviews and release checks. Preserve local edits, keep owned evidence in system temporary storage, and clean owned contexts after completion or interruption. JSON reports are opt-in.

The selected repository's local instructions and this repository profile govern these native workflows, including when an ancestor directory has a GitLab Workspace Group installation. Each task uses this repository's installed Skills and records.

New work uses native Megin v2 in the repository profile and Group v4 in the Group profile. Explore current-source functions and neutral requirements, obtain exact-plan approval, then preserve BDD/TDD raw evidence and a fresh independent read-only reviewer for initial round 0 plus at most three correction rounds. Approval can stop retries early; three failed corrections remain incomplete. Resume preserves the original attempt history and fingerprint. Functional exploration is source-first and read-only by default; normal Wiki queries stay Wiki-first.
